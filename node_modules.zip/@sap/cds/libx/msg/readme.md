# Messaging Service Implementations

That is: `cds.Service` implementations acting as clients to messaging channels and brokers 
