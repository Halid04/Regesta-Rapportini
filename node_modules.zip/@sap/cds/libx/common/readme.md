# Core Service Provider Implementation

- That is: `cds.Service` implementations for core and enterprise features
- Core in the sense of [Hexagonal Architecture's](https://en.wikipedia.org/wiki/Hexagonal_architecture_(software)) "Application Code"
