const cds = require('../../lib')

module.exports = (component, service, target, data, odataReq, upsert) => {
  let query = cds.odata.parse(odataReq, { service })

  //For concat
  if (component === 'READ' && Array.isArray(query)) {
    return query
  }

  const _target = query.SELECT && query.SELECT.from

  const {
    SELECT: { one }
  } = query

  switch (component) {
    case 'CREATE':
      // create
      // error in cases like `POST Books(1)` i.e. `POST` with navigation to single entity
      if (one && !upsert) cds.error('POST not allowed on entity', { code: 400 })
      return INSERT.into(_target).entries(data)
    case 'DELETE':
      if (!one) cds.error('DELETE not allowed on collection', { code: 400 })

      // eslint-disable-next-line no-case-declarations
      const last = query._propertyAccess || (_target.ref && _target.ref[_target.ref.length - 1])
      if (target.elements[last] || target.elements[query._propertyAccess]) {
        // delete simple property
        const ref = { ref: query._propertyAccess ? _target.ref : _target.ref.slice(0, -1) }
        return UPDATE(ref).data({ [last]: null })
      } else {
        return DELETE.from(_target)
      }
    case 'UPDATE':
      // eslint-disable-next-line no-throw-literal
      if (!one) throw { statusCode: 400, code: '400', message: `INVALID_${odataReq.getMethod()}` }
      return UPDATE(_target).data(data)
    default:
      return query
  }
}
