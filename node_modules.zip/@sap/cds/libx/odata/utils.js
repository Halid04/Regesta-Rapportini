const { toBase64url } = require('../_runtime/common/utils/binary')
const cds = require('../_runtime/cds')

const getSafeNumber = str => {
  const n = Number(str)
  return Number.isSafeInteger(n) || String(n) === str ? n : str
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
const _PT = ([hh, mm, ss]) => `PT${hh}H${mm}M${ss}S`
const _isTimestamp = val =>
  /^\d+-\d\d-\d\d(T\d\d:\d\d(:\d\d(\.\d+)?)?(Z|([+-]{1}\d\d:\d\d))?)?$/.test(val) && !isNaN(Date.parse(val))

const _getElement = (csnTarget, key) => {
  if (csnTarget) {
    if (csnTarget.elements) {
      if (Array.isArray(key)) {
        const [navigation, ...targetElement] = key
        const element = csnTarget.elements[navigation]
        if (element && element.isAssociation) {
          return _getElement(
            csnTarget.elements[navigation]._target,
            targetElement.length > 1 ? targetElement : targetElement[0]
          )
        } else if (element && element._isStructured) {
          return _getElement(
            csnTarget.elements[navigation],
            targetElement.length > 1 ? targetElement : targetElement[0]
          )
        }
      }
      return (
        csnTarget.elements[key] || {
          type: undefined
        }
      )
    } else if (csnTarget.params) {
      return (
        csnTarget.params[key] || {
          type: undefined
        }
      )
    }
  }

  return {
    type: undefined
  }
}

const formatVal = (val, elementName, csnTarget, kind) => {
  if (val === null || val === 'null') return 'null'
  if (typeof val === 'boolean') return val
  if (typeof val === 'number') return getSafeNumber(val)
  if (!csnTarget && typeof val === 'string' && UUID.test(val)) return kind === 'odata-v2' ? `guid'${val}'` : val
  const element = _getElement(csnTarget, elementName)
  if (kind === 'odata-v2') {
    switch (element.type) {
      case 'cds.Decimal':
      case 'cds.Integer64':
      case 'cds.Int64':
        return val
      case 'cds.Binary':
      case 'cds.LargeBinary':
        return `binary'${toBase64url(val)}'`
      case 'cds.Date':
        return element['@odata.Type'] === 'Edm.DateTimeOffset'
          ? `datetimeoffset'${val}T00:00:00'`
          : `datetime'${val}T00:00:00'`
      case 'cds.DateTime':
        return element['@odata.Type'] === 'Edm.DateTimeOffset' ? `datetimeoffset'${val}'` : `datetime'${val}'`
      case 'cds.Time':
        return `time'${_PT(val.split(':'))}'`
      case 'cds.Timestamp':
        return element['@odata.Type'] === 'Edm.DateTime' ? `datetime'${val}'` : `datetimeoffset'${val}'`
      case 'cds.UUID':
        return `guid'${val}'`
      default:
        return `'${val}'`
    }
  } else {
    switch (element.type) {
      case 'cds.Binary':
      case 'cds.LargeBinary':
        return `binary'${toBase64url(val)}'`
      case 'cds.Decimal':
      case 'cds.Integer64':
      case 'cds.Int64':
      case 'cds.Boolean':
      case 'cds.DateTime':
      case 'cds.Date':
      case 'cds.Timestamp':
      case 'cds.Time':
      case 'cds.UUID':
        return val
      default:
        return _isTimestamp(val) ? val : `'${val}'` // Why are we checking strings for timestamps? --> expensive
    }
  }
}

const skipToken = (token, cqn) => {
  const LOG = cds.log('odata')
  if (isNaN(token)) {
    let decoded
    try {
      decoded = JSON.parse(Buffer.from(token, 'base64').toString())
    } catch (err) {
      LOG.warn('$skiptoken is not in expected format. Ignoring it.')
      return
    }
    const xprs = decoded.c.map(() => [])

    for (let i = 0; i < xprs.length; i++) {
      const { k, v, a } = decoded.c[i]
      const ref = { ref: [k] }
      const val = { val: v }

      if (i > 0) xprs[i].push('and')
      xprs[i].push(ref, a ? '>' : '<', val)

      for (let j = i + 1; j < xprs.length; j++) {
        if (i > 0) xprs[j].push('and')
        xprs[j].push(ref, '=', val)
      }
    }

    const xpr = []
    for (let i = 0; i < xprs.length; i++) {
      if (i > 0) xpr.push('or')
      xpr.push(...xprs[i])
    }

    if (cqn.SELECT.where) {
      cqn.SELECT.where = [{ xpr: [ ...cqn.SELECT.where]}, 'and', { xpr }]
    } else {
      cqn.SELECT.where = [{ xpr }]
    }

    if (cds.context?.http.req.query.$top) {
      const top = parseInt(cds.context?.http.req.query.$top)
      if (top - decoded.r < cqn.SELECT.limit.rows.val) {
        cqn.SELECT.limit.rows.val = top - decoded.r
      }
    }
  } else {
    const { limit } = cqn.SELECT
    if (!limit) {
      cqn.SELECT.limit = { offset: { val: parseInt(token) } }
    } else {
      const { offset } = limit
      cqn.SELECT.limit.offset = { val: (offset && 'val' in offset ? offset.val : offset || 0) + parseInt(token) }
    }
  }
}

module.exports = {
  getSafeNumber,
  formatVal,
  skipToken
}
