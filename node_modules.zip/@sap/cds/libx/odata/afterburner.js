const cds = require('../_runtime/cds')

const { where2obj, resolveFromSelect } = require('../_runtime/common/utils/cqn')
const { findCsnTargetFor } = require('../_runtime/common/utils/csn')

const _addKeysDeep = (keys, keysCollector, ignoreManagedBacklinks) => {
  for (const keyName in keys) {
    const key = keys[keyName]
    const foreignKey = key._foreignKey4
    if (key.isAssociation || foreignKey === 'up_' || key['@cds.api.ignore'] === true) continue

    if (ignoreManagedBacklinks && foreignKey) {
      const navigationElement = keys[foreignKey]
      if (!navigationElement.on && navigationElement._isBacklink) {
        // skip navigation elements that are backlinks
        continue
      }
    }

    if ('elements' in key) {
      _addKeysDeep(key.elements, keysCollector)
      continue
    }
    keysCollector.push(keyName)
  }
}

function _keysOf(entity, ignoreManagedBacklinks) {
  if (!entity || !entity.keys) return
  const keysCollector = []
  _addKeysDeep(entity.keys, keysCollector, ignoreManagedBacklinks)
  return keysCollector
}

function _getDefinition(definition, name, namespace) {
  return (
    (definition.definitions && definition.definitions[name]) ||
    (definition.elements && definition.elements[name]) ||
    (definition.actions && (definition.actions[name] || definition.actions[name.replace(namespace + '.', '')])) ||
    definition[name]
  )
}

function _resolveAliasInParams(params, entity) {
  if (!entity._alias2ref) return
  const paramKeys = Object.keys(params)
  for (const paramKey of paramKeys) {
    if (entity._alias2ref[paramKey]) {
      params[entity._alias2ref[paramKey].join('_')] = params[paramKey]
      params[paramKey] = undefined
    }
  }
}

function _resolveAliasesInRef(ref, target) {
  if (ref.length === 1) {
    if (target.keys[ref[0]]) return ref
    if (target._alias2ref && target._alias2ref[ref[0]]) return [...target._alias2ref[ref[0]]]
  }
  for (const seg of ref) {
    target = target.elements[seg.id || seg]
    if (!target) return ref
    if (target.isAssociation) {
      target = target._target
      if (seg.where) _resolveAliasesInXpr(seg.where, target)
    }
  }
  return ref
}

function _resolveAliasesInXpr(xpr, target) {
  if (!target || !xpr) return
  for (const el of xpr) {
    if (el.xpr) _resolveAliasesInXpr(el.xpr, target)
    if (el.args) _resolveAliasesInXpr(el.args, target)
    if (el.ref) el.ref = _resolveAliasesInRef(el.ref, target)
  }
}

function _resolveAliasesInNavigation(cqn, target) {
  if (!target || !cqn) return
  if (cqn.SELECT.from.SELECT) _resolveAliasesInNavigation(cqn.SELECT.from, target)
  if (cqn.SELECT.where) _resolveAliasesInXpr(cqn.SELECT.where, target)
  if (cqn.SELECT.having) _resolveAliasesInXpr(cqn.SELECT.having, target)
}

function _addDefaultParams(ref, view) {
  const params = view.params
  const defaults = params && Object.values(params).filter(p => p.default)
  if (defaults && defaults.length > 0) {
    if (!ref.where) ref.where = []
    for (const def of defaults) {
      if (ref.where.find(e => e.ref && e.ref[0] === def.name)) {
        continue
      }
      if (ref.where.length > 0) ref.where.push('and')
      ref.where.push({ ref: [def.name] }, '=', { val: def.default.val })
    }
  }
}

// case: single key without name, e.g., Foo(1)
function addRefToWhereIfNecessary(where, entity) {
  if (!where || where.length !== 1) return 0

  const isView = !!entity.params

  const keys = isView ? Object.keys(entity.params) : _keysOf(entity)
  if (keys.length !== 1) return 0
  where.unshift(...[{ ref: [keys[0]] }, '='])
  return 1
}

function getResolvedElement(entity, { ref }) {
  const element = entity.elements[ref[0]]
  if (element && element.isAssociation && ref.length > 1) {
    return getResolvedElement(element._target, { ref: ref.slice(1) })
  } else if (element && element._isStructured) {
    return getResolvedElement(element, { ref: ref.slice(1) })
  }

  return element
}

function _processWhere(where, entity) {
  for (let i = 0; i < where.length; i++) {
    const ref = where[i]
    const val = where[i + 2]

    if (ref === '(' || ref === ')' || ref === 'and' || ref === 'or' || ref === 'not' || val === 'not' || ref.func) {
      continue
    }
    if (ref.xpr) {
      _processWhere(ref.xpr, entity)
      continue
    }

    let valIndex = -1
    let refIndex = -1
    if (typeof val === 'object') {
      if (val.val !== undefined) valIndex = i + 2
      if (val.ref != undefined) refIndex = i + 2
    }
    if (typeof ref === 'object') {
      if (ref.val !== undefined) valIndex = i
      if (ref.ref != undefined) refIndex = i
    }

    // no need to check ref = ref or val = val, if no ref or no val exists we can't do anything
    if (valIndex === refIndex || valIndex === -1 || refIndex == -1) continue

    const realRef = where[refIndex]
    const element = getResolvedElement(entity, realRef)

    if (element) {
      i += 2
      where[valIndex].val = _convertVal(element, where[valIndex].val)
    }
  }
}

function _convertVal(element, value) {
  if (value === null) return value
  switch (element._type) {
    case 'cds.Integer':
    case 'cds.UInt8':
    case 'cds.Int16':
    case 'cds.Int32':
      // eslint-disable-next-line no-case-declarations
      const n = Number(value)
      if (Number.isSafeInteger(n)) return n
      throw new Error('Not a valid integer') // TODO

    case 'cds.String':
    case 'cds.LargeString':
    case 'cds.Decimal':
    case 'cds.DecimalFloat':
    case 'cds.Double':
    case 'cds.Int64':
    case 'cds.Integer64':
      if (typeof value === 'string') return value
      return String(value)

    case 'cds.Boolean':
      return typeof value === 'string' ? value === 'true' : value

    default:
      return value
  }
}

function _processSegments(from, model, namespace, cqn) {
  const { ref } = from

  let current = model
  let path
  let keys = null
  let keyCount = 0
  let incompleteKeys = false
  let one
  let target
  for (let i = 0; i < ref.length; i++) {
    const seg = ref[i].id || ref[i]
    const whereRef = ref[i].where
    let params = whereRef && where2obj(whereRef)

    if (incompleteKeys) {
      // > key
      keys = keys || _keysOf(current, cds.env.features.odata_new_parser) // if odata, skip backlinks as key as they are used from structure
      let key = keys[keyCount++]
      one = true
      const element = current.elements[key]
      let base = ref[i - keyCount]
      if (!base.id) base = { id: base, where: [] }
      if (base.where.length) base.where.push('and')

      if (ref[i].id) {
        // > fix case key value parsed to collection with filter
        const val = `${ref[i].id}(${Object.keys(params)
          .map(k => `${k}='${params[k]}'`)
          .join(',')})`
        base.where.push({ ref: [key] }, '=', { val })
      } else {
        const val = _convertVal(element, seg)
        base.where.push({ ref: [key] }, '=', { val })
      }
      ref[i] = null
      ref[i - keyCount] = base
      incompleteKeys = keyCount < keys.length
    } else {
      // > entity or property (incl. nested) or navigation or action or function
      keys = null
      keyCount = 0
      one = false

      path = path ? path + `${path.match(/:/) ? '.' : ':'}${seg}` : seg
      // REVISIT: replace use case: <namespace>.<entity>_history is at <namespace>.<entity>.history
      current = _getDefinition(current, seg, namespace) || _getDefinition(current, seg.replace(/_/g, '.'), namespace)
      // REVISIT: 404 or 400?
      if (!current) cds.error(`Invalid resource path "${path}"`, { code: 404 })

      if (current.params && current.kind === 'entity') {
        // > View with params
        target = current
        if (whereRef) {
          keyCount += addRefToWhereIfNecessary(ref[i].where, current)
          _resolveAliasesInXpr(ref[i].where, current)
          _resolveAliasInParams(params, current)
          _processWhere(ref[i].where, current)
        }

        _addDefaultParams(ref[i], current)
        if ((!params || !Object.keys(params).length) && ref[i].where) params = where2obj(ref[i].where)

        _checkAllKeysProvided(params, current)

        ref[i].args = {}

        const where = ref[i].where
        for (let j = 0; j < where.length; j++) {
          const whereElement = where[j]
          if (whereElement === 'and' || !whereElement.ref) continue
          ref[i].args[whereElement.ref[0]] = where[j + 2]
          j += 2
        }
        ref[i].where = undefined
        if (ref[i + 1] !== 'Set') {
          // /Set is missing
          throw cds.error(`Invalid call to "${current.name}". You need to navigate to Set`, { status: 400, code: 400 })
        }
        ref[++i] = null
      } else if (current.kind === 'entity') {
        // > entity
        target = current
        one = !!(ref[i].where || current._isSingleton)

        let action
        if (current.actions) {
          const nextRef = typeof ref[i + 1] === 'string' && ref[i + 1]
          const shortName = nextRef && nextRef.replace(namespace + '.', '')
          action = shortName && current.actions[shortName]
        }

        incompleteKeys = ref[i].where ? false : i === ref.length - 1 || one ? false : true

        if (incompleteKeys && action) {
          if (
            action['@cds.odata.bindingparameter.collection'] ||
            (action.params && Object.values(action.params).some(e => e?.items?.type === '$self'))
          ) {
            incompleteKeys = false
          } else {
            const msg = `"${action.name}" must be called on a single instance of "${current.name}".`
            throw Object.assign(new Error(msg), { statusCode: 400 })
          }
        }

        if (whereRef) {
          keyCount += addRefToWhereIfNecessary(whereRef, current)
          _resolveAliasesInXpr(whereRef, current)
          _resolveAliasInParams(params, current)
          // in case of Foo(1), params will be {} (before addRefToWhereIfNecessary was called)
          if (!Object.keys(params).length) params = where2obj(ref[i].where)
          _processWhere(ref[i].where, current)
          _checkAllKeysProvided(params, current)
        }
      } else if ({ action: 1, function: 1 }[current.kind]) {
        // > action or function
        if (current.kind === 'action' && ref && ref[ref.length - 1]?.where?.length === 0) {
          const msg = `Round brackets (parentheses) are not allowed for action calls.`
          throw Object.assign(new Error(msg), { statusCode: 400 })
        }

        if (i !== ref.length - 1) {
          const msg = `${i ? 'Unbound' : 'Bound'} ${current.kind} are only supported as the last path segment.`
          throw Object.assign(new Error(msg), { statusCode: 501 })
        }
        ref[i] = { operation: current.name }
        if (params) ref[i].args = params
        if (current.returns && current.returns._type) one = true
      } else if (current.isAssociation) {
        // > navigation
        one = !!(current.is2one || ref[i].where)
        incompleteKeys = one || i === ref.length - 1 ? false : true
        current = model.definitions[current.target]
        target = current
        if (ref[i].where) {
          keyCount += addRefToWhereIfNecessary(ref[i].where, current)
          _resolveAliasesInXpr(ref[i].where, current)
          _processWhere(ref[i].where, current)
        }
      } else {
        // > property
        // we do not support navigations from properties yet
        one = true
        // if the last segment is a property, it must be removed and pushed to columns
        target = target || _getDefinition(model, ref[0].id, namespace)
        if (Object.keys(target.elements).includes(current.name)) {
          if (!cqn.SELECT.columns) cqn.SELECT.columns = []
          cqn.SELECT.columns.push({ ref: ref.slice(i) })
          // we need the keys to generate the correct @odata.context
          for (const key in target.keys || {}) {
            if (key !== 'IsActiveEntity' && !cqn.SELECT.columns.some(c => c.ref?.[0] === key))
              cqn.SELECT.columns.push({ ref: [key] })
          }
          Object.defineProperty(cqn, '_propertyAccess', { value: current.name, enumerable: false })
          from.ref.splice(i)
          break
        }
      }
    }
  }

  if (incompleteKeys) {
    // > last segment not fully qualified
    throw Object.assign(
      new Error(
        `Entity "${current.name}" has ${_keysOf(current).length} keys. Only ${keyCount} ${
          keyCount === 1 ? 'was' : 'were'
        } provided.`
      ),
      { status: 400 }
    )
  }

  // remove all nulled refs
  from.ref = ref.filter(r => r)

  return { one, current, target }
}

const AGGREGATION_DEFAULT = '@Aggregation.default'

function _addKeys(columns, target) {
  let hasAggregatedColumn = false,
    hasStarColumn = false
  for (let k = 0; k < columns.length; k++) {
    if (columns[k] === '*') hasStarColumn = true
    else if (columns[k].func || columns[k].func === null) hasAggregatedColumn = true
    // Add keys to (sub-)expands
    else if (columns[k].expand && columns[k].expand[0] !== '*')
      _addKeys(columns[k].expand, target.elements[columns[k].ref]._target)
  }

  // Don't add keys to queries with calculated properties, especially aggregations
  // REVISIT Clarify if keys should be added for queries containing non-aggregating func columns
  if (hasAggregatedColumn) return

  if (hasStarColumn) return

  const keys = _keysOf(target)

  for (const key of keys) {
    if (!columns.some(c => (typeof c === 'string' ? c === key : c.ref?.[0] === key))) columns.push({ ref: [key] })
  }
}

function _processColumns(cqn, target) {
  if (cqn.SELECT.from.SELECT) _processColumns(cqn.SELECT.from, target)

  const columns = cqn.SELECT.columns

  // REVISIT Keys should be added only in case of odata, not e.g. rest.
  // Currently odata is detected via odata_new_parser flag -> find a better indicator.
  if (columns && !cqn.SELECT.groupBy && cds.env.features.odata_new_parser) {
    let entity
    if (target.kind === 'entity') entity = target
    else if (target.kind === 'action' && target.returns?.kind === 'entity') entity = target.returns
    if (!entity) return

    _addKeys(columns, entity)
  }

  if (!Array.isArray(columns)) return

  let aggrProp, aggrElem
  for (let i = 0; i < columns.length; i++) {
    if (
      columns[i].func === null &&
      columns[i].args &&
      columns[i].args.length &&
      columns[i].args[0].ref &&
      columns[i].args[0].ref.length
    ) {
      // REVISIT: also support aggregate(Sales/Amount)?
      aggrProp = columns[i].args[0].ref[0]
      aggrElem = target.elements[aggrProp]
      if (
        aggrElem &&
        target[`@Aggregation.CustomAggregate#${aggrProp}`] &&
        aggrElem[AGGREGATION_DEFAULT] &&
        aggrElem[AGGREGATION_DEFAULT]['#']
      ) {
        columns[i].func = aggrElem[AGGREGATION_DEFAULT]['#'].toLowerCase()
        columns[i].as = columns[i].as || aggrProp
      } else throw new Error(`Default aggregation for property '${aggrProp}' not found.`)
    }
  }
}

const _checkAllKeysProvided = (params, entity) => {
  let keysOfEntity
  const isView = !!entity.params
  if (isView) {
    // view with params
    if (params === undefined) {
      throw cds.error(`Invalid call to "${entity.name}". You need to navigate to Set`, { status: 400, code: 400 })
    } else if (Object.keys(params).length === 0) {
      throw new Error('KEY_EXPECTED')
    }

    keysOfEntity = Object.keys(entity.params)
  } else {
    keysOfEntity = _keysOf(entity)
  }

  if (!keysOfEntity) return
  for (const keyOfEntity of keysOfEntity) {
    if (!(keyOfEntity in params)) {
      if (isView && entity.params[keyOfEntity].default) {
        // will be added later?
        continue
      }

      throw Object.assign(
        new Error(
          `${isView ? 'Parameter' : 'Key'} "${keyOfEntity}" is missing for ${isView ? 'view' : 'entity'} "${
            entity.name
          }"`
        ),
        { status: 400 }
      )
    }
  }
}

function _4service(service) {
  const { namespace, model } = service
  if (!model) return cqn => cqn

  return cqn => {
    const from = resolveFromSelect(cqn)
    const { ref } = from

    // REVISIT: shouldn't be necessary
    // Second findCsnTargetFor is required for concat query, where the root is already identified with the first query
    // and subsequent queries already have correct root
    /*
     * make first path segment fully qualified
     */
    const root =
      findCsnTargetFor(ref[0].id || ref[0], model, namespace) ||
      findCsnTargetFor(
        ref[0].id?.split('.')[ref[0].id?.split('.').length - 1] || ref[0].split('.')[ref[0].split('.').length - 1],
        model,
        namespace
      )
    // REVISIT: 404 or 400?
    if (!root) cds.error(`Invalid resource path "${namespace}.${ref[0].id || ref[0]}"`, { code: 404 })
    if (ref[0].id) ref[0].id = root.name
    else ref[0] = root.name

    /*
     * key vs. path segments (/Books/1/author/books/2/...) and more
     */
    const { one, current, target } = _processSegments(from, model, namespace, cqn)

    if (cqn.SELECT.where) {
      _processWhere(cqn.SELECT.where, root)
    }

    // one?
    if (one) cqn.SELECT.one = true

    // REVISIT: better
    // set target (csn definition) for later retrieval
    cqn.__target = current

    // target <=> endpoint entity, all navigation refs must be resolvable accordingly
    if (cds.env.effective.odata.structs) _resolveAliasesInNavigation(cqn, target)

    /*
     * add default aggregation function (and alias)
     */
    _processColumns(cqn, cqn.__target)

    return cqn
  }
}

const cache = new WeakMap()

module.exports = {
  for: service => {
    if (!cache.has(service)) cache.set(service, _4service(service))
    return cache.get(service)
  },
  addRefToWhereIfNecessary
}
