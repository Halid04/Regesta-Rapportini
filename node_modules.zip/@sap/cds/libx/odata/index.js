const cds = require('../_runtime/cds'),
  { decodeURIComponent } = cds.utils
const { SELECT } = cds.ql

const odata2cqn = require('./parser').parse
const cqn2odata = require('./cqn2odata')

const afterburner = require('./afterburner')
const { getSafeNumber: safeNumber } = require('./utils')
const getError = require('../_runtime/common/error')

const strict = {
  functions: {
    contains: 1,
    startswith: 1,
    endswith: 1,
    tolower: 1,
    toupper: 1,
    length: 1,
    indexof: 1,
    substring: 1,
    trim: 1,
    concat: 1,
    year: 1,
    month: 1,
    day: 1,
    hour: 1,
    minute: 1,
    second: 1,
    time: 1,
    now: 1
  }
}

const _2query = cqn => {
  if (cqn.SELECT.from.SELECT) cqn.SELECT.from = _2query(cqn.SELECT.from)
  const query = cqn.SELECT.one ? SELECT.one(cqn.SELECT.from) : SELECT.from(cqn.SELECT.from)
  for (const prop in cqn.SELECT) {
    if (prop === 'from') continue
    // explicitly use cds.ql to get '_includes_or__' magic for cqn.SELECT.where containing 'or'
    if (prop === 'where' || prop === 'having') query[prop](cqn.SELECT[prop])
    else query.SELECT[prop] = cqn.SELECT[prop]
  }
  return query
}

const enhanceCqn = (cqn, options) => {
  if (options.afterburner) cqn = options.afterburner(cqn)

  const query = _2query(cqn)

  // REVISIT: _target vs __target, i.e., pseudo csn vs actual csn
  // DO NOT USE __target outside of libx/rest!!!
  if (cqn.__target) query.__target = cqn.__target
  if (cqn._propertyAccess)
    Object.defineProperty(query, '_propertyAccess', { value: cqn._propertyAccess, enumerable: false })
  return query
}

/*
 * cds.odata API
 */
module.exports = {
  parse: (url, options = {}) => {
    // first arg may also be req
    if (url.url) url = url.url
    // REVISIT: for okra, remove when no longer needed
    else if (url.getIncomingRequest) url = url.getIncomingRequest().url

    url = decodeURIComponent(url) // REVISIT: do we need that?

    options = options === 'strict' ? { strict } : options.strict ? { ...options, strict } : options
    if (options.service) Object.assign(options, { minimal: true, afterburner: afterburner.for(options.service) })
    options.safeNumber = safeNumber
    options.skipToken = require('./utils').skipToken

    let cqn
    try {
      cqn = odata2cqn(url, options)
    } catch (err) {
      if (err.statusCode === 501) {
        throw getError(err.statusCode, err.message)
      }

      let offset = err.location && err.location.start.offset
      if (options.baseUrl) {
        // we need to add the number of chars from base url to the offset
        offset += options.baseUrl.length
      }

      // TODO adjust this to behave like above
      err.message = `Parsing URL failed at position ${offset}: ${err.message}`
      err.statusCode = err.statusCode || 400
      throw err
    }

    //cqn is an array, if concat is used
    if (Array.isArray(cqn)) {
      for (let i = 0; i < cqn.length; i++) {
        cqn[i] = enhanceCqn(cqn[i], options)
      }
    } else {
      cqn = enhanceCqn(cqn, options)
    }

    return cqn
  },

  urlify: (cqn, options = {}) => {
    return cqn2odata(cqn, options)
  }
}
