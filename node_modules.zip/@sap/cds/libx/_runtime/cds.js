/** @type {import('../../lib')} */
const cds = require('../../lib')
module.exports = cds

/*
 * csn aspects
 */
const { any, entity, Association } = cds.builtin.classes
cds.extend(any).with(require('./common/aspects/any'))
cds.extend(Association).with(require('./common/aspects/Association'))
cds.extend(entity).with(require('./common/aspects/entity'))
