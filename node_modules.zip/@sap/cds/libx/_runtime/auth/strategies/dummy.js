const cds = require('../../cds')

class DummyStrategy {
  constructor() {
    this.name = 'dummy'
  }

  authenticate() {
    const user = new cds.User.Privileged()
    this.success(user)
  }
}

module.exports = DummyStrategy
