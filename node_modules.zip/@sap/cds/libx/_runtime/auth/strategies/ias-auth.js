const cds = require('../../../../lib')
const _require = require('../../common/utils/require')
// _require for better error message
const express = _require('express')
const passport = _require('passport')
const { JWTStrategy } = _require('@sap/xssec')
const LOG = cds.log('auth')

const RESERVED_ATTRIBUTES = new Set([
  'aud',
  'azp',
  'exp',
  'ext_attr',
  'iat',
  'ias_iss',
  'iss',
  'jti',
  'sub',
  'user_uuid',
  'zone_uuid',
  'zid'
])

module.exports = function ias_auth(config) {
  // warn if no credentials
  if (!config.credentials) {
    LOG._warn &&
      LOG.warn(`
       No IAS instance bound to application, but "${config.kind}" configured.
       This is NOT recommended in production!
       `)

    return (req, res, next) => next()
  }

  passport.use('IAS', new JWTStrategy(config.credentials))
  return express
    .Router()
    .use(passport.authenticate('IAS', { session: false, failWithError: true }))
    .use((req, res, next) => {
      // grant_type === client_credentials or x509
      if (req.tokenInfo.getClientId() === req.tokenInfo.getSubject()) {
        req.user = new cds.User({
          id: 'system',
          roles: ['authenticated-user'],
          attr: {}
        })
        req.user._is_system = true
      } else {
        // add all unknown attributes to req.user.attr in order to keep public API small
        const payload = req.tokenInfo.getPayload()
        const attributes = Object.keys(payload)
          .filter(k => !RESERVED_ATTRIBUTES.has(k))
          .reduce((attrs, k) => {
            attrs[k] = payload[k]
            return attrs
          }, {})

        req.user = new cds.User({
          id: req.user.id,
          roles: ['authenticated-user'],
          attr: attributes
        })
      }

      req.tenant = req.tokenInfo.getZoneId()
      next()
    })
    .use((err, req, res, _next) => {
      if (req.tokenInfo) {
        LOG?.debug('error during token validation', req.tokenInfo.getErrorObject())
      }
      // REVISIT: reject request immediately as our other auth strategies do
      // should we call next(err)? -> I don't think so; it's not an error, is it?
      res.status(401).json({ code: '401', message: 'Unauthorized' }) // REVISIT: this is OData style?
    })
}
