const UNAUTHORIZED = { statusCode: 401, code: '401', message: 'Unauthorized' }
const FORBIDDEN = { statusCode: 403, code: '403', message: 'Forbidden' }

const getRequiresAsArray = definition => {
  const requires = definition['@requires']
  if (requires) return Array.isArray(requires) ? requires : [requires]
}

const isRestricted = srv => {
  if (srv.definition['@requires']) return true

  const entities = srv.entities
  const entitiesKeys = Object.keys(entities)

  return !!(
    entitiesKeys.some(entity => entities[entity]['@requires'] || entities[entity]['@restrict']) ||
    entitiesKeys.some(entity => {
      const actions = entities[entity].actions
      actions && Object.keys(actions).some(action => actions[action]['@requires'] || actions[action]['@restrict'])
    }) ||
    Object.keys(srv.operations).some(
      operation => srv.operations[operation]['@requires'] || srv.operations[operation]['@restrict']
    )
  )
}

module.exports = {
  UNAUTHORIZED,
  FORBIDDEN,
  getRequiresAsArray,
  isRestricted
}
