const cds = require('../cds')
const LOG = cds.log()

const _require = require('../common/utils/require')
const { UNAUTHORIZED, FORBIDDEN, isRestricted } = require('./utils')

let passport, logged

// strategy initializers for lazy loading of dependencies
const _initializers = {
  // REVISIT: support basic authentication?
  basic: ({ credentials }) => {
    const BasicStrategy = require('./strategies/basic')
    passport.use(new BasicStrategy(credentials))
  },
  dummy: () => {
    const DummyStrategy = require('./strategies/dummy')
    passport.use(new DummyStrategy())
  },
  jwt: ({ credentials, uaa }) => {
    const JWTStrategy = require('./strategies/JWT')
    if (credentials) {
      passport.use(new JWTStrategy(credentials))
    } else if (uaa) {
      // REVISIT: compat, remove with cds^6
      passport.use(new JWTStrategy(uaa.credentials))
    } else {
      throw Object.assign(new Error('No or malformed credentials for auth kind "jwt-auth"'), { credentials })
    }
  },
  mock: ({ users }, srvName) => {
    const MockStrategy = require('./strategies/mock')
    passport.use(new MockStrategy(users, `mock_${srvName}`))
  },
  xsuaa: ({ credentials, uaa }) => {
    const XSUAAStrategy = require('./strategies/xsuaa')
    if (credentials) {
      passport.use(new XSUAAStrategy(credentials))
    } else if (uaa) {
      // REVISIT: compat, remove with cds^6
      passport.use(new XSUAAStrategy(uaa.credentials))
    } else {
      throw Object.assign(
        new Error('No or malformed credentials for auth kind "xsuaa". Make sure to bind the app to an "xsuaa" service'),
        { credentials }
      )
    }
  }
}

// map for initialized authenticators
const _authenticators = {}

const _log = (req, challenges) => {
  if (!LOG._debug) return
  const challengesLog = challenges ? ['User challenges:', challenges] : []
  LOG.debug(`User "${req.user.id}" request URL`, req.url, '\n', ...challengesLog)
}

const cap_auth_callback = (req, res, next, internalError, user, challenges) => {
  // An internal error occurs during the authentication process
  if (internalError) {
    // REVISIT: What to do? Security log?
    return res.status(401).json(UNAUTHORIZED) // no details to client
  }

  let infoChallenges

  if (challenges) {
    if (Array.isArray(challenges)) {
      infoChallenges = challenges.filter(ele => ele)
      infoChallenges = infoChallenges.length ? infoChallenges : undefined
    } else {
      req.authInfo = challenges
    }
  }

  req.user = user || Object.defineProperty(new cds.User(), '_challenges', { enumerable: false, value: infoChallenges })
  Object.defineProperty(req.user, '_req', { enumerable: false, value: req })
  _log(req, infoChallenges)
  next()
}

const _mountCustomAuth = (srv, app, config) => {
  const impl = cds.resolve(config.impl)
  app.use(_require(impl))
}

const _mountMockAuth = (srv, app, strategy, config) => {
  const impl =
    strategy === 'dummy'
      ? new (require('./strategies/dummy'))()
      : new (require('./strategies/mock'))(config, `mock_${srv.name}`)

  app.use(function cap_auth(req, res, next) {
    let user, challenge
    impl.success = arg => (user = arg)
    impl.fail = arg => (challenge = arg)
    impl.authenticate(req)
    cap_auth_callback(req, res, next, undefined, user, [challenge])
  })
}

const _mountPassportAuth = (srv, app, strategy, config) => {
  if (!config.credentials)
    return (
      LOG._warn &&
      LOG.warn(`
    No XSUAA instance bound to application, but "${config.strategy}" configured.
    This is NOT recommended in production!
  `)
    )
  if (!passport) passport = _require('passport')

  // initialize strategy
  if (!_authenticators[strategy] || process.env.NODE_ENV === 'test') {
    _initializers[strategy](config, srv.name)
    _authenticators[strategy] = true
  }

  // authenticate
  app.use(passport.initialize())
  app.use((req, res, next) => {
    const options = { session: false, failWithError: true }
    const callback = cap_auth_callback.bind(undefined, req, res, next)
    passport.authenticate(strategy === 'jwt' ? 'JWT' : strategy, options, callback)(req, res, next)
  })
}

/*
 * export authentication middleware
 */
// eslint-disable-next-line complexity
module.exports = (srv, options = srv.options) => {
  const handlers = [],
    app = { use: h => handlers.push(h) }
  // NOTE: options.auth is not an official API
  let config = 'auth' in options ? options.auth : cds.env.requires.auth
  if (!config) {
    if (cds.requires.db && cds.requires.multitenancy) {
      process.exitCode = 1 // REVISIT: why exitCode needed?
      throw new Error('Authentication required for multitenancy')
    }
    if (isRestricted(srv)) {
      process.exitCode = 1 // REVISIT: why exitCode needed?
      throw new Error('Authentication required for authorization checks')
    }
    if (process.env.NODE_ENV !== 'production' && !logged) {
      LOG._warn && LOG.warn(`No authentication configured. This is not recommended in production.`)
    }
    // no auth wanted > return
    return handlers
  }

  // cds.env.requires.auth = { kind: 'xsuaa-auth' } was briefly documented on capire -> also support
  if (config.kind === 'xsuaa-auth' && !config.credentials) config = cds.env.requires.xsuaa

  // mount authentication middleware or strategy
  if (!logged) LOG._debug && LOG.debug(`Using authentication`, { kind: config.kind })

  // Security by default: set restrict_all_services if not disabled
  // this is done dynamically to also cover custom auth impl
  if (process.env.NODE_ENV === 'production' && config.restrict_all_services !== false) {
    config.restrict_all_services = true
  }

  if (config.impl) {
    // mount custom authentication middleware
    _mountCustomAuth(srv, app, config)
  } else if (config.kind === 'ias-auth') {
    // ias-auth follows the new implementation pattern for auth middlewares
    const iasAuth = require('./strategies/ias-auth')(config)
    if (iasAuth) app.use(iasAuth)
  } else {
    // mount our authentication strategies (legacy style)
    const strategy = _strategy4(config)
    if (strategy in { dummy: 1, mock: 1 }) {
      _mountMockAuth(srv, app, strategy, config)
    } else {
      _mountPassportAuth(srv, app, strategy, config)
    }
  }

  // Security by default: enforce authenticated users in production if auth service bound
  if (
    cds.requires.multitenancy ||
    (process.env.NODE_ENV === 'production' && config.credentials && config.restrict_all_services)
  ) {
    if (!logged) LOG._debug && LOG.debug(`Enforcing authenticated users for all services`)
    app.use(cap_enforce_login)
  }

  // so we don't log the same stuff multiple times
  logged = true
  return handlers
}

const _strategy4 = config => {
  const strategy = config.strategy ? config.strategy.toLowerCase() : config.kind.replace('-auth', '')
  if (strategy === 'mocked') return 'mock'
  if (strategy in _initializers) return strategy
  process.exitCode = 1 // REVISIT: why exitCode needed?
  throw new Error(`Authentication kind "${config.kind}" is not supported`)
}

const cap_enforce_login = (req, res, next) => {
  if (req.user && req.user.is('authenticated-user')) return next() // pass if user is authenticated
  if (!req.user || req.user._is_anonymous) {
    if (req.user && req.user._challenges) res.set('WWW-Authenticate', req.user._challenges.join(';'))
    return res.status(401).json(UNAUTHORIZED) // no details to client // REVISIT: security log in else case?
  } else {
    return res.status(403).json(FORBIDDEN) // no details to client // REVISIT: security log?
  }
}
