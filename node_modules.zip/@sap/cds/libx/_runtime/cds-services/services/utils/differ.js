const cds = require('../../../cds')
const { SELECT } = cds.ql

const { compareJson } = require('./compareJson')
const { selectDeepUpdateData } = require('../../../common/composition')
const { ensureDraftsSuffix } = require('../../../fiori/utils/handler')

const { DRAFT_COLUMNS_MAP } = require('../../../common/constants/draft')
const { cqn2cqn4sql, convertPathExpressionToWhere } = require('../../../common/utils/cqn2cqn4sql')
const { revertData } = require('../../../common/utils/resolveView')
const { removeIsActiveEntityRecursively } = require('../../../fiori/utils/where')

module.exports = class Differ {
  constructor(srv) {
    this._srv = srv
  }

  _createSelectColumnsForDelete(entity) {
    const columns = []
    for (const element of Object.values(entity.elements)) {
      // Don't take into account virtual or computed properties to make the diff result
      // consistent with the ones for UPDATE/CREATE (where we don't have access to that
      // information).
      if (!element.key && (element.virtual || element['@Core.Computed'])) continue
      if (element.isComposition) {
        if (element._target._hasPersistenceSkip) continue
        columns.push({
          ref: [element.name],
          expand: this._createSelectColumnsForDelete(element._target)
        })
      } else if (!element._isAssociationStrict && !(element.name in DRAFT_COLUMNS_MAP)) {
        columns.push({ ref: [element.name] })
      }
    }

    return columns
  }

  _diffDelete(req) {
    const { DELETE } = (req._ && req._.query) || req.query
    const query = SELECT.from(DELETE.from).columns(this._createSelectColumnsForDelete(req.target))
    if (DELETE.where) query.where(DELETE.where)

    return cds
      .tx(req)
      .run(query)
      .then(dbState => compareJson(undefined, dbState, req.target, { ignoreDraftColumns: true }))
  }

  async _addPartialPersistentState(req) {
    // REVISIT: cds.context.model?
    const deepUpdateData = await selectDeepUpdateData(this._srv, this._srv.model, req, true)
    req._.partialPersistentState = deepUpdateData
  }

  async _diffUpdate(req, providedData) {
    if (cds.db) await this._addPartialPersistentState(req)
    const newQuery = cqn2cqn4sql(req.query, this._srv.model)
    const combinedData = providedData || Object.assign({}, req.query.UPDATE.data || {}, req.query.UPDATE.with || {})
    const lastTransition = newQuery.UPDATE._transitions[newQuery.UPDATE._transitions.length - 1]
    const revertedPersistent = revertData(req._.partialPersistentState, lastTransition, this._srv)
    return compareJson(combinedData, revertedPersistent, req.target, { ignoreDraftColumns: true })
  }

  async _diffPatch(req, providedData) {
    if (cds.db) {
      const { target, alias, where = [] } = convertPathExpressionToWhere(req.query.UPDATE.entity, this._srv.model, {})

      const draftRef = { ref: [ensureDraftsSuffix(target)], as: alias }

      // SELECT because req.query in custom handler does not have access to _drafts
      req._.partialPersistentState = await cds
        .tx(req)
        .run(SELECT.from(draftRef).where(removeIsActiveEntityRecursively(where)).limit(1))

      return compareJson(providedData || req.data, req._.partialPersistentState, req.target, {
        ignoreDraftColumns: true
      })
    }
  }

  _diffCreate(req, providedData) {
    const originalData =
      providedData || (req.query.INSERT.entries && req.query.INSERT.entries.length === 1)
        ? req.query.INSERT.entries[0]
        : req.query.INSERT.entries

    return compareJson(originalData, undefined, req.target, { ignoreDraftColumns: true })
  }

  async calculate(req, providedData) {
    if (req.event === 'CREATE') return this._diffCreate(req, providedData)
    if (req.target._hasPersistenceSkip) return
    if (req.event === 'DELETE') return this._diffDelete(req)
    if (req.event === 'UPDATE') return this._diffUpdate(req, providedData)
    if (req.event === 'PATCH') return this._diffPatch(req, providedData)
  }

  // is used as a req instance method
  static reqDiff(req = this, data) {
    const { _service: d } = req.target
    if (!d) return Promise.resolve([])
    const srv = cds.services[d.name]
    if (!srv) return Promise.resolve([])
    return new Differ(srv).calculate(req, data)
  }
}
