const cds = require('../../cds')

const { resolveView, restoreLink, findQueryTarget } = require('../../common/utils/resolveView')
const { postProcess } = require('../../common/utils/postProcessing')

const _isSimpleCqnQuery = q => typeof q === 'object' && q !== null && !Array.isArray(q) && Object.keys(q).length > 0

// for getRestrictions()
const { getNormalizedRestrictions, getApplicableRestrictions } = require('../../common/generic/auth/restrictions.js')
const WRITE_EVENTS = { CREATE: 1, NEW: 1, UPDATE: 1, PATCH: 1, DELETE: 1, CANCEL: 1, EDIT: 1 }
const CRUD = Object.assign({ READ: 1 }, WRITE_EVENTS)

/**
 * Generic Service Event Handler.
 */
class ApplicationService extends cds.Service {
  init() {
    require('../../common/generic/auth').call(this, this)
    require('../../common/generic/etag').call(this, this)
    require('../../common/generic/input').call(this, this)
    require('../../common/generic/put').call(this, this)
    require('../../common/generic/temporal').call(this, this)
    require('../../common/generic/paging').call(this, this) // > paging must be executed before sorting
    require('../../common/generic/sorting').call(this, this)

    if (cds.env.requires.extensibility?.code) require('../../common/code-ext/handlers').call(this, this)

    this.registerFioriHandlers(this)
    this.registerPersonalDataHandlers(this)
    this.registerCrudHandlers(this) // default .on handlers, have to go last
    return this
  }

  /**
   * @param serviceImpl
   * @deprecated since version 1.11.0 - use Service.prepend instead
   */
  with(serviceImpl) {
    return this.prepend(serviceImpl)
  }

  /**
   * Registers custom handlers.
   * @param {string | object | Function} serviceImpl - init function to register custom handlers.
   */
  impl(serviceImpl) {
    if (typeof serviceImpl === 'string') serviceImpl = require(serviceImpl)
    return this.prepend(serviceImpl)
  }

  registerPersonalDataHandlers() {
    return cds.env.features.audit_personal_data && require('../../audit/generic/personal').impl.call(this)
  }

  registerFioriHandlers() {
    if (cds.env.fiori.lean_draft) {
      const { onNew, onPrepare, onEdit, onCancel } = require('../../fiori/lean-draft')

      for (const each of this.entities)
        if (each.drafts) {
          this.on('NEW', each.drafts, onNew)
          this.on('EDIT', each, onEdit)
          this.on('CANCEL', each.drafts, onCancel)
          this.on('draftPrepare', each.drafts, onPrepare)
          if (cds.env.fiori.draft_compat) {
            // register after read handlers to add `IsActiveEntity`,
            // so stakeholders have access to it when calling next()

            // to check if data contains a key value
            let _key
            for (const key in each.keys) {
              if (key === 'IsActiveEntity') continue
              _key = key
              break
            }
            const _addIsActiveEntity = (data, IsActiveEntity) => {
              if (!data) return
              if (Array.isArray(data)) return data.map(d => _addIsActiveEntity(d, IsActiveEntity))
              if (_key in data) data.IsActiveEntity = IsActiveEntity
            }
            this.on('READ', each, async (req, next) => {
              const data = await next()
              _addIsActiveEntity(data, !req.target?.isDraft)
              return data
            })
          }
        }
    } else return require('../../fiori/generic').impl.call(this)
  }

  registerCrudHandlers() {
    return require('../../common/generic/crud').impl.call(this)
  }

  /**
   * Returns the applicable restrictions for the current request as follows:
   * - null: unrestricted access
   * - []: no access
   * - [{ grant: '...', to: ['...'], where: '...' }, ...]: applicable restrictions with grant normalized to strings,
   *     i.e., grant: ['CREATE', 'UPDATE'] in model becomes [{ grant: 'CREATE' }, { grant: 'UPDATE' }]
   * - Promise resovling to any of the above (needed for CAS overrides)
   *
   * @param {object} definition - then csn definition of an entity or an (un)bound action or function
   * @param {string} event - the event name
   * @param {import('../../../../lib/req/user')} user - the current user
   * @returns {Promise | Array | null}
   */
  getRestrictions(definition, event, user) {
    let restrictions = getNormalizedRestrictions(definition, this.model.definitions, event)
    if (!restrictions && (event in CRUD || !definition.parent)) {
      // > unrestricted entity or unbound
      return null
    }
    if (event in CRUD && restrictions.length && restrictions.every(r => r.grant !== '*' && !(r.grant in CRUD))) {
      // > only bounds are restricted
      return null
    }
    if (!(event in CRUD) && !restrictions && definition.parent) {
      // > bound without own restrictions -> get from parent
      restrictions = getNormalizedRestrictions(definition.parent, this.model.definitions, event)
      if (!restrictions) {
        // > unrestricted bound
        return null
      }
    }
    // return the applicable restrictions (grant and to fit to request and user)
    return getApplicableRestrictions(restrictions, event, user)
  }

  // Overload .handle in order to resolve projections up to a definition that is known by the remote service instance.
  // Result is post processed according to the inverse projection in order to reflect the correct result of the original query.
  async handle(req) {
    // compat mode
    if (req._resolved) return super.handle(req)
    if (req.target && req.target.name && req.target.name.startsWith(this.namespace + '.')) return super.handle(req)

    // req.query can be:
    // - empty object in case of unbound action/function
    // - undefined/null in case of plain string queries
    if (this.model && _isSimpleCqnQuery(req.query)) {
      const q = resolveView(req.query, this.model, this)
      const t = findQueryTarget(q) || req.target

      // compat
      restoreLink(req)
      if (req.query.SELECT && req.query.SELECT._4odata) {
        Object.defineProperty(q.SELECT, '_4odata', { value: req.query.SELECT._4odata })
      }

      // REVISIT: We need to provide target explicitly because it's cached already within ensure_target
      const newReq = new cds.Request({ query: q, target: t, _resolved: true })
      const result = await super.dispatch(newReq)

      return postProcess(q, result, this)
    }

    return super.handle(req)
  }
}

ApplicationService.prototype.isAppService = true
module.exports = ApplicationService
