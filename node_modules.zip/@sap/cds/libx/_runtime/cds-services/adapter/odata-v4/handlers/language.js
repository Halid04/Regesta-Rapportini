const localeFrom = require('../../../../../../lib/req/locale')
const { toODataResult } = require('../utils/result')

module.exports = (req, res, next) => {
  const locale = localeFrom(req.getIncomingRequest())
  next(null, toODataResult(locale))
}
