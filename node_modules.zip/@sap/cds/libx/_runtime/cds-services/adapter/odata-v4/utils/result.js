const cds = require('../../../../cds')

const { Readable } = require('stream')
const { big } = require('@sap/cds-foss')

const getTemplate = require('../../../../common/utils/template')
const templateProcessor = require('../../../../common/utils/templateProcessor')
const { omitValue, applyOmitValuesPreference } = require('./omitValues')
const { setLocationHeader } = require('./readAfterWrite')

const METADATA = {
  $context: '*@odata.context',
  $count: '*@odata.count',
  $etag: '*@odata.etag',
  $metadataEtag: '*@odata.metadataEtag',
  $bind: '*@odata.bind',
  $id: '*@odata.id',
  $delta: '*@odata.delta',
  $removed: '*@odata.removed',
  $type: '*@odata.type',
  $nextLink: '*@odata.nextLink',
  $deltaLink: '*@odata.deltaLink',
  $editLink: '*@odata.editLink',
  $readLink: '*@odata.readLink',
  $navigationLink: '*@odata.navigationLink',
  $associationLink: '*@odata.associationLink',
  $mediaEditLink: '*@odata.mediaEditLink',
  $mediaReadLink: '*@odata.mediaReadLink',
  $mediaContentType: '*@odata.mediaContentType',
  $mediaContentDispositionFilename: '*@odata.mediaContentDispositionFilename', // > not supported by okra
  $mediaContentDispositionType: '*@odata.mediaContentDispositionType', // > not supported by okra
  $mediaEtag: '*@odata.mediaEtag'
}

const _getPropertyName = req => {
  const segments = req._.odataReq.getUriInfo().getPathSegments()
  if (segments[segments.length - 1].getKind().match(/\w*\.PROPERTY$/)) {
    return segments[segments.length - 1].getProperty().getName()
  }
  if (
    segments[segments.length - 1].getKind() === 'VALUE' &&
    segments[segments.length - 2].getKind() === 'PRIMITIVE.PROPERTY'
  ) {
    return segments[segments.length - 2].getProperty().getName()
  }
}

const _cleanupMetadata = (odataResult, result, req) => {
  if (typeof result !== 'object') return odataResult
  // backwards compatibility for content-type in stream
  if ('*@odata.mediaContentType' in result) result.$mediaContentType = result['*@odata.mediaContentType']
  if ('$mediaContentDispositionFilename' in result && req) {
    const cdt = result.$mediaContentDispositionType || 'attachment'
    req._.odataRes.setHeader(
      'Content-Disposition',
      `${cdt}; filename="${encodeURIComponent(result.$mediaContentDispositionFilename)}"`
    )
  }

  const keysToCleanup = {
    // do not set "@odata.context" as it may be inherited of remote service
    $context: true,
    // REVISIT: okra doesn't support content disposition
    $mediaContentDispositionFilename: true,
    $mediaContentDispositionType: true
  }

  for (const key in METADATA) {
    if (!(key in result)) continue
    if (!keysToCleanup[key]) odataResult[METADATA[key]] = result[key]
    delete result[key]
  }

  return odataResult
}

/**
 * Convert any result to the result object structure, which is expected of odata-v4.
 *
 * @param {*} result
 * @param {*} [req]
 * @returns {string | object}
 */
const toODataResult = (result, req) => {
  if (result == null) return ''

  let propertyName, isStream, isCollection
  if (req) {
    if (cds.env.features.odata_new_parser) {
      propertyName = req._metaInfo.propertyName
      isStream = req._metaInfo.isStream
      isCollection = req._metaInfo.isCollection
    } else {
      propertyName = _getPropertyName(req)
      isStream =
        req._.odataReq.getUriInfo().getLastSegment().getProperty() &&
        req._.odataReq.getUriInfo().getLastSegment().getProperty().getType().toString() === 'Edm.Stream'

      isCollection =
        !propertyName &&
        !(req.event in { NEW: 1, CREATE: 1, UPDATE: 1, UPSERT: 1, EDIT: 1, PATCH: 1 }) &&
        req._.odataReq.getUriInfo().getLastSegment().isCollection()
    }
  }

  if (isCollection && !Array.isArray(result)) result = [result]
  else if (!isCollection && Array.isArray(result)) result = result[0]

  let value = result
  if (typeof result === 'object') {
    if ('value' in result && (result.value instanceof Readable || isStream)) value = result.value
    else if (propertyName) value = result[propertyName]
  }

  const odataResult = _cleanupMetadata({ value }, result, req)

  const { metadata } = _getOptions(req)
  if (cds.env.features.odata_new_parser && metadata !== 'none') {
    return _setContext(odataResult, req, isCollection)
  }

  return odataResult
}

const _setContext = (odataResult, req, isCollection) => {
  if (req && req._metaInfo) {
    const result = isCollection ? odataResult : odataResult.value
    if (result != null) Object.assign(result, { [METADATA.$context]: req._metaInfo.contextUrl })
  }
  return odataResult
}

const addEtags = (row, key) => {
  row['*@odata.etag'] = row[key]
}

const convertDecimal = (row, key, options) => {
  const bigValue = big(row[key])
  row[key] = options.decimals.exponential ? bigValue.toExponential() : bigValue.toFixed()
}

const addAssociationToRow = (row, foreignKey, foreignKeyElement) => {
  const assocName = foreignKeyElement._foreignKey4
  const assoc = foreignKeyElement.parent.elements[assocName]

  if (!row[assocName]) {
    row[assocName] = {}
  }

  const keyOfAssociatedEntity = foreignKey.replace(`${assocName}_`, '')

  // REVISIT: structured keys, see xtests in structured-x4
  const assocTargetKey = assoc._target.keys[keyOfAssociatedEntity]
  if (assocTargetKey && assocTargetKey._foreignKey4) {
    // assoc as key
    row[assocName][keyOfAssociatedEntity] = row[foreignKey]
    delete row[foreignKey]
    addAssociationToRow(row[assocName], keyOfAssociatedEntity, assoc._target.keys[keyOfAssociatedEntity])
    return
  }

  // foreign key null or undefined, set assoc to null
  if (row[foreignKey] == null) {
    row[assocName] = null
    delete row[foreignKey]
    return
  }

  if (row[assocName][keyOfAssociatedEntity] === undefined) {
    row[assocName][keyOfAssociatedEntity] = row[foreignKey]
  }

  delete row[foreignKey]
}

const localizeAfterDraftActivate = (row, key, locale) => {
  if (row.texts && Object.prototype.hasOwnProperty.call(row, key)) {
    const texts = row.texts.filter(t => t.locale === locale)[0]
    if (texts && texts[key]) row[key] = texts[key]
  }
}

const _processCategory = (req, category, elementInfo, options, previousResult) => {
  const { row, key, element } = elementInfo

  switch (category) {
    case '@odata.omitValues':
      omitValue(elementInfo, req, options.omitValuesPreference, previousResult)
      break

    case '@odata.etag':
      addEtags(row, key)
      break

    case '@cds.Decimal':
      if (options.decimals && row[key]) convertDecimal(row, key, options)
      break

    case 'foreignKey':
      addAssociationToRow(row, key, element)
      break

    case '@cleanup':
      if (key !== 'DraftAdministrativeData_DraftUUID') delete row[key]
      break

    case 'localizeAfterDraftActivate':
      localizeAfterDraftActivate(row, key, req.locale)
      break

    case '@cds.Boolean':
      if (row[key] != null) row[key] = !!row[key]

    // no default
  }
}

const _processorFn = (req, previousResult, options) => elementInfo => {
  const { row, key, plain } = elementInfo
  if (typeof row !== 'object' || !Object.prototype.hasOwnProperty.call(row, key)) return
  const categories = plain.categories

  for (const category of categories) {
    _processCategory(req, category, elementInfo, options, previousResult)
  }
}

const _getParent = (model, name) => {
  const target = model.definitions[name]

  if (target && target.elements) {
    for (const elementName in target.elements) {
      const element = target.elements[elementName]
      if (element._anchor && element._anchor._isContained) return element._anchor
    }
  }

  return null
}

const _isUpAssoc = element => element && /^up_(_up_)*$/.test(element.name) && _isContainedOrBackLink(element)

const _isContainedOrBackLink = element =>
  element &&
  element.isAssociation &&
  element.keys &&
  (element._isContained || (element._anchor && element._anchor._isContained))

const _assocs = (element, target) => {
  const assocName = element._foreignKey4
  const assoc = assocName && target.elements[assocName]

  if (cds.env.effective.odata.refs) {
    // expand assoc keys except of up_ backlinks
    if (assoc && !_isUpAssoc(assoc)) {
      return ['foreignKey']
    }

    if (element['@odata.containment.ignore']) {
      return ['@cleanup']
    }
  }

  if (_isContainedOrBackLink(assoc)) {
    return ['@cleanup']
  }

  return []
}

const _pick = options => (element, target) => {
  const categories = []

  if (element['@odata.etag']) categories.push('@odata.etag')
  if (element._type === 'cds.Decimal') categories.push('@cds.Decimal')
  if (cds.db?.cqn2sql && element._type === 'cds.Boolean') categories.push('@cds.Boolean') // REVISIT: violates modularization -> do we still need that?

  categories.push(..._assocs(element, target))

  // REVISIT: It makes no sense to store static values inside the template, it would just
  // blow up the memory of the template.
  // For operations concering _all_ elements, the templating mechanism doesn't make sense
  // and should not be used.
  if (options.omitValuesPreference) categories.push('@odata.omitValues')
  if (options.event === 'draftActivate' && options.locale && options.locale !== 'en' && element.localized === true) {
    categories.push('localizeAfterDraftActivate')
  }

  if (categories.length) return { categories }
}

const _getOptions = req => {
  if (!req) return {}
  const { headers, locale, event } = req
  const options = {
    decimals: null,
    omitValuesPreference: null,
    locale,
    event,
    metadata: 'minimal'
  }

  if (!headers) return options

  // REVISIT: options ie headers are not used in _pick since its cached
  // consequently, all decimals are always picked even w/o these headers
  const acceptHeader = headers.accept

  if (acceptHeader && acceptHeader.includes('IEEE754Compatible=true')) {
    options.decimals = { exponential: acceptHeader.includes('ExponentialDecimals=true') }
  }

  const metadataMatch = acceptHeader && acceptHeader.match(/metadata=(minimal|full|none)/)
  if (metadataMatch) options.metadata = metadataMatch[1]

  const preferHeader = headers.prefer

  if (preferHeader && preferHeader.includes('omit-values=')) {
    options.omitValuesPreference = new Map()
  }

  return options
}

const _generateCacheKey = (headers, options) => {
  let key = 'postProcess' // default template cache key for post processing
  if (headers.prefer) key += `:${headers.prefer}`
  if (options.decimals) key += `:ExponentialDecimals=true`
  if (options.event === 'draftActivate' && options.locale) key += `:locale=${options.locale}`
  return key
}

const postProcess = (req, res, service, result, previousResult) => {
  const { model } = service
  const { headers, target } = req

  if (!target || !result || !model || !model.definitions[target.name]) return

  const options = _getOptions(req)
  const cacheKey = _generateCacheKey(headers, options)
  const parent = _getParent(model, target.name)
  // REVISIT: Why so many templates? -> Create only one (superset) template to reduce memory consumption
  const template = getTemplate(cacheKey, service, target, { pick: _pick(options) }, parent)

  if (template.elements.size === 0) return

  // normalize result to rows
  result = result.value != null && Object.keys(result).filter(k => !k.match(/^\W/)).length === 1 ? result.value : result

  if (typeof result === 'object' && result != null) {
    const rows = Array.isArray(result) ? result : [result]

    // process each row
    const processFn = _processorFn(req, previousResult, options)

    for (const row of rows) {
      templateProcessor({
        processFn,
        row,
        template
      })
    }
  }

  applyOmitValuesPreference(res, options.omitValuesPreference)
}

const postProcessMinimal = (req, service, result) => {
  const { target, timestamp } = req

  if (!target || !result) return

  setLocationHeader(req, service)

  const etag = target._etag && target._etag.name
  if (timestamp && etag && etag in result) {
    return { '*@odata.etag': result[etag] === '$now' ? new Date(timestamp).toISOString() : result[etag] }
  }

  return null
}

module.exports = {
  toODataResult,
  postProcess,
  postProcessMinimal
}
