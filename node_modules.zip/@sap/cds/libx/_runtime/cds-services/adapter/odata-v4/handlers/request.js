const cds = require('../../../../cds')

const { UNAUTHORIZED, FORBIDDEN, getRequiresAsArray, isRestricted } = require('../../../../auth/utils')

module.exports = srv => {
  const requires = getRequiresAsArray(srv.definition)
  const restricted = isRestricted(srv)

  return function ODataRequestHandler(odataReq, odataRes, next) {
    const req = odataReq.getBatchApplicationData()
      ? odataReq.getBatchApplicationData().req
      : odataReq.getIncomingRequest()
    const { res, user, path, headers } = req

    const { protectMetadata } = cds.env.odata
    if (protectMetadata === false && (path === '/' || path.endsWith('/$metadata'))) {
      // > nothing to do
      return next()
    }

    // in case of $batch we need to challenge directly, as the header is not processed if in $batch response body
    if (restricted && path.endsWith('/$batch')) {
      if (user?._challenges) {
        res.set('WWW-Authenticate', user._challenges.join(';'))
        return next(UNAUTHORIZED)
      } else if (user._is_anonymous && req.login) {
        res.set('WWW-Authenticate', `Basic realm="Users"`) // REVISIT: should be req.login(), and fiori app works with that but cds/tests/_runtime/auth/__tests__/strategies.test.js fails
        return next(UNAUTHORIZED)
        // return req.login()
      }
    }

    // check @requires as soon as possible (DoS)
    if (requires && !requires.some(r => user.is(r))) {
      // > unauthorized or forbidden?
      if (user._is_anonymous) {
        if (user._challenges) {
          res.set('WWW-Authenticate', user._challenges.join(';'))
        } else if (req.login) {
          res.set('WWW-Authenticate', `Basic realm="Users"`) // REVISIT: should be req.login(), and fiori app works with that but cds/tests/_runtime/auth/__tests__/strategies.test.js fails
          // return req.login()
        }
        // REVISIT: security log in else case?
        return next(UNAUTHORIZED)
      }
      // REVISIT: security log?
      return next(FORBIDDEN)
    }

    /*
     * .on('request') is the only possibility to set a shared object,
     * that can be used in ATOMICITY_GROUP_START and ATOMICITY_GROUP_END
     */
    if (path.endsWith('/$batch')) {
      // ensure content type
      const ct = headers['content-type'] || ''
      if (!ct.match(/multipart\/mixed/) && !ct.match(/application\/json/)) {
        return next({
          statusCode: 400,
          code: '400',
          message: 'Batch requests must have content type multipart/mixed or application/json'
        })
      }

      odataReq.setApplicationData({ req, res })
    }

    next()
  }
}
