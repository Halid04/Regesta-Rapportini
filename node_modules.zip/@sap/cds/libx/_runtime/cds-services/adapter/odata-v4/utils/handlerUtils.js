const cds = require('../../../../cds')
const { isCustomOperation } = require('./request')
const {
  uri: {
    UriResource: {
      ResourceKind: { COMPLEX_PROPERTY, PRIMITIVE_PROPERTY }
    }
  }
} = require('../okra/odata-server')
const { DRAFT_COLUMNS_MAP } = require('../../../../common/constants/draft')
const { SELECT } = cds.ql

const _keysOf = (row, target) => {
  const keyElements = Object.values(target.keys || {}).filter(v => !v.virtual)
  // > singleton
  if (!keyElements.length) return
  const keys = {}
  for (const key of keyElements) {
    if (key._isAssociationStrict) continue
    if (row[key.name] === undefined) continue // key is not in data, so ignore it
    keys[key.name] = key.elements ? { val: JSON.stringify(row[key.name]) } : row[key.name]
  }
  return keys
}

const getSimpleSelectCQN = (target, data, columns) => {
  const keys = _keysOf(data, target)
  // don't use `ql.where()` to get `where` in `from` for location header
  const cqn = keys ? SELECT.one(target, keys) : /* singleton */ SELECT.one(target)

  if (columns) {
    cqn.columns(...columns)
  }

  if (target.query && target.query.SELECT && target.query.SELECT.orderBy) {
    cqn.SELECT.orderBy = target.query.SELECT.orderBy
  }

  return cqn
}

/*
 * merge CQNs
 */
const _mergeExpandCQNs = cqns => {
  const cols = cqns[0].SELECT.columns
  for (const cqn of cqns.slice(1)) {
    for (const col of cqn.SELECT.columns) {
      if (!col.expand) continue
      const idx = cols.findIndex(ele => {
        if (!col.ref) return
        if (ele.ref) return ele.ref[0] === col.ref[0]
        if (ele.as) return ele.as === col.ref[0]
      })
      if (idx === -1) {
        cols.push(col)
      } else {
        const colExists = cols[idx]
        if (colExists.as && colExists.val === null) {
          cols[idx] = col
          continue
        }
        if (col.as && col.val === null) continue
        const mergedExpandCQN = _mergeExpandCQNs([
          { SELECT: { columns: colExists.expand } },
          { SELECT: { columns: col.expand } }
        ])
        colExists.expand = mergedExpandCQN.SELECT.columns
      }
    }
  }
  return cqns[0]
}

const _getExpandColumn = (data, element) => {
  const key = element.name
  if (!(key in data)) return
  data = data[key]
  if ((Array.isArray(data) && data.length === 0) || data == null) {
    // performance tweak, keep in mind it is only for compositions
    return { val: null, as: key }
  }
  const cqn = Array.isArray(data)
    ? _mergeExpandCQNs(data.map(data => getDeepSelect({ target: element._target, data })))
    : getDeepSelect({ target: element._target, data })
  return { ref: [key], expand: cqn.SELECT.columns }
}

const _getColumns = (target, data, prefix = []) => {
  const columns = []
  for (const each in target.elements) {
    if (each in DRAFT_COLUMNS_MAP) continue
    const element = target.elements[each]
    if (element.elements && data[each]) {
      prefix.push(element.name)
      columns.push(..._getColumns(element, data[each], prefix))
      prefix.pop()
    } else if (element.isComposition && !prefix.length) {
      const col = _getExpandColumn(data, element, prefix)
      if (col) columns.push(col)
    } else if (!element.isAssociation) {
      columns.push({ ref: [...prefix, each] })
    }
  }
  return columns
}

/*
 * recursively builds a select cqn for deep read after write
 * (depth determined by req.data)
 */
const getDeepSelect = req => {
  let { target, data } = req
  const columns = _getColumns(target, data)
  return getSimpleSelectCQN(target, data, columns)
}

const getActionOrFunctionReturnType = (pathSegments, definitions) => {
  if (!isCustomOperation(pathSegments, true)) return

  const actionOrFunction =
    pathSegments[pathSegments.length - 1].getFunction() || pathSegments[pathSegments.length - 1].getAction()

  if (actionOrFunction) {
    const returnType = actionOrFunction.getReturnType()
    if (returnType) {
      return definitions[returnType.getType().getFullQualifiedName().toString()]
    }
  }
}

const resolveStructuredName = (pathSegments, index, nameArr = []) => {
  if (pathSegments[index].getKind() === COMPLEX_PROPERTY) {
    const prop = pathSegments[index].getProperty()
    nameArr.unshift(prop.getName())
    return resolveStructuredName(pathSegments, --index, nameArr)
  } else if (
    pathSegments[index].getKind() === PRIMITIVE_PROPERTY &&
    pathSegments[index - 1].getKind() === COMPLEX_PROPERTY
  ) {
    return resolveStructuredName(pathSegments, --index, nameArr)
  }

  return nameArr
}

const isReturnMinimal = req => {
  if (!req.headers.prefer || !req.headers.prefer.includes('return=')) {
    return cds.env.odata.prefer && cds.env.odata.prefer.return === 'minimal'
  }

  return req.headers.prefer.includes('return=minimal')
}

module.exports = {
  resolveStructuredName,
  getActionOrFunctionReturnType,
  isReturnMinimal,
  getDeepSelect,
  getSimpleSelectCQN
}
