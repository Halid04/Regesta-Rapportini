const { removeDraftUUIDIfNecessary } = require('../../../../fiori/utils/handler')
const cds = require('../../../../cds')
const {
  Request,
  ql: { SELECT }
} = cds

const { getDeepSelect, getSimpleSelectCQN } = require('./handlerUtils')
const { hasDeepUpdate } = require('../../../../common/composition/update')
const { WRITE_EVENTS, CDS_EVENTS } = require('../../../../common/constants/events')

const setLocationHeader = (req, { model }) => {
  const { odataRes } = req._
  const cqn = getSimpleSelectCQN(req.target, req.data)
  const { path: location } = cds.odata.urlify(cqn, { kind: 'odata', model, method: 'GET' })
  odataRes.setHeader('Location', location.replace(/\?.*$/, ''))
}

const _isNoAccessError = e => Number(e.code) === 403 || Number(e.code) === 401
const _isNotFoundError = e => Number(e.code) === 404
const _isEntityNotReadableError = e => Number(e.code) === 405

const _handleReadError = err => {
  if (!(_isNoAccessError(err) || _isEntityNotReadableError(err) || _isNotFoundError(err))) throw err
}

const _getOperationQueryColumns = urlQueryOptions => {
  if (!urlQueryOptions || !(urlQueryOptions.$select || urlQueryOptions.$expand)) return []
  const url = []
  if (urlQueryOptions.$select) url.push(`$select=${urlQueryOptions.$select}`)
  if (urlQueryOptions.$expand) url.push(`$expand=${urlQueryOptions.$expand}`)
  const {
    SELECT: { columns }
  } = cds.odata.parse(`?${url.join('&')}`)
  return columns
}

const _isDraftAction = req => req.event in { draftActivate: 1, EDIT: 1, draftPrepare: 1 }
const _isActionOrFunction = req => !(req.event in CDS_EVENTS) || _isDraftAction(req)
const _isWriteWithResponse = req => req.event in WRITE_EVENTS && !(req.event in { CANCEL: 1, DELETE: 1 })
const _ensureKeysAreSelected = query => {
  if (!query.SELECT.columns || query.SELECT.columns.some(c => c === '*')) return
  for (const key in query._target.keys) {
    if (!query.SELECT.columns.some(c => c.ref?.[0] === key)) query.SELECT.columns.push({ ref: [key] })
  }
}

const readAfterWrite = async (req, srv, { operation, isBefore } = { isBefore: false }) => {
  let query

  if (_isActionOrFunction(req)) {
    const { result, returnType } = operation
    query = getSimpleSelectCQN(returnType, result, _getOperationQueryColumns(req._queryOptions))
    if (_isDraftAction(req)) query.where({ IsActiveEntity: req.event === 'draftActivate' })
  } else if (req.event === 'NEW' || req.event === 'PATCH') {
    const { result } = operation
    if (req.query.UPDATE?.entity?.ref[0]?.where) {
      query = SELECT.one(req.query.UPDATE.entity)
    } else {
      query = getSimpleSelectCQN(req.target, result)
    }
  } else if (req.event === 'UPDATE' && !hasDeepUpdate(srv.model, req.query)) {
    query = Array.isArray(req.data) ? SELECT.from(req.query.UPDATE.entity) : SELECT.one(req.query.UPDATE.entity)
  } else {
    query = getDeepSelect(req)
  }
  Object.defineProperty(query.SELECT, '_4odata', { value: true })
  _ensureKeysAreSelected(query)

  // gracefully set location and no body if no read auth or not readable capability
  let result
  try {
    const _req = new Request({ query, event: 'READ', _: req._, params: req.params })
    result = await srv.dispatch(_req)
    if (result && req.target._isDraftEnabled) removeDraftUUIDIfNecessary(req)(result)
    if (result == null && !isBefore && (_isWriteWithResponse(req) || _isDraftAction(req))) {
      // > something must be written and no READ error <=> @restrict or static where
      _req.reject({
        code: 404,
        internal: {
          reason: `No data found for "READ" after "${req.method}" of "${query._target.name}"`,
          source: `"@restrict" or "where" of "${query._target.name}" or underlying entities`
        }
      })
    }
  } catch (e) {
    _handleReadError(e, req)
    result = null
  }

  // draft actions have own logic to set location header
  if (result == null && _isWriteWithResponse(req) && !_isDraftAction(req)) {
    setLocationHeader(req, srv)
  }

  return result
}

module.exports = {
  readAfterWrite,
  setLocationHeader
}
