const { alias2ref } = require('../../../common/utils/csn') // REVISIT: eliminate that
const cds = require('../../../cds')
const OData = require('./OData')

/**
 * This is the express handler for a specific OData endpoint.
 * Note: the same service can be served at different endpoints.
 */
module.exports = srv => {
  const okra = new OkraAdapter(srv)
  return okra.process.bind(okra)
}

function OkraAdapter(srv, model = srv.model) {
  const edm = cds.compile.to.edm(model, { service: srv.definition?.name || srv.name })
  alias2ref(srv, edm) // REVISIT: eliminate that -> done again and again -> search for _alias2ref
  return new OData(edm, model, srv.options).addCDSServiceToChannel(srv)
}

//////////////////////////////////////////////////////////////////////////////
//
//  REVISIT: Move to ExtensibilityService
//
if (cds.mtx || cds.requires.extensibility || cds.requires.toggles)
  module.exports = srv => {
    const id = `${++unique} - ${srv.path}` // REVISIT: this is to allow running multiple express apps serving same endpoints, as done by some questionable tests
    return function ODataAdapter(req, res) {
      const model = cds.context?.model || srv.model
      if (!model._cached) Object.defineProperty(model, '_cached', { value: { touched: Date.now() } })

      // Note: cache is attached to model cache so they get disposed when models are evicted from cache
      let adapters = model._cached._odata_adapters || (model._cached._odata_adapters = {})
      let okra = adapters[id]
      if (!okra) {
        const _srv = { __proto__: srv, _real_srv: srv, model } // REVISIT: we need to do that better in new adapters
        okra = adapters[id] = new OkraAdapter(_srv, model)
      }
      return okra.process(req, res)
    }
  }
let unique = 0
