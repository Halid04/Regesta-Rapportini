const cds = require('../../../../cds')
const LOG = cds.log('odata')
const { appURL } = require('../../../../common/utils/vcap')
const { resolveFromSelect, targetFromPath } = require('../../../../common/utils/cqn')
const { setEntityContained } = require('../../../../common/utils/csn')
const { getNavigationIfStruct } = require('../../../../common/utils/structured')
const getTemplate = require('../../../../common/utils/template')
const templateProcessor = require('../../../../common/utils/templateProcessor')

const _ignoreColumns = (columns, options) => {
  if (!(Array.isArray(columns) && columns.some(c => c === '*' || c.as || c.ref))) return true
  // REVISIT expand=* => list all expanded properties (as by okra's implementation)
  // OData spec is clarified (https://github.tools.sap/cap/cds/pull/1183#pullrequestreview-1775872)
  if (options && !options.$select && options.$expand === '*') return true
}

const _getNestedQueryOptions = (ref, expand, expandString) => {
  const isNested = expandString.match(new RegExp(`${ref}(?=\\()`))
  // if no "ref(" i.e. "ref" without open bracket => no nested options => shift and return
  if (!(isNested && Array.isArray(expand) && expand.length)) return { _expand: expandString.replace(ref, '') }
  // if "ref(" found, shift to the first position after "("
  expandString = expandString.slice(isNested.index + ref.length + 1)
  // i.e. we found 1 open bracket already
  let openBrackets = 1
  let head = ''
  // if expandString is '$top=10;$expand=foo($select=*),bar($select=buz));$select=a,b)',
  // then outterQueryOptions is '$top=10;$expand=foo,bar;$select=a,b'
  let outterQueryOptions = ''
  let nestedExpand = ''

  // parse until the last even closing bracket
  while (openBrackets) {
    const bracketFound = expandString.match(/\(|\)/)
    head = expandString.substring(0, bracketFound.index)
    expandString = expandString.slice(bracketFound.index + 1)
    nestedExpand = `${nestedExpand}${head}${bracketFound[0]}`
    // every time we have only 1 opened bracket and find another one,
    // everything to the left is related to outter query options
    if (openBrackets === 1 && bracketFound[0] === '(') {
      outterQueryOptions = `${outterQueryOptions}${head}`
    }
    openBrackets = bracketFound[0] === '(' ? openBrackets + 1 : openBrackets - 1
  }
  outterQueryOptions = `${outterQueryOptions}${head}`

  // outterQueryOptions also contain $expand, but without nested options i.e. can safely be split by ";"
  const $select = outterQueryOptions.split(';').find(s => s.startsWith('$select'))

  const expandIndex = nestedExpand.indexOf('$expand=')
  // last symbol is a pair to open bracket in "ref(" => slice(..., -1)
  const $expand = expandIndex === -1 ? '' : nestedExpand.slice(expandIndex + '$expand='.length, -1)

  return {
    $select: $select && $select.replace('$select=', ''),
    $expand,
    _expand: expandString
  }
}

const _columnsFromQuery = (columns, target, options) => {
  // must use query.columns as it includes columns from $apply except of $apply=expand()
  // must use query options to get nested $selects inside $expand() as they are mixed into query columns
  // example: GET /Foo?$select=bar&$expand=bar => @odata.context: $metadata#Foo(bar,bar())
  // REVISIT tbd if having expand column in $select could be integrated into query in grammar.pegjs
  // REVISIT support $apply=expand()
  if (_ignoreColumns(columns, options)) return ''
  const context = []
  const _select = options.$select ? options.$select.split(',') : []
  let _expand = options.$expand || ''

  const hasAsterisk = _select.indexOf('*') > -1
  if (hasAsterisk) context.push('*')

  for (const c of columns) {
    if (!c) continue
    const ref = c.ref && c.ref.join('/')
    if (!hasAsterisk && !c.expand) {
      if (c.as) context.push(c.as)
      else if (ref) context.push(ref)
    } else if (c.expand) {
      if (!hasAsterisk && _select.indexOf(ref) > -1) context.push(ref)

      const nextTarget = getNavigationIfStruct(target, c.ref)
      if (nextTarget && nextTarget._target && nextTarget._target.elements) {
        const nestedOptions = _getNestedQueryOptions(ref, c.expand, _expand)
        _expand = nestedOptions._expand
        context.push(`${ref}(${_columnsFromQuery(c.expand, nextTarget._target, nestedOptions)})`)
      }
    }
  }
  if (context.length) return context.join(',')
  else if (hasAsterisk) return '*'
  return ''
}

const _processFn = columns => {
  return ({ row, key, element, pathSegmentsInfo }) => {
    if (!(key in row) || row[key] === null) return
    let cur = columns
    if (element.parent._isStructured) {
      const prefix = pathSegmentsInfo.join('/')
      key = `${prefix}/${key}`
    } else {
      for (let p of pathSegmentsInfo) {
        if (!cur[p]) cur[p] = {}
        cur = cur[p]
      }
    }
    if (!cur[key]) cur[key] = {}
  }
}

const _columnsFromData = (data, definition, service) => {
  const columns = {}
  const template = getTemplate('odata-context', service, definition, { pick: element => element.isAssociation })
  if (!template || !template.elements.size) return ''
  const arrayData = Array.isArray(data) ? data : data ? [data] : []
  for (const row of arrayData) {
    templateProcessor({ processFn: _processFn(columns), row, template, pathOptions: { pathSegmentsInfo: [] } })
  }
  return _stringifyColumnsFromData(columns)
}

const _stringifyColumnsFromData = columns =>
  Object.keys(columns)
    .map(key => `${key}(${_stringifyColumnsFromData(columns[key])})`)
    .join(',')

const _listColumns = ({ columns, data, isUpsert, returnType, event, /* express */ _req, service }) => {
  // query options ($select, $expand, etc) as strings
  const queryOptions = _req.query
  let columnsStr
  if (!isUpsert && event in { CREATE: 1 }) {
    columnsStr = _columnsFromData(data, returnType, service)
  } else {
    columnsStr = _columnsFromQuery(columns, returnType, queryOptions)
  }
  return columnsStr && `(${columnsStr})`
}

const _getContextUrlPrefix = ({ _req, path, target }) => {
  if (cds.env.odata.contextAbsoluteUrl) {
    try {
      if (typeof cds.env.odata.contextAbsoluteUrl === 'string') {
        const userDefinedURL = new URL(cds.env.odata.contextAbsoluteUrl, cds.env.odata.contextAbsoluteUrl).toString()
        return (!userDefinedURL.endsWith('/') && `${userDefinedURL}/`) || userDefinedURL
      }
    } catch (e) {
      e.message = `cds.odata.contextAbsoluteUrl could not be parsed as URL: ${cds.env.odata.contextAbsoluteUrl}`
      LOG._warn && LOG.warn(e)
    }
    const reqURL = _req && _req.get && _req.get('host') && `${_req.protocol || 'https'}://${_req.get('host')}`
    const baseAppURL = appURL || reqURL || ''
    const serviceUrl = `${(_req && _req.baseUrl) || ''}/`
    return baseAppURL && new URL(serviceUrl, baseAppURL).toString()
  }
  return target && target.params ? '../'.repeat(path.length) : '../'.repeat(path.length - 1)
}

const _findEdmNameFor = (definition, namespace, fullyQualified = false) => {
  let name
  if (!definition) return ''
  if (definition._isStructured) {
    const structured = [definition.name]
    while (definition.parent) {
      definition = definition.parent
      structured.unshift(definition.name)
    }
    name = structured.join('_')
  } else {
    name = definition.name
  }
  if (!name.startsWith(`${namespace}.`)) return name
  return fullyQualified ? name : name.replace(new RegExp(`^${namespace}\\.`), '')
}

const _opResultName = ({ service, returnType, operation, isServiceEntity }) => {
  const { namespace } = service
  if (returnType.name) {
    const resultName = _findEdmNameFor(returnType, namespace)
    if (returnType.name.startsWith(`${namespace}.`)) {
      if (isServiceEntity) return resultName.replace(/\./g, '_')
      return `${namespace}.${resultName.replace(/\./g, '_')}`
    }
    return resultName
  }
  // bound action / function returns inline structure
  if (operation.parent) {
    const boundEntityName = _findEdmNameFor(operation.parent, namespace, true).replace(/\./g, '_')
    // REVISIT exactly this return type name is generated in edm by compiler
    return `${namespace}.return_${boundEntityName}_${_findEdmNameFor(operation, namespace)}`
  }
  // unbound action / function returns inline structure
  // REVISIT exactly this return type name is generated in edm by compiler
  return `${namespace}.return_${_findEdmNameFor(operation, namespace, true).replace(/\./g, '_')}`
}

const _isNavToDraftAdmin = path => path.length > 1 && path[path.length - 1] === 'DraftAdministrativeData'

const _getCanonicalUrl = (path, target, model) => {
  const toManySegment =
    path.length > 1 && Array.isArray(path[path.length - 1].where) && path[path.length - 1].where.length && path.pop()
  if (target.params) path.push('Set')
  const odataUrl = cds.odata.urlify({ SELECT: { from: { ref: path } } }, { model, kind: 'odata' })
  let contextPath = odataUrl.path && odataUrl.path.match(/^([^?]*)\??/)[1]
  if (toManySegment) {
    contextPath += `/${toManySegment.id}`
    path.push(toManySegment)
  }
  return contextPath
}

const _getReturnTypeUrl = options => {
  const {
    service,
    isCollection,
    returnType,
    operation,
    path,
    target,
    propertyName,
    isServiceEntity,
    isTargetComposition
  } = options
  const { namespace } = service
  if (operation) {
    const resultName = _opResultName(options)
    if (isServiceEntity) return resultName
    return isCollection ? `Collection(${resultName})` : resultName
  }
  if (isTargetComposition || propertyName || target.params || _isNavToDraftAdmin(path)) {
    return _getCanonicalUrl(path, target, service.model)
  }
  if (isServiceEntity) return _findEdmNameFor(returnType, namespace).replace(/\./g, '_')
  return isCollection ? `Collection(${returnType.name})` : returnType.name
}

const _isSingleEntity = options => {
  const { isCollection, propertyName, returnType, isServiceEntity, isTargetComposition } = options
  if (isCollection || (returnType && returnType._isSingleton) || propertyName) return false
  return isServiceEntity || isTargetComposition
}

const _getContextUrl = options => {
  if (!options.returnType) return ''
  const contextUrlPrefix = _getContextUrlPrefix(options)
  const returnTypeUrl = _getReturnTypeUrl(options)
  const columnsStringified = _listColumns(options)
  const $entity = _isSingleEntity(options) ? '/$entity' : ''
  return `${contextUrlPrefix}$metadata#${returnTypeUrl}${columnsStringified}${$entity}`
}

const _getAdditionalContextUrl = (query, service, data, eventType, _req, isUpsert) => {
  if (Array.isArray(query)) {
    const additionalContextUrls = []
    for (let i = 1; i < query.length; i++) {
      additionalContextUrls.push(
        _getContextUrl(
          Object.assign(_getQueryInfo(query[i], service, data, eventType), { _req, service, data, isUpsert })
        )
      )
    }
    return additionalContextUrls
  }
  return []
}

const _partialCopyColumn = c => {
  if (c.expand) {
    const copy = { expand: Array.isArray(c.expand) ? c.expand.map(_partialCopyColumn) : c.expand }
    if (c.ref) copy.ref = [...c.ref]
    return copy
  }
  if (c.ref) return { ref: [...c.ref] }
  if (c.as) return { as: c.as }
  return c
}

const _partialCopyColumns = query => {
  if (query.SELECT) {
    // stop digging into subSelects as soon as columns found, as deeper columns will be shadowed by these
    if (!query.SELECT.columns && query.SELECT.from.SELECT) return _partialCopyColumns(query.SELECT.from)
    if (query.SELECT.columns) return query.SELECT.columns.map(_partialCopyColumn)
  }
  return []
}

const _getPathInfo = (query, model) => {
  const queryFrom =
    (query.SELECT && resolveFromSelect(query)) ||
    (query.INSERT && query.INSERT.into) ||
    (query.UPDATE && query.UPDATE.entity) ||
    (query.DELETE && query.DELETE.from)
  const { last, target, path, isTargetComposition } = targetFromPath(queryFrom, model)
  const operation = (last.kind === 'action' || last.kind === 'function') && last
  let returnType, isCollection, propertyName, unbound
  if (operation) {
    // last segment is bound action/function => must not be in ref
    queryFrom && queryFrom.ref && queryFrom.ref.pop()
    unbound = !operation.parent
    if (operation.returns) {
      returnType = setEntityContained(operation.returns.items || operation.returns, model)
      isCollection = !!operation.returns.items
    }
    // no propertyName as operations do not (yet?) support navigation
  } else {
    returnType = target
    isCollection = Array.isArray(query) || (query.SELECT && !query.SELECT.one)
    propertyName = query._propertyAccess && query.SELECT.columns[0].ref[query.SELECT.columns[0].ref.length - 1]
    if (propertyName) returnType = query.SELECT.columns[0].ref.reduce((r, c) => r.elements[c], target)
  }
  const isStream = propertyName && target.elements[propertyName]?.['@Core.MediaType']
  return {
    path,
    target,
    last,
    operation,
    returnType,
    isCollection,
    propertyName,
    isStream,
    unbound,
    isTargetComposition
  }
}

const _getEvent = (eventType, namespace, data, { last, target }) => {
  if (last && (last.kind === 'action' || last.kind === 'function')) {
    // BOUND
    if (last.parent) eventType = last.name
    // UNBOUND
    eventType = last.name.replace(`${namespace}.`, '')
  }
  // draft
  if (target && target._isDraftEnabled) {
    if (eventType === 'CREATE') return 'NEW'
    else if (eventType === 'draftEdit') return 'EDIT'
    else if (eventType === 'UPDATE') return 'PATCH'
    else if (eventType === 'DELETE' && data.IsActiveEntity !== true) return 'CANCEL'
  }
  return eventType
}

const _getQueryInfo = (query, service, data, eventType) => {
  const { namespace, model } = service
  const _pathInfo = _getPathInfo(Array.isArray(query) ? query[0] : query, model)
  const { returnType } = _pathInfo

  // store original columns before they are polluted by drafts, db and so on
  const columns = _partialCopyColumns(Array.isArray(query) ? query[0] : query)
  const isServiceEntity =
    _findEdmNameFor(returnType, namespace) in model.entities(namespace) && !returnType._isContained
  const event = _getEvent(eventType, namespace, data, _pathInfo)
  return Object.assign(_pathInfo, {
    columns,
    isServiceEntity,
    event
  })
}

module.exports = (query, eventType, service, data, /* express req */ _req, isUpsert) => {
  const queryInfo = _getQueryInfo(query, service, data, eventType)

  const { isCollection, isStream, propertyName, unbound, event, returnType, isServiceEntity } = queryInfo

  const contextUrl = _getContextUrl(Object.assign(queryInfo, { _req, service, data, isUpsert }))

  const additionalContextUrl = _getAdditionalContextUrl(query, service, data, eventType, _req, isUpsert)

  return {
    event,
    unbound,
    metadata: {
      isCollection,
      isStream,
      propertyName,
      contextUrl,
      returnType,
      isServiceEntity,
      additionalContextUrl
    }
  }
}
