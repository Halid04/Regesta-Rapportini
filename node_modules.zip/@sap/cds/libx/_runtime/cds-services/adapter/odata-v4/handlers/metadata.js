const cds = require('../../../../cds')
const LOG = cds.log('odata')

const { toODataResult } = require('../utils/result')
const { normalizeError } = require('../../../../common/error/frontend')
const getError = require('../../../../common/error')

/**
 * Provide localized metadata handler.
 *
 * @param {object} service
 * @returns {Function}
 */
const metadata = service => {
  return async (odataReq, odataRes, next) => {
    const req = odataReq.getIncomingRequest()
    const tenant = req.user && req.user.tenant
    // REVISIT: can we take locale from user, or is there some odata special wrt metadata?
    const locale = odataRes.getContract().getLocale()

    try {
      const { 'cds.xt.ModelProviderService': mps } = cds.services
      let edmx = mps
        ? await mps.getEdmx({ tenant, model: service.model, service: service.definition.name, locale })
        : cds.mtx && (await cds.mtx.isExtended(tenant))
        ? await cds.mtx.getEdmx(tenant, service.definition.name, locale)
        : cds.localize(
            service.model,
            locale,
            // REVISIT: we could cache this in model._cached
            cds.compile.to.edmx(service.model, { service: service.definition.name })
          )
      return next(null, toODataResult(edmx))
    } catch (e) {
      if (LOG._error) {
        e.message = 'Unable to get EDMX for tenant ' + tenant + ' due to error: ' + e.message
        LOG.error(e)
      }
      // return 503 to client
      const err = getError(Object.assign(e, { statusCode: 503 }))
      const { error, statusCode } = normalizeError(err, req)
      return next(Object.assign(error, { statusCode }))
    }
  }
}

module.exports = metadata
