const {
  uri: {
    UriResource: {
      ResourceKind: { ENTITY, ENTITY_COLLECTION }
    }
  }
} = require('../okra/odata-server')

const getError = require('../../../../common/error')

const _unboundActionsAndFunctions = { 'ACTION.IMPORT': 1, 'FUNCTION.IMPORT': 1 }
const _actionsAndFunctions = { ..._unboundActionsAndFunctions, 'BOUND.ACTION': 1, 'BOUND.FUNCTION': 1 }

/**
 * Checks if a custom operation was requested.
 *
 * @param {Array} pathSegments - The uri path segments of the request.
 * @param {boolean} [includingBound] - True if the check should also accept bound operations. Default is true.
 * @returns {boolean} - True if the request targets a custom operation.
 * @private
 */
const isCustomOperation = (pathSegments, includingBound = true) => {
  const kind = pathSegments[pathSegments.length - 1].getKind()
  const kinds = includingBound ? _actionsAndFunctions : _unboundActionsAndFunctions
  if (kind in kinds) {
    return kind
  }
}

/**
 * Validate resource path length and autoexposed entities.
 * It will throw an error in case the maximum is exceeded or top entity is autoexposed.
 *
 * @param {object} odataReq
 * @param {object} service
 */
const validateResourcePath = (odataReq, service) => {
  const segment = odataReq.getUriInfo().getPathSegments()[0]
  if (segment.getKind() === ENTITY || segment.getKind() === ENTITY_COLLECTION) {
    const name = segment.getEntitySet().getName()
    // REVISIT: This validation is violating all principles of locality
    const entity = service.model.definitions[`${service.definition.name}.${name}`]
    if (!entity) return

    /*
     * For auto-exposed Compositions all direct CRUD requests are rejected in non-draft case.
     * For other auto-exposed entities in non-draft case only C_UD are rejected. Direct READ is allowed.
     * Draft case is an exception. Direct requests are allowed.
     */
    if (entity._isDraftEnabled) return
    if (entity['@cds.autoexposed']) {
      if (entity['@cds.autoexpose'] && odataReq.getIncomingRequest().method === 'GET') {
        // combination GET && @cds.autoexposed && @cds.autoexpose is OK
        return
      }
      throw getError(405, 'ENTITY_IS_AUTOEXPOSED', [entity.name])
    }
  }
}

module.exports = {
  isCustomOperation,
  validateResourcePath
}
