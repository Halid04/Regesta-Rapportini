const cds = require('../../../../cds')
const LOG = cds.log('odata')

const { SELECT } = cds.ql

const { isPathToDraft } = require('../../../../common/utils/cqn')
const { deepCopyArray } = require('../../../../common/utils/copy')
const { cqn2cqn4sql } = require('../../../../common/utils/cqn2cqn4sql')
const { ensureDraftsSuffix } = require('../../../../fiori/utils/handler')
const { removeIsActiveEntityRecursively, isActiveEntityRequested } = require('../../../../fiori/utils/where')
const { getTransition } = require('../../../../common/utils/resolveView')

const isStreaming = segments => {
  const lastSegment = segments[segments.length - 1]
  return (
    segments.length > 1 &&
    lastSegment.getKind() === 'PRIMITIVE.PROPERTY' &&
    lastSegment.getProperty().getType().getName() === 'Stream'
  )
}

const _adaptSubSelectsDraft = select => {
  if (select.SELECT.from.ref) {
    const index = select.SELECT.from.ref.length - 1
    select.SELECT.from.ref[index] = ensureDraftsSuffix(select.SELECT.from.ref[index])
  }

  if (select.SELECT.where) {
    for (let i = 0; i < select.SELECT.where.length; i++) {
      const element = select.SELECT.where[i]
      if (element.SELECT) {
        _adaptSubSelectsDraft(element)
      } else if (element.xpr) {
        _adaptSubSelectsDraft({ SELECT: { from: {}, where: element.xpr } })
      }
    }
  }
}

const adaptStreamCQN = (cqn, isDraft = false) => {
  if (isDraft || !isActiveEntityRequested(cqn.SELECT.where)) {
    _adaptSubSelectsDraft(cqn)
  } else {
    cqn.SELECT.where = removeIsActiveEntityRecursively(cqn.SELECT.where)
  }
}

// eslint-disable-next-line complexity
const getStreamProperties = (req, model) => {
  // new odata parser sets streaming property in SELECT.from
  const ref = (req.query.SELECT.columns && req.query.SELECT.columns[0].ref) || req.query.SELECT.from.ref
  const propertyName = ref[ref.length - 1]
  let mediaTypeProperty
  for (let key in req.target.elements) {
    const val = req.target.elements[key]
    if (val['@Core.MediaType'] && val.name === propertyName) {
      mediaTypeProperty = val
      break
    }
  }

  let contentType, contentDispositionFilename
  const columns = []
  if (typeof mediaTypeProperty['@Core.MediaType'] === 'object') {
    let contentTypeProperty = mediaTypeProperty['@Core.MediaType']['=']
    if (!req.target.elements[contentTypeProperty]) {
      LOG._warn &&
        LOG.warn(
          `@Core.MediaType in entity "${req.target.name}" points to property "${contentTypeProperty}" which was renamed or is not part of the projection. You must update the annotation value.`
        )
      const mapping = getTransition(req.target, cds.db).mapping
      const key = [...mapping.entries()].find(({ 1: val }) => val.ref[0] === contentTypeProperty)
      contentTypeProperty = key && key.length && key[0]
    }
    if (!req.target.elements[contentTypeProperty]) {
      LOG._warn && LOG.warn(`MediaType ${contentTypeProperty} not found in entity "${req.target.name}".`)
    } else {
      columns.push({ ref: [contentTypeProperty], as: 'contentType' })
    }
  } else {
    contentType = mediaTypeProperty['@Core.MediaType']
  }
  if (mediaTypeProperty['@Core.ContentDisposition.Filename']) {
    if (typeof mediaTypeProperty['@Core.ContentDisposition.Filename'] === 'object') {
      let contentDispositionProperty = mediaTypeProperty['@Core.ContentDisposition.Filename']['=']
      if (!req.target.elements[contentDispositionProperty]) {
        LOG._warn &&
          LOG.warn(
            `@Core.ContentDisposition.Filename in entity "${req.target.name}" points to property "${contentDispositionProperty}" which was renamed or is not part of the projection. You must update the annotation value.`
          )
        const mapping = getTransition(req.target, cds.db).mapping
        const key = [...mapping.entries()].find(({ 1: val }) => val.ref[0] === contentDispositionProperty)
        contentDispositionProperty = key && key.length && key[0]
      }
      if (!req.target.elements[contentDispositionProperty]) {
        LOG._warn &&
          LOG.warn(`ContentDisposition ${contentDispositionProperty} not found in entity "${req.target.name}".`)
      } else {
        columns.push({ ref: [contentDispositionProperty], as: 'contentDispositionFilename' })
      }
    } else {
      contentDispositionFilename = mediaTypeProperty['@Core.ContentDisposition.Filename']
    }
  }
  const contentDispositionType = mediaTypeProperty['@Core.ContentDisposition.Type']

  if (columns.length && cds.db && !req.target._hasPersistenceSkip) {
    // used cloned path
    let select = SELECT.one.from({ ref: deepCopyArray(req.query.SELECT.from.ref) }).columns(columns)

    const pathToDraft = isPathToDraft(select.SELECT.from.ref, model)
    if (req.target._isDraftEnabled && pathToDraft) {
      select = cqn2cqn4sql(select, model)
      adaptStreamCQN(select, pathToDraft)
    }

    return cds
      .tx(req)
      .run(select)
      .then(res => ({
        contentType: (res && res.contentType) || contentType,
        contentDispositionFilename: (res && res.contentDispositionFilename) || contentDispositionFilename,
        contentDispositionType
      }))
  }

  return Promise.resolve({ contentType, contentDispositionFilename, contentDispositionType })
}

module.exports = {
  isStreaming,
  getStreamProperties,
  adaptStreamCQN
}
