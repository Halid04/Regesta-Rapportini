const getError = require('../../common/error')

const getModelNotDefinedError = modelName => {
  return new Error(`No valid model provided. Invalid model: ${JSON.stringify(modelName)}`)
}

// REVISIT: use i18n
const getFeatureNotSupportedError = message => {
  return getError(501, `Feature is not supported: ${message}`)
}

module.exports = {
  getModelNotDefinedError,
  getFeatureNotSupportedError
}
