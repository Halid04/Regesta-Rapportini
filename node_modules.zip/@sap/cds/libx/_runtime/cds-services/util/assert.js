const cds = require('../../cds')
const LOG = cds.log('app')
const templatePathSerializer = require('../../common/utils/templateProcessorPathSerializer')

// REVISIT: replace with cds.Request
const getEntry = require('../../common/error/entry')

const ISO_DATE_PART1 =
  '[1-9]\\d{3}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1\\d|2[0-8])|(?:0[13-9]|1[0-2])-(?:29|30)|(?:0[13578]|1[02])-31)'
const ISO_DATE_PART2 = '(?:[1-9]\\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00)-02-29'
const ISO_DATE = `(?:${ISO_DATE_PART1}|${ISO_DATE_PART2})`
const ISO_TIME_NO_MILLIS = '(?:[01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d'
const ISO_TIME = `${ISO_TIME_NO_MILLIS}(?:\\.\\d{1,9})?`
const ISO_DATE_TIME = `${ISO_DATE}T${ISO_TIME_NO_MILLIS}(?:Z|[+-][01]\\d:?[0-5]\\d)`
const ISO_TIMESTAMP = `${ISO_DATE}T${ISO_TIME}(?:Z|[+-][01]\\d:?[0-5]\\d)`

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
const ISO_DATE_REGEX = new RegExp(`^${ISO_DATE}$`, 'i')
const ISO_TIME_REGEX = new RegExp(`^${ISO_TIME_NO_MILLIS}$`, 'i')
const ISO_DATE_TIME_REGEX = new RegExp(`^${ISO_DATE_TIME}$`, 'i')
const ISO_TIMESTAMP_REGEX = new RegExp(`^${ISO_TIMESTAMP}$`, 'i')

const ASSERT_VALID_ELEMENT = 'ASSERT_VALID_ELEMENT'
const ASSERT_RANGE = 'ASSERT_RANGE'
const ASSERT_FORMAT = 'ASSERT_FORMAT'
const ASSERT_DATA_TYPE = 'ASSERT_DATA_TYPE'
const ASSERT_ENUM = 'ASSERT_ENUM'
const ASSERT_NOT_NULL = 'ASSERT_NOT_NULL'

const _enumValues = element => {
  return Object.keys(element).map(enumKey => {
    const enum_ = element[enumKey]
    const enumValue = enum_ && enum_.val

    if (enumValue !== undefined) {
      if (enumValue['=']) return enumValue['=']
      if (enum_ && enum_.literal && enum_.literal === 'number') return Number(enumValue)
      return enumValue
    }

    return enumKey
  })
}

// REVISIT: this needs a cleanup!
const assertError = (code, element, value, key, path) => {
  let args

  if (typeof code === 'object') {
    args = code.args
    code = code.code
  }

  const { name, type, precision, scale } = element
  const error = new Error()
  const errorEntry = {
    code,
    message: code,
    target: path ?? element.name ?? key,
    args: args ?? [name ?? key]
  }

  const assertError = Object.assign(error, getEntry(errorEntry))
  Object.assign(assertError, {
    entity: element.parent && element.parent.name,
    element: name, // > REVISIT: when is error.element needed?
    type: element.items ? element.items._type : type,
    value
  })

  if (element.enum) assertError.enum = _enumValues(element)
  if (precision) assertError.precision = precision
  if (scale) assertError.scale = scale

  if (element.target) {
    // REVISIT: when does this case apply?
    assertError.target = element.target
  }

  return assertError
}

const _checkString = value => typeof value === 'string'

const _checkNumber = value => typeof value === 'number'

const _checkDecimal = (value, element) => {
  const [left, right] = String(value).split('.')
  return (
    _checkNumber(value) &&
    (!element.precision || left.length <= element.precision - (element.scale || 0)) &&
    (!element.scale || ((right || '').length <= element.scale && parseFloat(right) !== 0))
  )
}

const _checkInteger = value => _checkNumber(value) && parseInt(value, 10) === value

const _checkBoolean = value => typeof value === 'boolean'

// REVISIT: Extension parameter in push is an object with buffer data
const _checkBuffer = value => Buffer.isBuffer(value) || value.type === 'Buffer'

const _checkUUID = value => {
  return _checkString(value) && UUID_REGEX.test(value)
}

const _checkISODate = value => (_checkString(value) && ISO_DATE_REGEX.test(value)) || value instanceof Date

const _checkISOTime = value => _checkString(value) && ISO_TIME_REGEX.test(value)

const _checkISODateTime = value => (_checkString(value) && ISO_DATE_TIME_REGEX.test(value)) || value instanceof Date

const _checkISOTimestamp = value => (_checkString(value) && ISO_TIMESTAMP_REGEX.test(value)) || value instanceof Date

const _checkDateValue = (val, r1, r2) => {
  const dateVal = new Date(val)
  return (dateVal - new Date(r1)) * (dateVal - new Date(r2)) <= 0
}

const _toDate = val => `2000-01-01T${val}Z`

const _checkInRange = (val, range, type) => {
  switch (type) {
    case 'cds.Date':
      return _checkISODate(val) && _checkDateValue(val, range[0], range[1])
    case 'cds.DateTime':
      return _checkISODateTime(val) && _checkDateValue(val, range[0], range[1])
    case 'cds.Timestamp':
      return _checkISOTimestamp(val) && _checkDateValue(val, range[0], range[1])
    case 'cds.Time':
      return _checkISOTime(val) && _checkDateValue(_toDate(val), _toDate(range[0]), _toDate(range[1]))
    default:
      return (val - range[0]) * (val - range[1]) <= 0
  }
}

const _resolveCDSType = element => {
  if (element.type.startsWith('cds.')) return element.type
  if (!element.type) return

  return _resolveCDSType(element.__proto__)
}

// process.env.CDS_ASSERT_FORMAT_FLAGS not official!
const _checkRegExpFormat = (val, format) =>
  _checkString(val) && val.match(new RegExp(format, process.env.CDS_ASSERT_FORMAT_FLAGS || 'u'))

const CDS_TYPE_CHECKS = {
  'cds.UUID': _checkUUID,
  'cds.Boolean': _checkBoolean,
  'cds.Integer': _checkInteger,
  'cds.UInt8': _checkInteger,
  'cds.Int16': _checkInteger,
  'cds.Int32': _checkInteger,
  'cds.Integer64': _checkInteger,
  'cds.Int64': _checkInteger,
  'cds.Decimal': _checkDecimal,
  'cds.DecimalFloat': _checkNumber,
  'cds.Double': _checkNumber,
  'cds.Date': _checkISODate,
  'cds.Time': _checkISOTime,
  'cds.DateTime': _checkISODateTime,
  'cds.Timestamp': _checkISOTimestamp,
  'cds.String': _checkString,
  'cds.Binary': _checkBuffer,
  'cds.LargeString': _checkString,
  'cds.LargeBinary': _checkBuffer
}

// Limitation: depth 1
const checkComplexType = ([key, value], elements, ignoreNonModelledData) => {
  let found = false

  for (const objKey in elements) {
    if (objKey.startsWith(`${key}_`)) {
      const element = elements[objKey]
      const check = CDS_TYPE_CHECKS[element._type]
      found = true

      const nestedData = value[objKey.substring(key.length + 1)]
      // check existence of nestedData to not stumble across not-provided, yet-modelled type parts with depth > 1
      if (nestedData && !check(nestedData)) {
        return false
      }
    }
  }

  return found || ignoreNonModelledData
}

const checkStaticElementByKey = (definition, key, value, result = [], ignoreNonModelledData = true) => {
  const elementsOrParameters = definition.elements || definition.params
  if (!elementsOrParameters) return result
  const elementOrParameter = elementsOrParameters[key]

  if (!elementOrParameter) {
    if (!checkComplexType([key, value], elementsOrParameters, ignoreNonModelledData)) {
      result.push(assertError(ASSERT_VALID_ELEMENT, { name: key }))
    }

    return result
  }

  let check
  if (elementOrParameter.isUUID && definition.name === 'ProvisioningService.tenant') {
    // > old SCP accounts don't have UUID ids
    check = CDS_TYPE_CHECKS['cds.String']
  } else {
    check = CDS_TYPE_CHECKS[elementOrParameter._type]
  }

  if (check && !check(value, elementOrParameter)) {
    // code, entity, element, value
    const args = [typeof value === 'string' ? '"' + value + '"' : value, elementOrParameter._type]
    result.push(assertError({ code: ASSERT_DATA_TYPE, args }, elementOrParameter, value, key))
  }

  return result
}

const _isNotFilled = value =>
  value === null || value === undefined || (typeof value === 'string' && value.trim() === '')

const _checkMandatoryElement = (element, value, errors, key, pathSegmentsInfo) => {
  if (element.parent?.query?.SELECT?.columns?.find(col => _isNavigationColumn(col, element.name))) return
  if (element._isMandatory && !element.default && _isNotFilled(value)) {
    errors.push(assertError(ASSERT_NOT_NULL, element, value, key, pathSegmentsInfo))
  }
}

const _isNavigationColumn = (column, searched) =>
  column.ref?.length > 1 && (column.as === searched || column.ref[column.ref.length - 1] === searched)

const _getEnumElement = element =>
  (element['@assert.range'] && element.enum) || element['@assert.enum'] ? element.enum : undefined

const _checkEnumElement = (element, value, errors, key, pathSegmentsInfo) => {
  const enumElements = _getEnumElement(element)
  const enumValues = enumElements && _enumValues(enumElements)

  if (enumElements && !enumValues.includes(value)) {
    const args =
      typeof value === 'string'
        ? ['"' + value + '"', enumValues.map(ele => '"' + ele + '"').join(', ')]
        : [value, enumValues.join(', ')]

    errors.push(assertError({ code: ASSERT_ENUM, args }, element, value, key, pathSegmentsInfo))
  }
}

const _checkRangeElement = (element, value, errors, key, pathSegmentsInfo) => {
  const rangeElements = element['@assert.range'] && !_getEnumElement(element) ? element['@assert.range'] : undefined
  if (rangeElements && !_checkInRange(value, rangeElements, _resolveCDSType(element))) {
    const args = [value, ...element['@assert.range']]
    errors.push(assertError({ code: ASSERT_RANGE, args }, element, value, key, pathSegmentsInfo))
  }
}

const _checkFormatElement = (element, value, errors, key, pathSegments) => {
  const formatElements = element['@assert.format']
  if (formatElements && !_checkRegExpFormat(value, formatElements)) {
    errors.push(assertError({ code: ASSERT_FORMAT, args: [value, formatElements] }, element, value, key, pathSegments))
  }
}

/**
 * @param {import('../../types/api').InputConstraints} constraints
 */
const checkInputConstraints = ({ element, value, errors, key, pathSegmentsInfo }) => {
  if (!element) return errors
  let path

  if (pathSegmentsInfo?.length) path = templatePathSerializer(element.name || key, pathSegmentsInfo)
  _checkMandatoryElement(element, value, errors, key, path)

  if (value == null) return errors

  _checkEnumElement(element, value, errors, key, path)
  _checkRangeElement(element, value, errors, key, path)
  _checkFormatElement(element, value, errors, key, path)
  return errors
}

const checkStatic = (definition, data, ignoreNonModelledData = false) => {
  if (!Array.isArray(data)) data = [data]

  return data.reduce((result, row) => {
    return Object.entries(row)
      .filter(([, value]) => value !== null && value !== undefined)
      .reduce((result, [key, value]) => {
        return checkStaticElementByKey(definition, key, value, result, ignoreNonModelledData)
      }, result)
  }, [])
}

const checkKeys = (entity, data) => {
  if (!Array.isArray(data)) {
    return checkKeys(entity, [data])
  }

  const entityKeys = Object.keys(entity.keys)
  return data.reduce((result, row) => {
    for (const key of entityKeys) {
      if (row[key] === undefined && !entity.elements[key].isAssociation)
        result.push(assertError(ASSERT_NOT_NULL, entity.elements[key]))
    }

    return result
  }, [])
}

const assertNotNullError = element => assertError(ASSERT_NOT_NULL, element)

/**
 * Check whether the target entity referenced by the association (the reference's target) exists and assert an error if
 * the the reference's target doesn't exist.
 *
 * In other words, use this annotation to check whether a non-null foreign key input in a table has a corresponding
 * primary key (also known as a parent key) in the associated/referenced target table (also known as a parent table).
 *
 * @param {import('../../types/api').assertTargetMap} assertMap
 * @param {array} errors An array to appends the possible errors.
 * @see {@link https://cap.cloud.sap/docs/guides/providing-services#assert-target @assert.target} for
 * further information.
 */
const assertTargets = async (assertMap, errors) => {
  const { targets: targetsMap, allTargets } = assertMap
  if (targetsMap.size === 0) return

  const targets = Array.from(targetsMap.values())
  const transactions = targets.map(({ keys, entity }) => {
    const where = Object.assign({}, ...keys)
    return cds.db.exists(entity, where).forShareLock()
  })
  const targetsExistsResults = await Promise.allSettled(transactions)

  targetsExistsResults.forEach((txPromise, index) => {
    const isPromiseRejected = txPromise.status === 'rejected'
    const shouldAssertError = (txPromise.status === 'fulfilled' && txPromise.value === null) || isPromiseRejected
    if (!shouldAssertError) return

    const target = targets[index]
    const { element } = target.assocInfo

    if (isPromiseRejected) {
      LOG._debug &&
        LOG.debug(
          `The transaction to check the @assert.target constraint for foreign key "${element.name}" failed`,
          txPromise.reason
        )

      throw new Error(txPromise.reason.message)
    }

    allTargets
      .filter(t => t.key === target.key)
      .forEach(target => {
        const { row, pathSegmentsInfo } = target.assocInfo
        const key = target.foreignKey.name
        let path
        if (pathSegmentsInfo?.length) path = templatePathSerializer(key, pathSegmentsInfo)
        const error = assertError('ASSERT_TARGET', target.foreignKey, row[key], key, path)
        errors.push(error)
      })
  })
}

module.exports = {
  CDS_TYPE_CHECKS,
  checkComplexType,
  checkStatic,
  checkInputConstraints,
  checkKeys,
  assertError,
  checkStaticElementByKey,
  assertNotNullError,
  assertTargets
}
