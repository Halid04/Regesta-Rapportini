const cds = require('../cds')
const OutboxService = require('../messaging/Outbox')
const {
  connect,
  buildDataAccessLogs,
  sendDataAccessLog,
  buildDataModificationLogs,
  sendDataModificationLog,
  buildSecurityLog,
  sendSecurityLog,
  buildConfigChangeLogs,
  sendConfigChangeLog
} = require('./utils/v2')
const ANONYMOUS = 'anonymous'
const PLAN = {
  standard: 'standard',
  OAuth2: 'OAuth2'
}

const _getTenantAndUser = options => {
  // REVISIT: the standard plan is deprecated/insecure
  if (options.plan === PLAN.standard) {
    return {
      user: cds.context?.user?.id ?? ANONYMOUS,
      tenant: cds.context?.tenant
    }
  }

  return {
    user: '$USER',
    tenant: '$PROVIDER'
  }
}

const _getSecurityContext = () => {
  const securityContext = cds?.context?.http?.req?.authInfo

  if (!securityContext) {
    const errorMsg =
      '[Audit Logging]: The Programmatic API of the Audit Logging service for the OAuth2 plan (API - V2) can only be ' +
      'called within the context of a request event handler. The authInfo property of the request interface (req.authInfo) ' +
      "is used to get the security context required for the implementation's proper functioning."
    throw new Error(errorMsg)
  }

  return securityContext
}

module.exports = class AuditLogService extends OutboxService {
  async init() {
    // call OutboxService's init, which handles outboxing
    await super.init()

    const credentials = this.options.credentials
    this.options.plan = !credentials || !credentials.uaa ? PLAN.standard : PLAN.OAuth2

    // REVISIT: the standard plan is deprecated/insecure
    if (this.options.plan === PLAN.standard) {
      const auditLogClient = await connect(credentials)
      if (auditLogClient) this.#registerOnHandlers(auditLogClient)
      return
    }

    // OAuth2 plan
    const outbox = cds.requires['audit-log'].outbox
    if (outbox?.kind === 'persistent-outbox' || (outbox && cds.requires.outbox?.kind === 'persistent-outbox')) {
      throw new Error('The OAuth2 plan is not currently supported with persistent outbox')
    }

    if (credentials?.uaa) this.#registerOnHandlers()
  }

  async emit(first, second) {
    const { event, data } = typeof first === 'object' ? first : { event: first, data: second }
    if (!this.options.outbox) return this.send(event, data)

    if (this[event]) {
      try {
        // this will open a new tx -> preserve user
        await super.send(new cds.Request({ method: event, data, user: cds.context.user }))
      } catch (e) {
        if (e.code === 'ERR_ASSERTION') {
          e.unrecoverable = true
        }
        throw e
      }
    }
  }

  async send(event, data) {
    if (this[event]) return super.send(event, data)
  }

  /*
   * api (await AuditLogService.<event>(data))
   */

  async dataAccessLog(data) {
    return super.send('dataAccessLog', data)
  }

  async dataModificationLog(data) {
    return super.send('dataModificationLog', data)
  }

  async securityLog(data) {
    return super.send('securityLog', data)
  }

  async configChangeLog(data) {
    return super.send('configChangeLog', data)
  }

  /*
   * impl
   */

  #registerOnHandlers(auditLogClient) {
    this.on('dataAccessLog', function (req) {
      return this._dataAccessLog(req, auditLogClient)
    })

    this.on('dataModificationLog', function (req) {
      return this._dataModificationLog(req, auditLogClient)
    })

    this.on('securityLog', function (req) {
      return this._securityLog(req, auditLogClient)
    })

    this.on('configChangeLog', function (req) {
      return this._configChangeLog(req, auditLogClient)
    })
  }

  async _dataAccessLog({ data: { accesses } }, auditLogClient) {
    const { tenant, user } = _getTenantAndUser(this.options)

    // build the logs
    auditLogClient = auditLogClient ?? (await connect(this.options.credentials, _getSecurityContext()))
    const { entries, errors } = buildDataAccessLogs(auditLogClient, accesses, tenant, user)
    if (errors.length) {
      throw errors.length === 1 ? errors[0] : Object.assign(new Error('MULTIPLE_ERRORS'), { details: errors })
    }

    // write the logs
    await Promise.all(entries.map(entry => sendDataAccessLog(entry).catch(err => errors.push(err))))

    if (errors.length) {
      throw errors.length === 1 ? errors[0] : Object.assign(new Error('MULTIPLE_ERRORS'), { details: errors })
    }
  }

  // REVISIT: modification.action not used in auditlog v2
  async _dataModificationLog({ data: { modifications } }, auditLogClient) {
    const { tenant, user } = _getTenantAndUser(this.options)

    // build the logs
    auditLogClient = auditLogClient ?? (await connect(this.options.credentials, _getSecurityContext()))
    const { entries, errors } = buildDataModificationLogs(auditLogClient, modifications, tenant, user)
    if (errors.length) {
      throw errors.length === 1 ? errors[0] : Object.assign(new Error('MULTIPLE_ERRORS'), { details: errors })
    }

    // write the logs
    await Promise.all(entries.map(entry => sendDataModificationLog(entry).catch(err => errors.push(err))))

    if (errors.length) {
      throw errors.length === 1 ? errors[0] : Object.assign(new Error('MULTIPLE_ERRORS'), { details: errors })
    }
  }

  async _securityLog({ data: { action, data } }, auditLogClient) {
    let { tenant, user } = _getTenantAndUser(this.options)

    // cds.context may not be proper on auth-related errors -> try to extract from data
    if (!tenant && user === ANONYMOUS) {
      try {
        const parsed = JSON.parse(data)
        if (parsed.tenant) {
          tenant = parsed.tenant
          delete parsed.tenant
        }

        if (parsed.user && typeof parsed.user === 'string') {
          user = parsed.user
          delete parsed.user
        }

        data = JSON.stringify(parsed)
      } catch (e) {
        // ignore
      }
    }

    // build the log
    auditLogClient = auditLogClient ?? (await connect(this.options.credentials, _getSecurityContext()))
    const entry = buildSecurityLog(auditLogClient, action, data, tenant, user)

    // write the log
    await sendSecurityLog(entry)
  }

  // REVISIT: action and success not used in auditlog v2
  async _configChangeLog({ data: { configurations } }, auditLogClient) {
    const { tenant, user } = _getTenantAndUser(this.options)

    // build the logs
    auditLogClient = auditLogClient ?? (await connect(this.options.credentials, _getSecurityContext()))
    const { entries, errors } = buildConfigChangeLogs(auditLogClient, configurations, tenant, user)
    if (errors.length) {
      throw errors.length === 1 ? errors[0] : Object.assign(new Error('MULTIPLE_ERRORS'), { details: errors })
    }

    // write the logs
    await Promise.all(entries.map(entry => sendConfigChangeLog(entry).catch(err => errors.push(err))))

    if (errors.length) {
      throw errors.length === 1 ? errors[0] : Object.assign(new Error('MULTIPLE_ERRORS'), { details: errors })
    }
  }
}
