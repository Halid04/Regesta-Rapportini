const cds = require('../../../cds')

const getTemplate = require('../../../common/utils/template')
const templateProcessor = require('../../../common/utils/templateProcessor')

const {
  getRootEntity,
  getPick,
  createLogEntry,
  addObjectID,
  addDataSubject,
  addDataSubjectForDetailsEntity,
  resolveDataSubjectPromises
} = require('./utils')

const _processorFnAccess = (accessLogs, model, req) => {
  return ({ row, key, element, plain }) => {
    if (row.IsActiveEntity === false) return

    const entity = getRootEntity(element)

    // create or augment log entry
    const entry = createLogEntry(accessLogs, entity, row)

    // process categories
    for (const category of plain.categories) {
      if (category === 'ObjectID') addObjectID(entry, row, key)
      else if (category === 'DataSubjectID') addDataSubject(entry, row, key, entity)
      else if (category === 'IsPotentiallySensitive' && key in row) {
        if (!entry.attributes.some(e => e.name === key)) entry.attributes.push({ name: key })
        // REVISIT: attribute vs. attachment?
      }
    }

    // add promise to determine data subject if a DataSubjectDetails entity
    const semantics = entity['@PersonalData.EntitySemantics']
    if (
      (semantics === 'DataSubjectDetails' || semantics === 'Other') &&
      entry.dataSubject.id.length === 0 // > id still an array -> promise not yet set
    ) {
      addDataSubjectForDetailsEntity(row, entry, req, entity, model)
    }
  }
}

const auditAccessHandler = async function (data, req) {
  const auditLogService = await cds.connect.to('audit-log')
  const mock = Object.assign({ name: req.target._service.name, model: this.model })
  const template = getTemplate('personal_read', mock, req.target, { pick: getPick('READ') })
  if (!template.elements.size) return
  const accessLogs = {}
  if (typeof data === 'object' && data !== null) {
    const processFn = _processorFnAccess(accessLogs, this.model, req)
    const data_ = Array.isArray(data) ? data : [data]
    data_.forEach(row => templateProcessor({ processFn, row, template }))
    const accesses = (await resolveDataSubjectPromises(accessLogs)).filter(ele => ele.attributes.length)
    if (accesses.length) await auditLogService.emit('dataAccessLog', { accesses })
  }
}

module.exports = { auditAccessHandler }
