const cds = require('../../../cds')
const {
  attachDiffToContextHandler,
  calcModificationLogsHandler4Before,
  calcModificationLogsHandler4After,
  emitModificationHandler
} = require('./modification')
const { auditAccessHandler } = require('./access')

exports.impl = cds.service.impl(function () {
  if (!cds.db) return cds.on('connect', srv => srv.isDatabaseService && exports.impl.call(this))
  // REVISIT: diff() doesn't work in srv after phase but foreign key propagation has not yet taken place in srv before phase
  //          -> calc diff in db layer and store in audit data structure at context
  //          -> REVISIT for GA: clear req._.partialPersistentState?
  attachDiffToContextHandler._initial = true
  for (const e of this.entities) {
    if (!_hasPersonalData(e)) continue

    if (e['@AuditLog.Operation.Insert']) {
      cds.db.before('CREATE', e, attachDiffToContextHandler)
      // create -> all new -> calcModificationLogsHandler in after phase
      cds.db.after('CREATE', e, calcModificationLogsHandler4After)
      this.after('CREATE', e, emitModificationHandler)
    }

    if (e['@AuditLog.Operation.Update']) {
      cds.db.before('UPDATE', e, attachDiffToContextHandler)
      // update -> mixed (via deep) -> calcModificationLogsHandler in before and after phase
      cds.db.before('UPDATE', e, calcModificationLogsHandler4Before)
      cds.db.after('UPDATE', e, calcModificationLogsHandler4After)
      this.after('UPDATE', e, emitModificationHandler)
    }

    if (e['@AuditLog.Operation.Delete']) {
      cds.db.before('DELETE', e, attachDiffToContextHandler)
      // delete -> all done -> calcModificationLogsHandler in before phase
      cds.db.before('DELETE', e, calcModificationLogsHandler4Before)
      this.after('DELETE', e, emitModificationHandler)
    }

    if (e['@AuditLog.Operation.Read']) {
      this.after('READ', e, auditAccessHandler)
    }
  }
})

const _hasPersonalData = e => {
  if (!e['@PersonalData.DataSubjectRole']) return
  if (!e['@PersonalData.EntitySemantics']) return
  return !!Object.values(e.elements).some(
    e =>
      e['@PersonalData.IsPotentiallyPersonal'] ||
      e['@PersonalData.IsPotentiallySensitive'] ||
      (e['@PersonalData.FieldSemantics'] && e['@PersonalData.FieldSemantics'] === 'DataSubjectID')
  )
}
