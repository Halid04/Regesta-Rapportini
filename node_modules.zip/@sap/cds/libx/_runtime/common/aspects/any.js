const { foreignKey4 } = require('../../common/utils/foreignKeyPropagations')

// NOTE: Please only add things which are relevant to _any_ type,
// use specialized types otherwise (entity, Association, ...).
module.exports = class {
  get _isStructured() {
    return this.own('__isStructured', () => !!this.elements && this.kind !== 'entity')
  }

  get _isMandatory() {
    return this.own('__isMandatory', () => !this.isAssociation && isMandatory(this))
  }

  get _isReadOnly() {
    return this.own('__isReadOnly', () => !this.key && isReadOnly(this))
  }

  // REVISIT: Where to put?
  get _relations() {
    return this.own('__relations', () => getRelations(this))
  }

  get _foreignKey4() {
    return this.own('__foreignKey4', () => foreignKey4(this))
  }
}

const Relation = require('./relation')
const _exposeRelation = relation => Object.defineProperty({}, '_', { get: () => relation })

const _relationHandler = relation => ({
  get: (target, name) => {
    const path = name.split(',')
    const prop = path.join('_')
    if (!target[prop]) {
      if (path.length === 1) {
        // REVISIT: property 'join' must not be used in CSN to make this working
        if (relation._has(prop)) return relation[prop]
        const newRelation = Relation.to(relation, prop)
        if (newRelation) {
          target[prop] = new Proxy(_exposeRelation(newRelation), _relationHandler(newRelation))
        }

        return target[prop]
      }

      target[prop] = path.reduce((relation, value) => relation[value] || relation.csn._relations[value], relation)
      target[prop].path = path
    }

    return target[prop]
  }
})

const getRelations = e => {
  const newRelation = Relation.to(e)
  return new Proxy(_exposeRelation(newRelation), _relationHandler(newRelation))
}

const CommonFieldControl = e => {
  const cfr = e['@Common.FieldControl']
  return cfr && cfr['#']
}

const isMandatory = e => {
  return (
    e['@assert.mandatory'] !== false &&
    (e['@mandatory'] ||
      e['@Common.FieldControl.Mandatory'] ||
      e['@FieldControl.Mandatory'] ||
      CommonFieldControl(e) === 'Mandatory')
  )
}

const isReadOnly = e => {
  return (
    e['@readonly'] ||
    e['@cds.on.update'] ||
    e['@cds.on.insert'] ||
    e['@Core.Computed'] ||
    e['@Common.FieldControl.ReadOnly'] ||
    e['@FieldControl.ReadOnly'] ||
    CommonFieldControl(e) === 'ReadOnly'
  )
}
