const cds = require('../../cds')
const LOG = cds.log()
const { parentPort } = require('worker_threads')
const executionContextMap = new Map()

parentPort.on('message', function onWorkerMessageReceived(message) {
  const { id, kind, result } = message
  if (!executionContextMap.has(id)) return
  if (LOG._debug) LOG.debug(`Post message received on worker thread (workerQueryExecutor.js) from main thread`, message)

  switch (kind) {
    case 'responseData':
      executionContextMap.get(id)(result)
      executionContextMap.delete(id)
      return

    case 'cleanup':
      executionContextMap.delete(id)
      return
  }
})

function queryExecutor(contextId, resolve) {
  const id = cds.utils.uuid()
  executionContextMap.set(id, result => resolve(result))
  parentPort.postMessage({
    id,
    contextId,
    kind: 'run',
    target: 'srv',
    prop: 'run',
    responseData: true,
    args: [this]
  })
}

module.exports = queryExecutor
