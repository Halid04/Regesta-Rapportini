const os = require('os')
const totalMemory = os.totalmem() // total amount of system memory in bytes
const maxOldGenerationSizeMb = Math.floor(totalMemory / 1024 ** 2 / 8) // max size of the main heap in MB
const maxYoungGenerationSizeMb = Math.floor(totalMemory / 1024 ** 2 / 8) // max size of a heap space for recently created objects

module.exports = {
  timeout: 10000,
  resourceLimits: {
    maxOldGenerationSizeMb,
    maxYoungGenerationSizeMb,
    stackSizeMb: 4 // default
  }
}
