const { parentPort } = require('worker_threads')
const { Responses, Errors } = require('../../../../lib/req/response')

class WorkerReq {
  constructor(contextId, reqData) {
    this.contextId = contextId
    Object.assign(this, reqData)
    this.postMessages = []
    this.messages = this.messages ?? []
    this.errors = this.errors ?? new Errors()
  }

  #push(args) {
    this.postMessages.push({
      kind: 'run',
      target: 'req',
      ...args
    })
  }

  notify(...args) {
    this.#push({
      prop: 'notify',
      args
    })

    const notify = Responses.get(1, ...args)
    this.messages.push(notify)
    return notify
  }

  info(...args) {
    this.#push({
      prop: 'info',
      args
    })

    const info = Responses.get(2, ...args)
    this.messages.push(info)
    return info
  }

  warn(...args) {
    this.#push({
      prop: 'warn',
      args
    })

    const warn = Responses.get(3, ...args)
    this.messages.push(warn)
    return warn
  }

  error(...args) {
    this.#push({
      prop: 'error',
      args
    })

    let error = Responses.get(4, ...args)
    if (!error.stack) Error.captureStackTrace((error = Object.assign(new Error(), error)), this.error)
    this.errors.push(error)
    return error
  }

  reject(...args) {
    parentPort.postMessage({
      contextId: this.contextId,
      kind: 'run',
      target: 'req',
      prop: 'reject',
      args
    })
  }
}

module.exports = WorkerReq
