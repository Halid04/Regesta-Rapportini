const cds = require('../../cds')
const path = require('path')
const { AsyncResource } = require('async_hooks')
const { timeout, resourceLimits } = require('./config')
const WorkerPool = require('./WorkerPool')
const workerPath = path.resolve(__dirname, 'worker.js')
const workerPool = new WorkerPool(workerPath, { resourceLimits })
const { Errors } = require('../../../../lib/req/response')
const LOG = cds.log()
const _getReqData = req => {
  return {
    data: req.data,
    params: req.params,
    results: req.results,
    messages: req.messages,
    errors: req.errors ?? new Errors()
  }
}

module.exports = async function executeCode(code, req) {
  const reqData = _getReqData(req)
  const srv = this
  const _getTarget = target => {
    switch (target) {
      case 'srv':
        return srv

      case 'req':
        return req

      // no default
    }
  }

  const worker = workerPool.adquire()
  const workerId = worker.id
  const contextId = cds.utils.uuid()
  const executePromise = new Promise(function executeCodePromiseExecutor(resolve, reject) {
    queueMicrotask(AsyncResource.bind(onStarted))
    const onMessageReceivedProxy = AsyncResource.bind(onMessageReceived)
    const onErrorProxy = AsyncResource.bind(onError)
    const onExitProxy = AsyncResource.bind(onExit)
    worker.on('message', onMessageReceivedProxy)
    worker.on('error', onErrorProxy)
    worker.on('exit', onExitProxy)

    let onStartTimeoutID
    function onStarted() {
      onStartTimeoutID = setTimeout(() => {
        worker.terminate()
        reject(new Error(`Script execution timed out after ${timeout}ms`))
      }, timeout)
    }

    function onMessageReceived(message) {
      if (message.contextId !== contextId) return

      if (LOG._debug)
        LOG.debug(`Post message received on main thread (code-ext/execute.js) from worker thread`, message)

      switch (message.kind) {
        case 'run':
          run(message)
          return

        case 'success':
          onSuccess(message)
          return

        case 'error':
          onError(message.error)
          return

        // no default
      }
    }

    async function onSuccess(message) {
      for (const m of message.postMessages) await run(m)
      req.data && Object.assign(req.data, message.req.data) // REVISIT: Why Object.assign(...) is a required?
      req.results = message.req.results
      cleanup()
      resolve(req.results ?? message.result)
    }

    function onError(error) {
      cleanup()
      reject(error)
    }

    function onExit(exitCode) {
      if (exitCode !== 0) {
        reject(new Error(`Worker thread stopped with exit code ${exitCode}`))
      }
    }

    async function run(message) {
      try {
        let result = _getTarget(message.target)[message.prop](...message.args)
        if (typeof result?.then === 'function') result = await result
        if (message.responseData) worker.postMessage({ id: message.id, kind: 'responseData', result })
      } catch (error) {
        if (LOG._debug) LOG.debug(`Calling ${message.target}.${message.prop}(...) throws an error.`, error)
        if (message.id) worker.postMessage({ id: message.id, kind: 'cleanup' })
        cleanup()
        reject(error)
      }
    }

    function cleanup() {
      clearTimeout(onStartTimeoutID)
      worker.removeListener('message', onMessageReceivedProxy)
      worker.removeListener('error', onErrorProxy)
      worker.removeListener('exit', onExitProxy)
      workerPool.release(worker)
    }
  })

  // triggers execution of the code in the worker thread
  const message = { contextId, workerId, kind: 'start', code, reqData }
  worker.postMessage(message)
  return executePromise
}
