const cds = require('../../cds')
const LOG = cds.log()
const executeCode = require('./execute')
const CODE_ANNOTATION = '@extension.code'

module.exports = cds.service.impl(function () {
  const getCodeFromAnnotation = async (defName, operation, registration) => {
    // REVISIT: tenant info in not in this.model and cds.context.model is undefined for single tenancy
    const model = cds.context.model || this.model
    const el = model.definitions[defName]
    const boundEl = el.actions?.[operation]
    const extensionCode = boundEl?.[CODE_ANNOTATION] ?? el[CODE_ANNOTATION]
    if (extensionCode) {
      const annotation = extensionCode.filter(element => element[registration] === operation)
      return annotation.length && annotation[0].code
    }
  }

  this.after('READ', async function (result, req) {
    if (result == null) return // whether result is null or undefined
    const code = await getCodeFromAnnotation(req.target.name, req.event, 'after')
    if (!code) return
    await executeCode.call(this, code, req).catch(error => LOG._debug && LOG.debug(error))
  })

  this.before(['CREATE', 'UPDATE', 'DELETE'], async function (req) {
    const code = await getCodeFromAnnotation(req.target.name, req.event, 'before')
    if (!code) return
    await executeCode.call(this, code, req).catch(error => LOG._debug && LOG.debug(error))
  })

  this.on('*', async function (req, next) {
    if (this.name.startsWith('cds.xt')) return next()

    // REVISIT: req.target -> wait until implementation task finished
    let fqn = req.target?.actions?.[`${req.event}`] // check for bound action/function
    if (!fqn) {
      if (req.target) return next()
      fqn = this.model.definitions[`${this.name}.${req.event}`] // check for bound action/function or event
    }

    // REVISIT: DO NOT OVERWRITE EXISTING Action Implementations!
    // REVISIT: check whether action/function or event is part of an extension
    if (fqn.kind === 'action' || fqn.kind === 'function' || req.constructor.name === 'EventMessage') {
      const code = await getCodeFromAnnotation(req?.target?.name ?? fqn.name, req.event, 'on')
      if (!code) return next()
      return await executeCode.call(this, code, req).catch(error => LOG._debug && LOG.debug(error))
    }
  })
})
