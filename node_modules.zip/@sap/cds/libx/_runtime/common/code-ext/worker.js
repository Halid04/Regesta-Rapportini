const cds = require('../../cds')
const LOG = cds.log()
const { parentPort, workerData } = require('worker_threads')
const SELECT = require('../../../../lib/ql/SELECT')
const INSERT = require('../../../../lib/ql/INSERT')
const UPSERT = require('../../../../lib/ql/UPSERT')
const UPDATE = require('../../../../lib/ql/UPDATE')
const DELETE = require('../../../../lib/ql/DELETE')
const queryExecutor = require('./workerQueryExecutor')
const WorkerReq = require('./WorkerReq')
const { timeout } = require('./config')

parentPort.on('message', function onWorkerMessageReceived(message) {
  const { contextId, workerId, kind, code, reqData } = message
  if (kind !== 'start' || workerId !== workerData.id) return
  if (LOG._debug) LOG.debug(`Post message received on worker thread (worker.js) from main thread`, message)

  // eslint-disable-next-line cds/no-missing-dependencies
  const { VM } = require('vm2')
  const workerReq = new WorkerReq(contextId, reqData)

  class WorkerSELECT extends SELECT {
    then(r, e) {
      return new Promise(queryExecutor.bind(this, contextId)).then(r, e)
    }
  }

  class WorkerINSERT extends INSERT {
    then(r, e) {
      return new Promise(queryExecutor.bind(this, contextId)).then(r, e)
    }
  }

  class WorkerUPSERT extends UPSERT {
    then(r, e) {
      return new Promise(queryExecutor.bind(this, contextId)).then(r, e)
    }
  }

  class WorkerUPDATE extends UPDATE {
    then(r, e) {
      return new Promise(queryExecutor.bind(this, contextId)).then(r, e)
    }
  }

  class WorkerDELETE extends DELETE {
    then(r, e) {
      return new Promise(queryExecutor.bind(this, contextId)).then(r, e)
    }
  }

  Object.defineProperty(WorkerSELECT.prototype, 'cmd', { value: 'SELECT' })
  Object.defineProperty(WorkerINSERT.prototype, 'cmd', { value: 'INSERT' })
  Object.defineProperty(WorkerUPSERT.prototype, 'cmd', { value: 'UPSERT' })
  Object.defineProperty(WorkerUPDATE.prototype, 'cmd', { value: 'UPDATE' })
  Object.defineProperty(WorkerDELETE.prototype, 'cmd', { value: 'DELETE' })

  const vm = new VM({
    console: 'inherit',
    timeout, // specifies the number of milliseconds to execute code before terminating execution
    allowAsync: true,

    // the sandbox represents the global object inside the vm instance
    sandbox: {
      req: workerReq,
      SELECT: WorkerSELECT._api(),
      INSERT: WorkerINSERT._api(),
      UPSERT: WorkerUPSERT._api(),
      UPDATE: WorkerUPDATE._api(),
      DELETE: WorkerDELETE._api()
    }
  })

  try {
    ;(async function () {
      const result = await vm.run(code)
      parentPort.postMessage({ contextId, kind: 'success', req: reqData, postMessages: workerReq.postMessages, result })
    })()
  } catch (error) {
    parentPort.postMessage({ contextId, kind: 'error', error })
  }
})
