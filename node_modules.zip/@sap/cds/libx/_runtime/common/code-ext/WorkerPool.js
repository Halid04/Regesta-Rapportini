const cds = require('../../cds')
const os = require('os')
const { Worker } = require('worker_threads')

class ExtensionWorker extends Worker {
  constructor(id, workerPath, options) {
    super(workerPath, options)
    this.id = id
    this.tasksAssigned = 0
  }
}

class WorkerPool {
  static instances = []
  constructor(workerPath, options) {
    this.workerPath = workerPath
    this.options = options
    this.size = options.size ?? Math.max(os.cpus().length, 1)
    this.idleWorkers = new Set()
    this.workers = []
    WorkerPool.instances.push(this)
  }

  #createWorker() {
    const id = cds.utils.uuid()
    const worker = new ExtensionWorker(id, this.workerPath, {
      workerData: { id },
      resourceLimits: this.options.resourceLimits
    })
    worker.on('exit', this.#onWorkerExit.bind(this, worker))
    return worker
  }

  #onWorkerExit(worker) {
    this.idleWorkers.delete(worker)
    this.workers.splice(this.workers.indexOf(worker), 1)
    worker.tasksAssigned = 0
  }

  adquire() {
    if (this.idleWorkers.size === 0 && this.workers.length < this.size) {
      const worker = this.#createWorker()
      this.idleWorkers.add(worker)
      this.workers.push(worker)
    }

    const worker = this.idleWorkers.values().next().value

    if (worker) {
      this.idleWorkers.delete(worker)
      worker.tasksAssigned++
      return worker
    }

    const randomWorkerIndex = Math.floor(Math.random() * this.workers.length)
    const busyWorker = this.workers[randomWorkerIndex]
    busyWorker.tasksAssigned++
    return busyWorker
  }

  release(worker) {
    if (worker.tasksAssigned === 0) return

    worker.tasksAssigned--
    if (worker.tasksAssigned === 0) {
      this.idleWorkers.add(worker)
    }
  }

  async destroy() {
    if (this.workers.length === 0) return

    const workers = Array.from(this.workers)
    const iterable = workers.map(worker => {
      worker.removeAllListeners()
      return worker.terminate()
    })

    await Promise.all(iterable)
    this.idleWorkers = new Set()
    this.workers = []
    WorkerPool.instances = []
  }

  static async destroyAll() {
    for (const workerPool of WorkerPool.instances) await workerPool.destroy()
  }
}

module.exports = WorkerPool
