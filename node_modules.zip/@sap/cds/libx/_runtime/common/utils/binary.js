const getTemplate = require('./template')
const templateProcessor = require('./templateProcessor')

// convert the standard base64 encoding to the URL-safe variant
const toBase64url = value =>
  (Buffer.isBuffer(value) ? value.toString('base64') : value).replace(/\//g, '_').replace(/\+/g, '-')

const normalizeBase64string = value => {
  if (typeof value !== 'string') return value
  // add last byte(s) and '=' padding in case of shortend base64
  return Buffer.from(value, 'base64').toString('base64')
}

const isInvalidBase64string = value => {
  if (Buffer.isBuffer(value)) return // ok

  // convert to standard base64 string; let it crash if typeof value !== 'string'
  const base64value = value.replace(/_/g, '/').replace(/-/g, '+')
  const normalized = normalizeBase64string(value)

  // example of invalid base64 string --> 'WTGTdDsD/k21LnFRb+uNcAi=' <-- '...i=' must be '...g='
  // see https://datatracker.ietf.org/doc/html/rfc4648#section-4
  if (base64value.replace(/=/g, '') !== normalized.replace(/=/g, '')) return true
  return base64value.length > normalized.length
}

const _picker = element => {
  const categories = {}
  if (Array.isArray(element)) return
  if (element.type !== 'cds.Binary' && element.type !== 'cds.LargeBinary') return
  categories['convert_binary'] = true
  return categories
}

const _processorFn =
  toBuffer =>
  ({ row, key, plain: categories }) => {
    if (categories['convert_binary'] && row[key] != null) {
      if (toBuffer && typeof row[key] === 'string') row[key] = Buffer.from(row[key], 'base64')
      if (!toBuffer && Buffer.isBuffer(row[key])) row[key] = row[key].toString('base64')
    }
  }

const _processBinaryData = (data, srv, definition, toBuffer) => {
  const template = getTemplate('rest-payload', srv, definition, { pick: _picker })
  if (template && template.elements.size) {
    const rows = Array.isArray(data) ? data : [data]
    for (const row of rows) {
      templateProcessor({ processFn: _processorFn(toBuffer), row, template })
    }
  }
}

const base64ToBuffer = (data, srv, definition) => {
  _processBinaryData(data, srv, definition, true)
}

const bufferToBase64 = (data, srv, definition) => {
  _processBinaryData(data, srv, definition, false)
}

module.exports = {
  normalizeBase64string,
  isInvalidBase64string,
  toBase64url,
  base64ToBuffer,
  bufferToBase64
}
