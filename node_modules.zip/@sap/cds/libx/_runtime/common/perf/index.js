const { performance } = require('perf_hooks')

const _statisticsRequested = req =>
  (req.query && req.query['sap-statistics'] === 'true') ||
  (req.headers && req.headers['sap-statistics'] === 'true' && (!req.query || !req.query['sap-statistics']))

module.exports = function sap_statistics(req, res, next) {
  if (!_statisticsRequested(req)) return next()

  const t0 = performance.now()
  const { writeHead } = res
  res.writeHead = function (...args) {
    const total = Number((performance.now() - t0) / 1000).toFixed(2)
    if (res.statusCode < 400) res.setHeader('sap-statistics', `total=${total}`)
    writeHead.call(this, ...args)
  }

  next()
}
