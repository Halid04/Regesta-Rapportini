const { getCompositionTree } = require('./tree')
const ctUtils = require('./utils')
const { getEntityNameFromUpdateCQN } = require('../utils/cqn')

const { ensureNoDraftsSuffix } = require('../utils/draft')
const { getDBTable } = require('../utils/resolveView')
const { cqn2cqn4sql } = require('../utils/cqn2cqn4sql')
const cds = require('../../cds')
const { SELECT } = cds.ql

const CHUNK_SIZE = cds.env.features.chunk_deep || Number.MAX_VALUE

/*
 * own utils
 */

const _isSameEntityInWhere = (where, target, persistentObj) => {
  for (let i = 0; i < where.length; i++) {
    if (where[i].xpr) {
      const res = _isSameEntityInWhere(where[i].xpr, target, persistentObj)
      if (!res) return res
      continue
    }
    if (!where[i] || !where[i].ref || !target.elements[where[i].ref]) {
      continue
    }
    const key = where[i].ref
    const val = where[i + 2].val
    const sign = where[i + 1]
    // eslint-disable-next-line
    if (target.elements[key].key && key in persistentObj && sign === '=' && val !== persistentObj[key]) {
      return false
    }
  }
  return true
}

const _isSameEntity = (cqn, req) => {
  const where = cqn.UPDATE.where || []
  const persistentObj = Array.isArray(req._.partialPersistentState)
    ? req._.partialPersistentState[0]
    : req._.partialPersistentState
  if (!persistentObj) {
    // If no data was found we don't know if it is the same entity
    return false
  }
  const target = getDBTable(req.target)
  if (target.name !== (cqn.UPDATE.entity.ref && cqn.UPDATE.entity.ref[0]) && target.name !== cqn.UPDATE.entity) {
    return false
  }
  return _isSameEntityInWhere(where, target, persistentObj)
}

const _getLinksOfCompTree = compositionTree => {
  const links = []
  for (const link of [...compositionTree.backLinks, ...compositionTree.customBackLinks]) {
    links.push(link.entityKey)
  }
  for (const compElement of compositionTree.compositionElements || []) {
    for (const link of [...compElement.backLinks, ...compElement.customBackLinks]) {
      links.push(link.targetKey)
    }
  }
  return links
}

const _whereKeys = keySet => {
  if (!keySet.length || !Object.keys(keySet[0]).length) return []

  const keys0 = Object.keys(keySet[0])
  const keys = { list: keys0.map(pk => ({ ref: [pk] })) }
  const values = {
    list: keySet.map(row => ({
      list: keys0.map(k => ({ val: row[k] }))
    }))
  }
  return [keys, 'in', values]
}

const _parentKey = (element, key) => {
  let links = [...element.customBackLinks, ...element.backLinks]
  if (element.is2one && links.some(l => l.for2one)) links = links.filter(l => l.for2one)
  return links.reduce((parentKey, customBackLink) => {
    // TODO: why Object.prototype.hasOwnProperty?
    parentKey[customBackLink.entityKey] = Object.prototype.hasOwnProperty.call(key, customBackLink.targetKey)
      ? key[customBackLink.targetKey]
      : customBackLink.targetVal

    // nested
    if (!parentKey[customBackLink.entityKey]) {
      const splitted = customBackLink.targetKey.split('_')
      let current
      let joined = ''
      while (splitted.length > 1) {
        if (joined) joined += '_'
        joined += splitted.shift()
        if (Object.prototype.hasOwnProperty.call(key, joined)) current = key[joined]
      }
      if (current) parentKey[customBackLink.entityKey] = current[splitted[0]]
    }

    return parentKey
  }, {})
}

const _findWhere = (data, where) => {
  return data.filter(entry => {
    return Object.keys(where).every(key => {
      return where[key] === entry[key]
    })
  })
}

const _keys = (entity, data) => {
  return data.map(entry => {
    return ctUtils.key(entity, entry)
  })
}

const _parentKeys = (element, keys) => {
  return keys.map(key => _parentKey(element, key)).filter(ele => Object.keys(ele).length)
}

const _subData = (data, prop) =>
  data &&
  data.reduce((result, entry) => {
    if (prop in entry) {
      const elementValue = ctUtils.val(entry[prop])
      result.push(...ctUtils.array(elementValue))
    }
    return result
  }, [])

const _getWhereObj = (row, links) => {
  return links.reduce((res, currentLink) => {
    if (Object.prototype.hasOwnProperty.call(row, currentLink.targetKey) && row[currentLink.targetKey] !== null)
      res[currentLink.entityKey] = row[currentLink.targetKey]
    return res
  }, {})
}

const _subWhere = (result, element) => {
  let where
  let links = [...element.backLinks, ...element.customBackLinks]
  if (element.is2one && links.some(l => l.for2one)) links = links.filter(l => l.for2one)
  if (result.length && links && links.length > 0) {
    where = {}
    const keys0 = Object.keys(_getWhereObj(result[0], links))
    if (keys0.length) {
      const keys = { list: keys0.map(pk => ({ ref: [pk] })) }
      for (let i = 0; i < result.length; i += CHUNK_SIZE) {
        const values = {
          list: result.slice(i, i + CHUNK_SIZE).map(row => ({
            list: keys0.map(k => {
              return { val: _getWhereObj(row, links)[k] }
            })
          }))
        }
        where[i] = [keys, 'in', values]
      }
    }
  }
  return where
}

const _mergeResults = (result, selectData, root, model, compositionTree, entityName) => {
  if (root) {
    return [...selectData, ...result]
  } else {
    const parent = model.definitions[compositionTree.target] || model.definitions[entityName]
    const assoc = (parent && parent.elements[compositionTree.name]) || {}
    return selectData.map(selectEntry => {
      if (assoc.is2one) {
        selectEntry[compositionTree.name] = selectEntry[compositionTree.name] || {}
      } else if (assoc.is2many) {
        selectEntry[compositionTree.name] = selectEntry[compositionTree.name] || []
      }
      const newData = _findWhere(result, _parentKey(compositionTree, selectEntry))
      if (assoc.is2one) {
        if (newData[0]) selectEntry[compositionTree.name] = Object.assign(selectEntry[compositionTree.name], newData[0])
        else selectEntry[compositionTree.name] = null
      } else if (assoc.is2many) {
        selectEntry[compositionTree.name].push(...newData)
      }
      return selectEntry
    })
  }
}

const _columns = (entity, data, compositionTree, selectAllColumns) => {
  const backLinkKeys = _getLinksOfCompTree(compositionTree)
  const columns = []
  for (const elementName in entity.elements) {
    const element = entity.elements[elementName]
    if (element.virtual || element.isAssociation) continue
    if (
      selectAllColumns ||
      element.key ||
      backLinkKeys.includes(element.name) ||
      (Array.isArray(data) && data.find(entry => element.name in entry))
    ) {
      columns.push({ ref: [element.name] })
    }
  }
  return columns
}

const _select = ({
  model,
  entityName,
  draft,
  alias,
  compositionTree,
  data,
  selectAllColumns,
  where,
  parentKeys,
  orderBy,
  singleton
}) => {
  const entity = model.definitions[entityName]
  const from = ctUtils.addDraftSuffix(draft, entity.name)
  const selectCQN = SELECT.from(from)
  if (alias) selectCQN.SELECT.from.as = alias
  selectCQN.SELECT.columns = _columns(entity, data, compositionTree, selectAllColumns)
  if (where) selectCQN.SELECT.where = where
  else if (parentKeys) selectCQN.SELECT.where = _whereKeys(parentKeys)
  if (orderBy) selectCQN.SELECT.orderBy = orderBy
  if (singleton) selectCQN.SELECT.limit = { rows: { val: 1 } }
  // REVISIT: remove once SELECT builder does flattening!
  return cqn2cqn4sql(selectCQN, model)
}

const _selectDeepUpdateData = async args => {
  const { model, compositionTree, entityName, data, root, selectData, tx, selectAllColumns, where, parentKeys } = args
  let result = []
  if (!where && parentKeys && parentKeys.length && Object.keys(parentKeys[0]).length) {
    const keys0 = Object.keys(parentKeys[0])
    const keys = { list: keys0.map(pk => ({ ref: [pk] })) }
    for (let i = 0; i < parentKeys.length; i += CHUNK_SIZE) {
      const values = {
        list: parentKeys.slice(i, i + CHUNK_SIZE).map(row => ({ list: keys0.map(k => ({ val: row[k] })) }))
      }
      const _args = { ...args, where: [keys, 'in', values], parentKeys: undefined }
      const selectCQN = _select(_args)
      result.push(...(await tx.run(selectCQN)))
    }
  } else if (where && !Array.isArray(where)) {
    for (let w of Object.values(where)) {
      const _args = { ...args, where: w }
      const selectCQN = _select(_args)
      result.push(...(await tx.run(selectCQN)))
    }
  } else {
    const selectCQN = _select(args)
    result = await tx.run(selectCQN)
  }
  if (!result.length) return Promise.resolve(result)

  const keys = _keys(model.definitions[entityName], result)
  await Promise.all(
    compositionTree.compositionElements.map(element => {
      if (element.skipPersistence) return Promise.resolve()
      if (data !== undefined && !data.find(entry => element.name in entry) && !(selectAllColumns && result.length))
        return Promise.resolve()
      const subs = {
        compositionTree: element,
        entityName: element.source,
        data: _subData(data, element.name),
        where: _subWhere(result, element),
        selectData: result,
        parentKeys: _parentKeys(element, keys),
        orderBy: false,
        root: false
      }

      // REVISIT: remove null elements
      subs.data = subs.data.filter(d => d)

      return _selectDeepUpdateData({ ...args, ...subs })
    })
  )

  return _mergeResults(result, selectData || [], root, model, compositionTree, entityName)
}

// if a view has an orderBy with renamed field, we need to resolve it
const _resolveOrderBy = (orderBy, transitions) => {
  // no resolved entity found
  if (!transitions?.length) return
  // if there are no renamed fields, no need to resolve
  if (!transitions[0].mapping.size) return
  if (orderBy) orderBy.map(el => (el.ref[0] = transitions[0].mapping.get(el.ref[0]).ref[0]))
}

/*
 * exports
 */

const selectDeepUpdateData = (service, model, req, selectAllColumns = false) => {
  const query = req.query
  // REVISIT this should be done somewhere before, so it is not done twice for deep updates
  const sqlQuery = cqn2cqn4sql(query, model)

  if (req && _isSameEntity(sqlQuery, req)) {
    return Promise.resolve(req._.partialPersistentState)
  }

  const from = getEntityNameFromUpdateCQN(sqlQuery)
  const alias = sqlQuery.UPDATE.entity.as
  const where = sqlQuery.UPDATE.where || []
  const entityName = ensureNoDraftsSuffix(from)
  const draft = entityName !== from
  const orderBy = req && req.target && req.target.query && req.target.query.SELECT && req.target.query.SELECT.orderBy
  _resolveOrderBy(orderBy, sqlQuery.UPDATE._transitions)
  const data = Object.assign({}, sqlQuery.UPDATE.data || {}, query.UPDATE.with || {})
  const compositionTree = getCompositionTree({
    definitions: model.definitions,
    rootEntityName: entityName, // REVISIT: drafts are resolved too eagerly
    resolveViews: !draft,
    service
  })

  return _selectDeepUpdateData({
    tx: cds.tx(req),
    model,
    compositionTree,
    entityName,
    data: [data],
    where,
    orderBy,
    draft,
    singleton: req && req.target && req.target._isSingleton,
    alias,
    selectAllColumns,
    root: true,
    service
  })
}

module.exports = {
  selectDeepUpdateData
}
