const cds = require('../../cds')

const { getCompositionTree } = require('./tree')
const ctUtils = require('./utils')

const { ensureNoDraftsSuffix } = require('../utils/draft')
const { getEntityNameFromDeleteCQN } = require('../utils/cqn')
const { cqn2cqn4sql } = require('../utils/cqn2cqn4sql')
const { getComp2oneParents } = require('../utils/csn')
const getColumns = require('../../db/utils/columns')

/*
 * own utils
 */

// Poor man's alias algorithm
// REVISIT: Extract and adapt the alias functionality from `expandCQNToJoin.js`: _adaptWhereOrderBy
const _recursivelyAliasRefs = (something, newAlias, oldAlias, subselect = false) => {
  if (Array.isArray(something)) return something.map(s => _recursivelyAliasRefs(s, newAlias, oldAlias, subselect))
  if (typeof something === 'object') {
    if (something.ref) {
      something = { ref: [...something.ref] }
      if (oldAlias && something.ref[0] === oldAlias) something.ref[0] = newAlias
      else if (!subselect) something.ref.unshift(newAlias)
    } else {
      something = Object.assign({}, something)
      for (const key in something) {
        if (key === 'from' || key === 'val') continue // Workaround: Deep delete to be rewritten
        something[key] = _recursivelyAliasRefs(something[key], newAlias, oldAlias, subselect || key === 'SELECT')
      }
    }
  }
  return something
}

function _getSubWhereAndEntities(element, parentWhere, draft, level = 0, compositionTree = {}) {
  const allBackLinks = [...element.backLinks, ...element.customBackLinks]
  let entity1, entity2
  const linksForWhere = allBackLinks.length ? allBackLinks : element.links

  const subWhere = linksForWhere.reduce((result, backLink) => {
    // exclude static values from subwhere
    if (backLink.entityKey && !backLink.targetKey && backLink.targetVal !== undefined) {
      return result
    }
    if (result.length > 0) {
      result.push('and')
    }

    entity1 = {
      alias: `ALIAS${level + 1}`,
      entityName: ctUtils.addDraftSuffix(draft, element.source),
      propertyName: backLink.entityKey
    }

    const res1 = backLink.entityKey ? { ref: [entity1.alias, entity1.propertyName] } : { val: backLink.entityVal }

    entity2 = {
      alias: `ALIAS${level}`,
      entityName: ctUtils.addDraftSuffix(draft, element.target || element.source),
      propertyName: backLink.targetKey
    }

    const res2 = backLink.targetKey ? { ref: [entity2.alias, entity2.propertyName] } : { val: backLink.targetVal }

    result.push(res1, '=', res2)
    return result
  }, [])

  const where = []
  if (!subWhere.length) return { where, entity1, entity2 }

  let whereKeys = _getWhereKeys(allBackLinks, entity1)
  const staticWhereValues = _getStaticWhere(allBackLinks, entity1)
  if (whereKeys.length === 0 && element.links.length === 1) {
    // add is null check for each unused backlink
    for (const ce of compositionTree.compositionElements || []) {
      if (ce.source !== element.source) continue
      if (ce.name === element.name) continue
      const wk = _getWhereKeys([...ce.backLinks, ...ce.customBackLinks], entity1, 'null')
      if (whereKeys.length === 0) whereKeys = wk
      else whereKeys.push('and', ...wk)
    }
  }

  if (whereKeys.length > 0) {
    where.push({ xpr: [...whereKeys] }, 'and')
  }
  if (staticWhereValues.length > 0) {
    where.push({ xpr: [...staticWhereValues] }, 'and')
  }
  where.push('exists', {
    SELECT: {
      columns: [{ val: 1, as: '_exists' }],
      from: { ref: [entity2.entityName], as: entity2.alias },
      where: parentWhere && parentWhere.length ? [{ xpr: [...parentWhere] }, 'and', { xpr: [...subWhere] }] : subWhere
    }
  })

  return {
    where,
    entity1,
    entity2
  }
}

function _getWhereKeys(allBackLinks, entity1, is) {
  return allBackLinks.reduce((result, backLink) => {
    // exclude static keys
    if (backLink.entityKey && !backLink.targetKey && backLink.targetVal !== undefined) {
      return result
    }
    if (result.length > 0) {
      result.push('or')
    }
    if (backLink.entityKey && is) {
      result.push({ ref: [entity1.alias, backLink.entityKey] }, 'is ' + is)
    } else if (backLink.entityVal !== undefined) {
      // static values should not be included
      result.pop()
    }
    return result
  }, [])
}

function _getStaticWhere(allBackLinks, entity1) {
  return allBackLinks.reduce((result, backLink) => {
    if (result.length > 0) {
      result.push('and')
    }
    if (backLink.entityKey && !backLink.targetKey && backLink.targetVal !== undefined) {
      result.push({ ref: [entity1.alias, backLink.entityKey] }, '=', { val: backLink.targetVal })
    }
    return result
  }, [])
}

const _addToCQNs = (cqns, subCQN, element, model, level) => {
  // REVISIT:
  // The compiler generates foreign-key constraints (if features.assert_integrity_type = 'DB')
  // and enables DELETE CASCADE. For these cases, the runtime doesn't need to delete compositions
  // manually, it's done by the database itself.
  // However, there are cases (unmanaged compositions), where this doesn't happen.
  // As a first step, the runtime will delete _all_ compositions regardless of the database.
  // In the future, the runtime can enable the deletion of only those compositions
  // which wouldn't be deleted by the database.
  cqns[level] = cqns[level] || []
  cqns[level].push(subCQN)
}

// unofficial config!
const DEEP_DELETE_MAX_RECURSION_DEPTH =
  (cds.env.features.recursion_depth && Number(cds.env.features.recursion_depth)) || 2

const _addSubCascadeDeleteCQN = (model, compositionTree, parentWhere, level, cqns, draft, elementMap = new Map()) => {
  for (const element of compositionTree.compositionElements) {
    if (element.skipPersistence) continue

    const fqn = compositionTree.source + ':' + element.name
    const seen = elementMap.get(fqn)
    if (seen && seen >= DEEP_DELETE_MAX_RECURSION_DEPTH) {
      // recursion -> abort
      continue
    }

    // REVISIT: sometimes element.target is undefined which leads to self join
    if (!element.target) element.target = compositionTree.source

    const { entity1, where } = _getSubWhereAndEntities(element, parentWhere, draft, level, compositionTree)
    if (where.length) {
      const subCQN = { DELETE: { from: { ref: [entity1.entityName], as: entity1.alias }, where: where } }

      _addToCQNs(cqns, subCQN, element, model, level)

      // Make a copy and do not share the same map among brother compositions
      // as we're only interested in deep recursions, not wide recursions.
      const newElementMap = new Map(elementMap)
      newElementMap.set(fqn, (seen && seen + 1) || 1)
      _addSubCascadeDeleteCQN(model, element, subCQN.DELETE.where, level + 1, cqns, draft, newElementMap)
    }
  }

  return cqns
}

/*
 * exports
 */

const hasDeepDelete = (model, cqn) => {
  const from = getEntityNameFromDeleteCQN(cqn)
  if (!from) return false

  // hidden flag for DELETEs on draft root, we have a separate mechanism that deletes the rows using the DraftUUID
  // Hence, we do not need a deep delete in that case.
  if (cqn._suppressDeepDelete) return false

  const entity = model.definitions[ensureNoDraftsSuffix(from)]

  if (entity) return !!Object.keys(entity.elements || {}).find(k => entity.elements[k].isComposition)

  return false
}

const resolveNavigationTarget = (cqn, ref, model) => {
  const lastTransition = cqn.UPDATE._transitions && cqn.UPDATE._transitions[cqn.UPDATE._transitions.length - 1]
  const target = lastTransition
    ? lastTransition.target
    : model.definitions[(cqn.UPDATE.entity.ref && cqn.UPDATE.entity.ref[0]) || cqn.UPDATE.entity]
  let elementName = ref[ref.length - 1].id || ref[ref.length - 1]
  const resolved = lastTransition && lastTransition.mapping && lastTransition.mapping.get(elementName)
  if (resolved) elementName = resolved.ref[0]
  return { target, elementName }
}

const _getDataFromOncond = (onCond, parent) => {
  return onCond.reduce((res, e) => {
    if (e.xpr) {
      return Object.assign(res, _getDataFromOncond(e.xpr, parent))
    }
    if (!e.ref || e.ref[0] !== '$$parent') return res
    const fk = e.ref.slice(1).join('_')
    if (!parent.keys[fk]) res[fk] = null
    return res
  }, {})
}

// eslint-disable-next-line complexity
const getSetNullParentForeignKeyCQNs = async (model, req, dbQuery) => {
  const cqns = []
  const query = dbQuery || req.query
  // REVISIT: req._tx should not be used like that!
  const origQuery = (req.tx.isDatabaseService && req._ && req._.query) || req.query
  if (!dbQuery && origQuery && origQuery.DELETE && origQuery.DELETE.from.ref && origQuery.DELETE.from.ref.length > 1) {
    // delete via 2one navigation => parent is known => no need to SELECT
    const ref = origQuery.DELETE.from.ref
    const cqn = cqn2cqn4sql(UPDATE.entity({ ref: ref.slice(0, ref.length - 1) }), model)
    const { target: parent, elementName } = resolveNavigationTarget(cqn, ref, model)
    const element = parent.elements[elementName]
    if (element && element.isComposition && element.is2one) {
      const onCond = element && parent._relations[element.name].join('$$whatever', '$$parent')
      const data = _getDataFromOncond(onCond, parent)
      cqn.data(data)
      cqn.__4delete = true
      if (Object.keys(data).length) cqns.push(cqn)
    }
  } else if (query.DELETE.where && query.DELETE.where.length) {
    // direct or internal request => parent is uknown => need to SELECT
    const entityName = getEntityNameFromDeleteCQN(query)
    const target = model.definitions[entityName]
    const comp2oneParents = getComp2oneParents(target, model)
    for (const element of comp2oneParents) {
      const parent = element.parent
      const onCond = parent._relations[element.name].join('$$child', '$$parent')
      const data = _getDataFromOncond(onCond, parent)
      const columns = getColumns(parent, { _4db: true, onlyKeys: true }).map(c => ({ ref: ['$$parent', c.name] }))
      const as = query.DELETE.from.as || (query.DELETE.from.ref && query.DELETE.from.ref[0]) || query.DELETE.from
      const selectCQN = SELECT.from(`${parent.name} as $$parent`)
        .join(`${element.target} as $$child`)
        .on(onCond)
        .columns(columns)
        .where(_recursivelyAliasRefs(query.DELETE.where, '$$child', as))
      const results = await cds.tx(req).run(selectCQN)
      if (results.length && Object.keys(data).length) {
        const cqn = UPDATE.entity(parent).data(data)
        for (const result of results) {
          const where = []
          for (const col of columns) {
            if (where.length) where.push('and')
            const ref = col.ref.slice(1)
            where.push({ ref }, '=', { val: result[ref[0]] })
          }
          cqn.UPDATE.where = where
          cqn.__4delete = true
          cqns.push(cqn)
        }
      }
    }
  }
  return cqns
}

const getDeepDeleteCQNs = async (model, req, dbQuery) => {
  const query = dbQuery || req.query
  const from = getEntityNameFromDeleteCQN(query)
  if (!from) return [[query]]

  const entityName = ensureNoDraftsSuffix(from)
  // REVISIT: baaad check!
  const draft = entityName !== from
  const compositionTree = getCompositionTree({
    definitions: model.definitions,
    rootEntityName: entityName,
    resolveViews: !draft,
    service: cds.db
  })
  const parentWhere = _recursivelyAliasRefs(
    query.DELETE.where,
    'ALIAS0',
    query.DELETE.from.as || (query.DELETE.from.ref && query.DELETE.from.ref[0]) || query.DELETE.from
  )
  const setNullUpdates =
    (model.definitions[entityName].own('__oneCompositionParents') &&
      (await getSetNullParentForeignKeyCQNs(model, req, dbQuery))) ||
    []
  const subCascadeDeletes = _addSubCascadeDeleteCQN(model, compositionTree, parentWhere, 0, [], draft)
  return [[query], ...subCascadeDeletes, setNullUpdates].reverse()
}

module.exports = {
  hasDeepDelete,
  getDeepDeleteCQNs,
  getSetNullParentForeignKeyCQNs
}
