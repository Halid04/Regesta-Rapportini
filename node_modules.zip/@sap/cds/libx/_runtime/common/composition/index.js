const { getCompositionTree, getCompositionRoot } = require('./tree')
const { hasDeepInsert, getDeepInsertCQNs } = require('./insert')
const { hasDeepUpdate, getDeepUpdateCQNs } = require('./update')
const { hasDeepDelete, getDeepDeleteCQNs, getSetNullParentForeignKeyCQNs } = require('./delete')
const { selectDeepUpdateData } = require('./data')

module.exports = {
  // tree
  getCompositionTree,
  getCompositionRoot,
  // insert
  hasDeepInsert,
  getDeepInsertCQNs,
  // update
  hasDeepUpdate,
  getDeepUpdateCQNs,
  // delete
  hasDeepDelete,
  getDeepDeleteCQNs,
  getSetNullParentForeignKeyCQNs,
  // data
  selectDeepUpdateData
}
