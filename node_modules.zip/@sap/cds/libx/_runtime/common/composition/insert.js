const cds = require('../../cds')

const { getCompositionTree } = require('./tree')
const ctUtils = require('./utils')

const { ensureNoDraftsSuffix } = require('../utils/draft')
const { deepCopyArray } = require('../utils/copy')

/*
 * own utils
 */

function _hasCompOrAssoc(entity, k) {
  // TODO once REST also uses same logic as odata structured check if we can omit 'entity.elements[k] &&'
  return entity.elements[k] && (entity.elements[k].is2one || entity.elements[k].is2many)
}

const _addSubDeepInsertCQN = (model, compositionTree, data, cqns, draft) => {
  compositionTree.compositionElements.forEach(element => {
    if (element.skipPersistence) {
      return
    }
    // element source must be changed in comp tree
    const subEntity = model.definitions[element.source]
    const into = ctUtils.addDraftSuffix(draft, subEntity.name)
    const insertCQN = { INSERT: { into: into, entries: [] } }
    const subData = data.reduce((result, entry) => {
      if (element.name in entry) {
        const elementValue = ctUtils.val(entry[element.name])
        if (elementValue != null) {
          // remove empty entries
          const subData = ctUtils.array(elementValue).filter(ele => Object.keys(ele).length > 0)
          if (subData.length > 0) {
            // REVISIT: this can make problems
            insertCQN.INSERT.entries.push(...ctUtils.cleanDeepData(subEntity, subData))
            result.push(...subData)
          }
        }
      }
      return result
    }, [])
    if (insertCQN.INSERT.entries.length > 0) {
      cqns.push(insertCQN)
    }
    if (subData.length > 0) {
      _addSubDeepInsertCQN(model, element, subData, cqns, draft)
    }
  })
  return cqns
}

/*
 * exports
 */

const _entityFromINSERT = (model, INSERT) => {
  if (INSERT && INSERT.into) {
    const into = (INSERT.into.ref && INSERT.into.ref[0]) || INSERT.into.name || INSERT.into
    const entityName = ensureNoDraftsSuffix(into)
    return model.definitions[entityName]
  }
}

const hasDeepInsert = (model, cqn) => {
  if (cqn.INSERT.entries) {
    const entity = _entityFromINSERT(model, cqn.INSERT)
    if (entity) {
      return !!cqn.INSERT.entries.find(entry => {
        return !!Object.keys(entry || {}).find(k => {
          return _hasCompOrAssoc(entity, k)
        })
      })
    }
  }
  return false
}

const getDeepInsertCQNs = (model, cqn) => {
  const into = (cqn.INSERT.into.ref && cqn.INSERT.into.ref[0]) || cqn.INSERT.into.name || cqn.INSERT.into
  const entityName = ensureNoDraftsSuffix(into)
  const draft = entityName !== into
  const dataEntries = cqn.INSERT.entries ? deepCopyArray(cqn.INSERT.entries) : []
  const entity = model.definitions[entityName]
  const compositionTree = getCompositionTree({
    definitions: model.definitions,
    rootEntityName: entityName,
    resolveViews: !draft,
    service: cds.db
  })

  const flattenedCqn = { INSERT: Object.assign({}, cqn.INSERT) }
  flattenedCqn.INSERT.entries = []

  dataEntries.forEach(dataEntry =>
    flattenedCqn.INSERT.entries.push(ctUtils.cleanDeepData(entity, Object.assign({}, dataEntry)))
  )

  return [flattenedCqn, ..._addSubDeepInsertCQN(model, compositionTree, dataEntries, [], draft)]
}

module.exports = {
  hasDeepInsert,
  getDeepInsertCQNs
}
