const cds = require('../../cds')

const { getCompositionTree } = require('./tree')
const { getDeepInsertCQNs } = require('./insert')
const { getDeepDeleteCQNs } = require('./delete')
const ctUtils = require('./utils')

const { ensureNoDraftsSuffix } = require('../utils/draft')
const { deepCopyObject } = require('../utils/copy')

const getError = require('../../common/error')
const { getEntityNameFromUpdateCQN } = require('../utils/cqn')

const CHUNK_SIZE = cds.env.features.chunk_deep || Number.MAX_VALUE

/*
 * own utils
 */

const _serializedKey = (entity, data) => {
  if (data === null) return 'null'

  return JSON.stringify(
    ctUtils
      .keyElements(entity)
      .map(key => key.name)
      .sort()
      .map(keyName => data[keyName])
  )
}

const _dataByKey = (entity, data) => {
  const dataByKey = new Map()
  for (const entry of data) {
    dataByKey.set(_serializedKey(entity, entry), entry)
  }
  return dataByKey
}

function _addSubDeepUpdateCQNForDelete({ entity, data, selectData, entityName, deleteCQNs }) {
  const dataByKey = _dataByKey(entity, data)
  if (selectData.length && selectData[0] && Object.keys(selectData[0]).length) {
    for (let j = 0; j < selectData.length; j += CHUNK_SIZE) {
      const deleteCQN = { DELETE: { from: entityName, where: [] } }
      for (let i = j; i < j + CHUNK_SIZE && i < selectData.length; i++) {
        const selectEntry = selectData[i]
        if (!selectEntry) continue
        const dataEntry = dataByKey.get(_serializedKey(entity, selectEntry))
        if (!dataEntry) {
          if (deleteCQN.DELETE.where.length > 0) {
            deleteCQN.DELETE.where.push('or')
          }
          deleteCQN.DELETE.where.push({ xpr: [...ctUtils.whereKey(ctUtils.key(entity, selectEntry))] })
        }
      }
      if (deleteCQN.DELETE.where.length) deleteCQNs.push(deleteCQN)
    }
  }
}

const _unwrapVal = obj => {
  for (const key in obj) {
    const value = obj[key]
    if (value && value.val) obj[key] = value.val
  }
  return obj
}

function _fillLinkFromStructuredData(entity, entry) {
  for (const elementName in entity.elements) {
    const _foreignKey4 = entity.elements._foreignKey4
    if (_foreignKey4 && entry[_foreignKey4]) {
      const foreignKey = entity.elements[elementName].name
      const childKey = foreignKey.split('_')[1]
      const val = _unwrapVal(entry[_foreignKey4])[childKey]
      if (val !== undefined) entry[foreignKey] = val
    }
  }
}

const _diffData = (newData, oldData, entity, newEntry, oldEntry, model) => {
  const result = {}

  const keysSet = new Set(Object.keys(newData).concat(Object.keys(oldData)))
  for (const key of keysSet.keys()) {
    const newVal = ctUtils.val(newData[key])
    const oldVal = ctUtils.val(oldData[key])

    if (newVal !== undefined && newVal !== oldVal) {
      if (!entity.elements[key]) continue

      if (entity.elements[key]._isStructured && Object.keys(newData[key]).length === 0) {
        // empty structured -> skip
        continue
      }

      result[key] = newData[key]
      continue
    }

    // comp2one removed?
    const fk = entity.elements[key] && entity.elements[key]._foreignKey4
    if (fk && newVal === undefined && oldVal !== undefined) {
      const nav = entity.elements[fk]
      // REVISIT: why check @cds.persistence.skip needed? bad tests?
      if (
        nav.isComposition &&
        nav.is2one &&
        newEntry[nav.name] !== undefined &&
        !model.definitions[nav.target]._hasPersistenceSkip
      ) {
        result[key] = null
      }
    }
  }

  return result
}

function _addSubDeepUpdateCQNForUpdateInsert({ entity, entityName, data, selectData, updateCQNs, insertCQN, model }) {
  const selectDataByKey = _dataByKey(entity, selectData)
  const deepUpdateData = []
  for (const entry of data) {
    if (entry === null) continue

    const key = ctUtils.key(entity, entry)
    const selectEntry = selectDataByKey.get(_serializedKey(entity, entry))
    _fillLinkFromStructuredData(entity, entry)
    if (selectEntry) {
      deepUpdateData.push(entry)
      const newData = ctUtils.cleanDeepData(entity, entry)
      const oldData = ctUtils.cleanDeepData(entity, selectEntry)
      const diff = _diffData(newData, oldData, entity, entry, selectEntry, model)
      // empty updates will be removed later
      updateCQNs.push({ UPDATE: { entity: entityName, data: diff, where: ctUtils.whereKey(key) } })
    } else {
      insertCQN.INSERT.entries.push(entry)
      // inserts are handled deep so they must not be put into deepUpdateData
    }
  }
  return deepUpdateData
}

async function _addSubDeepUpdateCQNCollect(model, cqns, updateCQNs, insertCQN, deleteCQNs, req) {
  if (updateCQNs.length > 0) {
    cqns[0] = cqns[0] || []
    cqns[0].push(...updateCQNs)
  }

  if (insertCQN.INSERT.entries.length > 0) {
    cqns[0] = cqns[0] || []
    const deepInsertCQNs = getDeepInsertCQNs(model, insertCQN)
    deepInsertCQNs.forEach(insertCQN => {
      const intoCQN = cqns[0].find(cqn => {
        return cqn.INSERT && cqn.INSERT.into === insertCQN.INSERT.into
      })
      if (!intoCQN) {
        cqns[0].push(insertCQN)
      } else {
        intoCQN.INSERT.entries.push(...insertCQN.INSERT.entries)
      }
    })
  }

  for (let deleteCQN of deleteCQNs) {
    if (deleteCQN.DELETE.where.length > 0) {
      cqns[0] = cqns[0] || []
      const deepDeleteCQNs = await getDeepDeleteCQNs(model, req, deleteCQN)
      deepDeleteCQNs.forEach((delCQNs, index) => {
        delCQNs.forEach(el => {
          cqns[index] = cqns[index] || []
          cqns[index].push(el)
        })
      })
    }
  }
}

const _unwrapIfNotArray = x => (Array.isArray(x) ? x : _unwrapVal(x))

const _addToData = (subData, entity, element, entry) => {
  const value = ctUtils.val(entry[element.name])
  const subDataEntries = ctUtils.array(value)
  const unwrappedSubData = subDataEntries.map(entry => _unwrapIfNotArray(entry))
  subData.push(...unwrappedSubData)
}

async function _addSubDeepUpdateCQNRecursion({ model, compositionTree, entity, data, selectData, cqns, draft, req }) {
  const selectDataByKey = _dataByKey(entity, selectData)

  for (const element of compositionTree.compositionElements) {
    const subData = []
    const selectSubData = []

    for (const entry of data) {
      if (element.name in entry) {
        const selectEntry = selectDataByKey.get(_serializedKey(entity, entry))

        if (selectEntry && element.name in selectEntry) {
          if (selectEntry[element.name] === null && entry[element.name] === null) {
            continue
          }
          _addToData(selectSubData, entity, element, selectEntry)
        }

        _addToData(subData, entity, element, entry)
      }
    }

    await _addSubDeepUpdateCQN({
      model,
      compositionTree: element,
      data: subData,
      selectData: selectSubData,
      cqns,
      draft,
      req
    })
  }

  return cqns
}

const _addSubDeepUpdateCQN = async ({ model, compositionTree, data, selectData, cqns, draft, req }) => {
  // We handle each level for deepUpdate, the moment we see that there will be an INSERT,
  // it'll be removed from our deepUpdateData (and handled deep separately).
  const entity = model.definitions[compositionTree.source]

  if (entity._hasPersistenceSkip) return Promise.resolve()

  const entityName = ctUtils.addDraftSuffix(draft, entity.name)
  const updateCQNs = []
  const insertCQN = { INSERT: { into: entityName, entries: [] } }
  const deleteCQNs = []
  _addSubDeepUpdateCQNForDelete({ entity, data, selectData, entityName, deleteCQNs })
  const deepUpdateData = _addSubDeepUpdateCQNForUpdateInsert({
    entity,
    entityName,
    data,
    selectData,
    updateCQNs,
    insertCQN,
    model
  })

  await _addSubDeepUpdateCQNCollect(model, cqns, updateCQNs, insertCQN, deleteCQNs, req)

  if (deepUpdateData.length === 0) return Promise.resolve()

  return _addSubDeepUpdateCQNRecursion({
    model,
    compositionTree,
    entity,
    data: deepUpdateData,
    selectData,
    cqns,
    draft,
    req
  })
}

/*
 * exports
 */

const hasDeepUpdate = (model, cqn) => {
  if (cqn && cqn.UPDATE && cqn.UPDATE.entity && (cqn.UPDATE.data || cqn.UPDATE.with)) {
    const entityName = getEntityNameFromUpdateCQN(cqn)
    const entity = model.definitions[ensureNoDraftsSuffix(entityName)]

    if (entity) {
      const keys = Object.keys(Object.assign({}, cqn.UPDATE.data || {}, cqn.UPDATE.with || {}))
      return !!keys.find(k => ctUtils.isCompOrAssoc(entity, k))
    }
  }

  return false
}

const getDeepUpdateCQNs = async (model, req, selectData) => {
  const { query } = req
  if (!Array.isArray(selectData)) selectData = [selectData]

  if (selectData.length === 0) return []

  if (selectData.length > 1) throw getError('Deep update can only be performed on a single instance')

  const cqns = []
  const from = getEntityNameFromUpdateCQN(query)
  const entityName = ensureNoDraftsSuffix(from)
  const draft = entityName !== from
  const data = query.UPDATE.data ? deepCopyObject(query.UPDATE.data) : {}
  const withObj = query.UPDATE.with ? deepCopyObject(query.UPDATE.with) : {}
  const entity = model.definitions[entityName]
  const entry = Object.assign({}, data, withObj, ctUtils.key(entity, selectData[0]))
  const compositionTree = getCompositionTree({
    definitions: model.definitions,
    rootEntityName: entityName,
    resolveViews: !draft,
    service: cds.db
  })

  const subCQNs = await _addSubDeepUpdateCQN({
    model,
    compositionTree,
    data: [entry],
    selectData,
    cqns: [],
    draft,
    req
  })
  subCQNs.forEach((subCQNs, index) => {
    cqns[index] = cqns[index] || []
    cqns[index].push(...subCQNs)
  })

  // remove empty updates and inserts
  return cqns
    .map(cqns => {
      return cqns.filter(cqn => {
        if (!cqn.UPDATE && !cqn.INSERT) return true
        if (cqn.UPDATE) return Object.keys(cqn.UPDATE.data).length > 0
        if (!cqn.INSERT.entries || cqn.INSERT.entries.length > 1) return true
        return Object.keys(cqn.INSERT.entries[0]).length > 0
      })
    })
    .filter(cqns => cqns.length > 0)
}

module.exports = {
  hasDeepUpdate,
  getDeepUpdateCQNs
}
