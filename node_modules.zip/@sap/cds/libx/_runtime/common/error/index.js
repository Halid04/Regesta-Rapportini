const entry = require('./entry')

module.exports = (...args) => {
  let e = entry(...args)
  if (!(e instanceof Error)) e = Object.assign(new Error(e.message), e)
  // _thrownByFramework shouldn't be logged
  Object.defineProperty(e, '_thrownByFramework', {
    value: true,
    enumerable: false
  })
  return e
}
