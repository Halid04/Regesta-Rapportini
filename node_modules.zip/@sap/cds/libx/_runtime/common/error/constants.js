module.exports = {
  ALLOWED_PROPERTIES_MAP: { code: 1, message: 1, target: 1, details: 1, innererror: 1 },
  ADDITIONAL_MSG_PROPERTIES_MAP: { numericSeverity: 1, longtextUrl: 1, transition: 1 },
  /*
   * severities:
   *   1: success
   *   2: info
   *   3: warning
   *   4: error
   */
  DEFAULT_SEVERITY: 2,
  MIN_SEVERITY: 1,
  MAX_SEVERITY: 4,
  MULTIPLE_ERRORS: 'MULTIPLE_ERRORS'
}
