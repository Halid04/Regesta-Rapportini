/*
 * OData spec:
 *   This object MUST contain name/value pairs with the names code and message,
 *   and it MAY contain name/value pairs with the names target, details and innererror.
 *   [...]
 *   Error responses MAY contain annotations in any of its JSON objects.
 */
const localeFrom = require('../../../../lib/req/locale')
const { getErrorMessage } = require('./utils')
let _i18n
const i18n = (...args) => {
  if (!_i18n) _i18n = require('../i18n')
  return _i18n(...args)
}

const {
  ALLOWED_PROPERTIES_MAP,
  ADDITIONAL_MSG_PROPERTIES_MAP,
  DEFAULT_SEVERITY,
  MIN_SEVERITY,
  MAX_SEVERITY
} = require('./constants')
const ADDITIONAL_MSG_PROPERTIES = Object.keys(ADDITIONAL_MSG_PROPERTIES_MAP)

const _getFiltered = err => {
  const error = {}

  Object.keys(err)
    .concat(['message'])
    .forEach(k => {
      if (k in ALLOWED_PROPERTIES_MAP || k.startsWith('@')) {
        error[k] = err[k]
      } else if (k === 'numericSeverity') {
        error['@Common.numericSeverity'] = err[k]
      }
    })

  return error
}

const _rewriteDBError = error => {
  // REVISIT: db stuff probably shouldn't be here
  if (error.code === 'SQLITE_ERROR') {
    error.code = 'null'
  } else if (
    (error.code.startsWith('SQLITE_CONSTRAINT') && error.message.match(/COMMIT/)) ||
    (error.code.startsWith('SQLITE_CONSTRAINT') && error.message.match(/FOREIGN KEY/)) ||
    (error.code === '155' && error.message.match(/fk constraint violation/))
  ) {
    // > foreign key constaint violation no sqlite/ hana
    error.code = '400'
    error.message = i18n('FK_CONSTRAINT_VIOLATION')
  } else if (error.code.startsWith('ASSERT_')) {
    error.code = '400'
  }
}

const _normalize = (err, locale, inner = false) => {
  // message (i18n)
  err.message = getErrorMessage(err, locale)

  // only allowed properties
  const error = _getFiltered(err)

  // ensure code is set and a string
  error.code = String(error.code || 'null')

  // REVISIT: code and message rewriting
  _rewriteDBError(error)

  let statusCode = err.status || err.statusCode || (_isAllowedError(error.code) && error.code)

  // details
  if (!inner && err.details) {
    const childErrorCodes = new Set()
    error.details = err.details.map(ele => {
      const { error: childError, statusCode: childStatusCode } = _normalize(ele, locale, true)
      childErrorCodes.add(childStatusCode)
      return childError
    })
    statusCode = statusCode || _statusCodeFromDetails(childErrorCodes)
  }

  // make sure it's a number if set, otherwise will be assigned as 500 in normalizeError
  statusCode = statusCode ? Number(statusCode) : undefined

  return { error, statusCode }
}

const _isAllowedError = errorCode => {
  return errorCode >= 300 && errorCode < 505
}

// - for one unique value, we use it
// - if at least one 5xx exists, we use 500
// - else if at least one 4xx exists, we use 400
const _statusCodeFromDetails = uniqueStatusCodes => {
  if (uniqueStatusCodes.size === 1) return uniqueStatusCodes.values().next().value
  if ([...uniqueStatusCodes].some(s => s >= 500)) return 500
  if ([...uniqueStatusCodes].some(s => s >= 400)) return 400
}

const normalizeError = (err, req) => {
  const locale = req.locale || (req.locale = localeFrom(req))
  let { error, statusCode } = _normalize(err, locale)

  if ((!statusCode || (statusCode >= 500 && err._thrownByFramework)) && process.env.NODE_ENV === 'production') {
    // > return sanitized error to client
    return {
      error: { code: statusCode ? `${statusCode}` : '500', message: i18n(statusCode || 500, locale) },
      statusCode: Number(statusCode) || 500
    }
  }

  if (!statusCode) statusCode = 500

  // no top level null codes
  if (error.code === 'null') {
    error.code = String(statusCode)
  }

  return { error, statusCode }
}

const _ensureSeverity = arg => {
  if (typeof arg === 'number' && arg >= MIN_SEVERITY && arg <= MAX_SEVERITY) {
    return arg
  }

  return DEFAULT_SEVERITY
}

const _normalizeMessage = (message, locale) => {
  const { error: normalized } = _normalize(message, locale)

  // numericSeverity without @Common
  normalized.numericSeverity = _ensureSeverity(message.numericSeverity)
  delete normalized['@Common.numericSeverity']

  ADDITIONAL_MSG_PROPERTIES.forEach(k => {
    if (message[k] && typeof message[k] === 'string') {
      normalized[k] = message[k]
    }
  })

  return normalized
}

const getSapMessages = (messages, req) => {
  const locale = req.locale || (req.locale = localeFrom(req))
  const s = JSON.stringify(messages.map(message => _normalizeMessage(message, locale)))
  // convert non ascii to unicode
  return s.replace(/[\u007F-\uFFFF]/g, chr => {
    return '\\u' + ('0000' + chr.charCodeAt(0).toString(16)).substr(-4)
  })
}

const isClientError = e => {
  // e.code may be undefined, string, number, ... -> NaN -> not a client error
  const numericCode = e.statusCode || e.status || Number(e.code)
  return numericCode >= 400 && numericCode < 500
}

module.exports = {
  normalizeError,
  getSapMessages,
  isClientError
}
