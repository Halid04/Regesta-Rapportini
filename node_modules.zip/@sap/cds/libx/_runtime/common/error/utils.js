let _i18n
// REVISIT does it really make sense to delay i18n require here?
const i18n = (...args) => {
  if (!_i18n) _i18n = require('../i18n')
  return _i18n(...args)
}

/**
 * Gets the localized error message for an error based on message, code, statusCode or status
 * @param {*} error
 * @param {*} locale can be undefined for default language
 * @returns localized error message
 */
function getErrorMessage(error, locale) {
  return (
    i18n(error.message || error.code || error.status || error.statusCode, locale, error.args) ||
    error.message ||
    `${error.code || error.status || error.statusCode}`
  )
}

module.exports = {
  getErrorMessage
}
