const _getLocalName = definition => {
  return definition._service ? definition.name.replace(`${definition._service.name}.`, '') : definition.name
}

const _getRestrictWithEventRewrite = (grant, to, where, target) => {
  // REVISIT: req.event should be 'SAVE' and 'PREPARE'
  if (grant === 'SAVE') grant = 'draftActivate'
  else if (grant === 'PREPARE') grant = 'draftPrepare'
  return { grant, to, where, target }
}

const WRITE = ['CREATE', 'UPDATE', 'DELETE']

const _addNormalizedRestrictPerGrant = (grant, where, restrict, restricts, definition) => {
  const to = restrict.to ? (Array.isArray(restrict.to) ? restrict.to : [restrict.to]) : ['any']

  if (definition.kind === 'entity') {
    if (grant === 'WRITE') {
      WRITE.forEach(g => {
        restricts.push(_getRestrictWithEventRewrite(g, to, where, definition))
      })
    } else {
      restricts.push(_getRestrictWithEventRewrite(grant, to, where, definition))
    }
  } else {
    restricts.push({ grant: _getLocalName(definition), to, where, target: definition.parent })
  }
}

const _addNormalizedRestrict = (restrict, restricts, definition) => {
  const where = restrict.where
    ? restrict.where.replace(/\$user/g, '$user.id').replace(/\$user\.id\./g, '$user.')
    : undefined

  restrict.grant = Array.isArray(restrict.grant) ? restrict.grant : [restrict.grant || '*']
  restrict.grant.forEach(grant => _addNormalizedRestrictPerGrant(grant, where, restrict, restricts, definition))
}

const getNormalizedRestrictions = (definition, definitions) => {
  const restricts = []
  let isRestricted = false

  // own
  if (definition['@restrict']) {
    isRestricted = true
    definition['@restrict'].forEach(restrict => _addNormalizedRestrict(restrict, restricts, definition))
  }

  // bounds
  const actions = definition.actions

  if (actions && Object.keys(actions).some(k => actions[k]['@restrict'])) {
    for (const k in actions) {
      const action = actions[k]

      if (action['@restrict']) {
        const restrictions = getNormalizedRestrictions(action, definitions)
        if (restrictions) {
          isRestricted = true
          restricts.push(...restrictions)
        }
      } else if (!definition['@restrict']) {
        // > no entity-level restrictions => unrestricted action
        isRestricted = true
        restricts.push({ grant: action.name, to: ['any'], target: action.parent })
      }
    }
  }

  return isRestricted ? restricts : null
}

const _isGrantAccessAllowed = (eventName, restrict) => restrict.grant === '*' || restrict.grant === eventName
const _isToAccessAllowed = (user, restrict) => restrict.to.some(role => user.is(role))

const getApplicableRestrictions = (restrictions, event, user) => {
  return restrictions.filter(restrict => {
    const eventName = { NEW: 'CREATE', EDIT: 'UPDATE' }[event] || event
    return _isGrantAccessAllowed(eventName, restrict) && _isToAccessAllowed(user, restrict)
  })
}

const getNormalizedPlainRestrictions = (restrictions, definition) => {
  const result = []
  for (const restriction of restrictions) _addNormalizedRestrict(restriction, result, definition)
  return result
}

module.exports = {
  getNormalizedRestrictions,
  getApplicableRestrictions,
  getNormalizedPlainRestrictions
}
