const { MOD_EVENTS, WRITE_EVENTS, CRUD_EVENTS, DRAFT_EVENTS } = require('../../constants/events')

const RESTRICTIONS = {
  CREATE: 'InsertRestrictions.Insertable',
  READ: 'ReadRestrictions.Readable',
  READABLE_BY_KEY: 'ReadRestrictions.ReadByKeyRestrictions.Readable',
  UPDATE: 'UpdateRestrictions.Updatable',
  DELETE: 'DeleteRestrictions.Deletable'
}

module.exports = {
  MOD_EVENTS,
  WRITE_EVENTS,
  CRUD_EVENTS,
  DRAFT_EVENTS,
  RESTRICTIONS
}
