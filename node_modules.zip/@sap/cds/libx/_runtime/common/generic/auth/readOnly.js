const cds = require('../../../cds')
const { getAuthRelevantEntity } = require('./utils')
const { WRITE_EVENTS } = require('./constants')

const _isAutoexposed = entity => {
  if (!entity) return false
  return (entity['@cds.autoexpose'] && entity['@cds.autoexposed']) || entity.name.match(/\.DraftAdministrativeData$/)
}

function handler(req) {
  // autoexposed
  const isAutoexposed = _isAutoexposed(req.target)
  if (isAutoexposed && req.event !== 'READ') {
    req.reject(405, 'ENTITY_IS_AUTOEXPOSED', [req.target.name])
  }

  // @read-only
  let entity = getAuthRelevantEntity(req, this.model, ['@readonly'])
  if (cds.env.fiori.lean_draft && (req.event === 'NEW' || req.event === 'UPDATE')) entity = entity?.actives

  if (!entity || !entity['@readonly']) return
  if (entity['@readonly'] && req.event in WRITE_EVENTS) req.reject(405, 'ENTITY_IS_READ_ONLY', [entity.name])
}

handler._initial = true

module.exports = handler
