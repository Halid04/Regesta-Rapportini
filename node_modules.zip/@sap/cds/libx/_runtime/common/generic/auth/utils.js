const cds = require('../../../cds')
const LOG = cds.log('app')

const { CRUD_EVENTS } = require('./constants')

const { getDraftTreeRoot } = require('../../utils/csn')

const reject = (req, reason = null) => {
  // unauthorized or forbidden?
  if (req.user._is_anonymous) {
    // REVISIT: challenges handling should be done in protocol adapter (i.e., express error middleware)
    // REVISIT: improve `req.http.req` check if this is an HTTP request
    if (req.http?.req && req.user._challenges && req.user._challenges.length > 0) {
      req.http.res.set('WWW-Authenticate', req.user._challenges.join(';'))
    }

    // REVISIT: security log in else case?
    return req.reject(401)
  }

  return req.reject({
    code: 403,
    internal: reason
  })
}

const getRejectReason = (req, annotation, definition, restrictedCount, unrestrictedCount) => {
  if (!LOG._debug) return
  // it is not possible to specify the reason further than the source as there are multiple factors
  const appendix = unrestrictedCount
    ? ` (${unrestrictedCount - restrictedCount} out of ${unrestrictedCount} instances are restricted)`
    : ''
  return {
    reason: `Access denied to user "${req.user.id}" for event "${req.event}"${appendix}`,
    source: `${annotation} of "${definition.name}"`
  }
}

const _getCurrentSubClause = (next, restrict) => {
  const escaped = next[0].replace(/\$/g, '\\$').replace(/\./g, '\\.')
  const re1 = new RegExp(`([\\w\\.']*)\\s*=\\s*(${escaped})|(${escaped})\\s*=\\s*([\\w\\.']*)`)
  const re2 = new RegExp(`([\\w\\.']*)\\s*in\\s*(${escaped})|(${escaped})\\s*in\\s*([\\w\\.']*)`)
  const re3 = new RegExp(`(${escaped})\\s*is\\s*null`)
  const re4 = new RegExp(`(${escaped})\\s*is\\s*not\\s*null`)
  const clause =
    restrict.where.match(re3) || restrict.where.match(re4) || restrict.where.match(re1) || restrict.where.match(re2)

  if (clause) return clause

  // NOTE: arrayed attr with "=" as operator is some kind of legacy case
  throw new Error('user attribute array must be used with operator "=", "in", "is null", or "is not null"')
}

const _isNull = (userAttrs, attr) =>
  userAttrs[attr] == null || (Array.isArray(userAttrs[attr]) && userAttrs[attr].length === 0)
const _isNotNull = (userAttrs, attr) =>
  userAttrs[attr] != null && Array.isArray(userAttrs[attr]) && userAttrs[attr].length > 0

const _processUserAttr = (next, restrict, userAttrs, attr) => {
  const clause = _getCurrentSubClause(next, restrict)
  const valOrRef = clause[1] || clause[4]

  if (clause[0].match(/ is\s*null/)) {
    restrict.where = restrict.where.replace(clause[0], _isNull(userAttrs, attr) ? '1 = 1' : '1 = 2')
  } else if (clause[0].match(/ is\s*not\s*null/)) {
    restrict.where = restrict.where.replace(clause[0], _isNotNull(userAttrs, attr) ? '1 = 1' : '1 = 2')
  } else {
    if (_isNull(userAttrs, attr)) {
      restrict.where = restrict.where.replace(clause[0], '1 = 2')
    } else if (clause[0].match(/ in /)) {
      if (userAttrs[attr].length === 1) {
        restrict.where = restrict.where.replace(clause[0], `${valOrRef} = '${userAttrs[attr][0]}'`)
      } else {
        restrict.where = restrict.where.replace(
          clause[0],
          `${valOrRef} in (${userAttrs[attr].map(ele => `'${ele}'`).join(', ')})`
        )
      }
    } else if (valOrRef.startsWith("'") && userAttrs[attr].includes(valOrRef.split("'")[1])) {
      restrict.where = restrict.where.replace(clause[0], `${valOrRef} = ${valOrRef}`)
    } else {
      restrict.where = restrict.where.replace(
        clause[0],
        `(${userAttrs[attr].map(ele => `${valOrRef} = '${ele}'`).join(' or ')})`
      )
    }
  }
}

/*
 * for supporting xssec v3
 */
const _getAttrsAsProxy = (attrs, additional = {}) => {
  return new Proxy(
    {},
    {
      get: function (_, attr) {
        if (attr in additional) return additional[attr]
        return attrs[attr]
      }
    }
  )
}

/*
 * resolves user attributes deeply, even though nested attributes are officially not supported
 */
const resolveUserAttrs = (restrict, req) => {
  const _getNext = where => where.match(/\$user\.([\w.]*)/)
  let next = _getNext(restrict.where)

  while (next !== null) {
    const parts = next[1].split('.')
    let skip
    let val
    let attrs = _getAttrsAsProxy(req.user.attr, { id: req.user.id })
    let attr = parts.shift()

    while (attr) {
      if (attrs[attr] === undefined || Array.isArray(attrs[attr])) {
        _processUserAttr(next, restrict, attrs, attr)
        skip = true
        break
      }

      val = !Number.isNaN(Number(attrs[attr])) && attr !== 'id' ? attrs[attr] : `'${attrs[attr]}'`
      if (val === null || val === undefined) break

      attrs = _getAttrsAsProxy(attrs[attr])
      attr = parts.shift()
    }

    if (!skip) {
      const v = val === undefined ? null : typeof val === 'string' && val.match(/^\d*$/) ? `'${val}'` : val
      restrict.where = restrict.where.replace(next[0], v).replace('in null', 'is null')
    }

    next = _getNext(restrict.where)
  }

  return restrict
}

const _authDependsOnParent = (entity, annotations) => {
  // @cds.autoexposed and not @cds.autoexpose -> not explicitly exposed by modeling
  return (
    entity.name.match(/\.DraftAdministrativeData$/) ||
    (entity['@cds.autoexposed'] && !entity['@cds.autoexpose'] && !annotations.some(a => a in entity))
  )
}

const cqnFrom = req => {
  const { query } = req
  if (!query) return
  if (query.SELECT) return query.SELECT.from
  if (query.INSERT) return query.INSERT.into
  if (query.UPDATE) return query.UPDATE.entity
  if (query.DELETE) return query.DELETE.from
}

const getAuthRelevantEntity = (req, model, annotations) => {
  if (!req.target || !(req.event in CRUD_EVENTS)) return
  if (!_authDependsOnParent(req.target, annotations)) return req.target

  let cqn = cqnFrom(req)

  // REVISIT: needed in draft for some reason
  if (typeof cqn === 'string') cqn = { ref: [cqn] }

  if (cqn.ref.length === 1 && req.target._isDraftEnabled) {
    // > direct access to children in draft
    const root = getDraftTreeRoot(req.target, model)
    if (!root)
      reject(
        req,
        LOG._debug ? { reason: `Unable to determine single draft tree root for entity "${req.target.name}"` } : null
      )
    return root
  }

  // find and return the restrictions (may be none!) of the right-most entity that is non-autoexposed or explicitly restricted
  const segments = []
  let current = { elements: model.definitions }
  for (let i = 0; i < cqn.ref.length; i++) {
    current = current.elements[cqn.ref[i].id || cqn.ref[i]]
    if (current && current.target) current = model.definitions[current.target]
    segments.push(current)
  }
  let authRelevantEntity
  for (let i = segments.length - 1; i >= 0; i--) {
    const segment = segments[i]
    if (segment.kind === 'entity' && !_authDependsOnParent(segment, annotations)) {
      authRelevantEntity = segment
      break
    }
  }
  return authRelevantEntity
}

module.exports = {
  reject,
  getRejectReason,
  resolveUserAttrs,
  cqnFrom,
  getAuthRelevantEntity
}
