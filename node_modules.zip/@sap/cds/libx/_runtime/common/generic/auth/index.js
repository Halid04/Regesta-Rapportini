const cds = require('../../../cds')

const requiresHandler = require('./requires')
const readOnlyHandler = require('./readOnly')
const insertOnlyHandler = require('./insertOnly')
const capabilitiesHandler = require('./capabilities')
const restrictHandler = require('./restrict')
const restrictExpandHandler = require('./expand')

module.exports = cds.service.impl(function authorization() {
  /*
   * @requires
   */
  this.before('*', requiresHandler)

  /*
   * access control (cheaper than @restrict -> do first)
   */
  this.before('*', readOnlyHandler)
  this.before('*', insertOnlyHandler)
  this.before('*', capabilitiesHandler)

  /*
   * @restrict
   */
  this.before('*', restrictHandler)

  /*
   * expand restrictions
   */
  this.before('READ', '*', restrictExpandHandler)
})
