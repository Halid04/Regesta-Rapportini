const { cqnFrom } = require('./utils')
const { RESTRICTIONS } = require('./constants')

const _isRestricted = (req, capability, capabilityReadByKey) => {
  if (capabilityReadByKey !== undefined && req.query.SELECT && req.query.SELECT.one) {
    return capabilityReadByKey === false
  }
  return capability === false
}

const _isNavigationRestricted = (target, path, annotation, req) => {
  if (!target) return
  if (!Array.isArray(target['@Capabilities.NavigationRestrictions.RestrictedProperties'])) return

  const [restriction, operation] = annotation.split('.')
  for (const r of target['@Capabilities.NavigationRestrictions.RestrictedProperties']) {
    // prefix check to support both notations: { InsertRestrictions: { Insertable: false } } and { InsertRestrictions.Insertable: false }
    if (r.NavigationProperty['='] === path && Object.keys(r).some(k => k.startsWith(restriction))) {
      const capability = r[annotation] ?? r[restriction]?.[operation]
      return _isRestricted(req, capability, r.ReadRestrictions?.['ReadByKeyRestrictions.Readable'])
    }
  }
}

const _localName = entity => entity.name.replace(entity._service.name + '.', '')

function handler(req) {
  // TODO: Determine auth-relevant entity
  const annotation = RESTRICTIONS[req.event]

  if (!req.target || !annotation) return

  const action = annotation.split('.').pop().toUpperCase()
  const from = cqnFrom(req)
  const nav = (from && from.ref && from.ref.map(el => el.id || el)) || []

  if (nav.length > 1) {
    const path = nav.slice(1).join('.')
    const target = this.model.definitions[nav[0]]
    if (_isNavigationRestricted(target, path, annotation, req)) {
      // REVISIT: rework exception with using target
      const trgt = `${_localName(target)}.${path}`
      req.reject(405, 'ENTITY_IS_NOT_CRUD_VIA_NAVIGATION', [_localName(req.target), action, trgt])
    }
  } else if (
    _isRestricted(
      req,
      req.target['@Capabilities.' + annotation],
      req.target['@Capabilities.' + RESTRICTIONS.READABLE_BY_KEY]
    )
  ) {
    req.reject(405, 'ENTITY_IS_NOT_CRUD', [_localName(req.target), action])
  }
}

handler._initial = true

module.exports = handler
