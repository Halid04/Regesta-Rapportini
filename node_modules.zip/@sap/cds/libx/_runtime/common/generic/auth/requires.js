const { reject, getRejectReason, getAuthRelevantEntity } = require('./utils')
const { CRUD_EVENTS } = require('./constants')

const { getRequiresAsArray } = require('../../../auth/utils')

function handler(req) {
  if (req.user._is_privileged) {
    // > skip checks
    return
  }

  let definition
  if (req.event in CRUD_EVENTS) {
    // > CRUD
    definition = getAuthRelevantEntity(req, this.model, ['@requires', '@restrict'])
  } else if (req.target && req.target.actions) {
    // > bound
    definition = req.target.actions[req.event]
  } else {
    // > unbound
    definition = this.operations[req.event]
  }

  if (!definition) return

  const requires = getRequiresAsArray(definition)
  if (!requires || requires.some(role => req.user.is(role))) return

  reject(req, getRejectReason(req, '@requires', definition))
}

handler._initial = true

module.exports = handler
