const cds = require('../../../cds')

const { reject, getRejectReason, resolveUserAttrs, getAuthRelevantEntity } = require('./utils')
const { DRAFT_EVENTS, MOD_EVENTS } = require('./constants')
const { getNormalizedPlainRestrictions } = require('./restrictions')

const { cqn2cqn4sql } = require('../../utils/cqn2cqn4sql')

const { isActiveEntityRequested, removeIsActiveEntityRecursively } = require('../../../fiori/utils/where')

const _getResolvedApplicables = (applicables, req) => {
  const resolvedApplicables = []

  // REVISIT: the static portion of "mixed wheres" could already grant access -> optimization potential
  for (const restrict of applicables) {
    // replace $user.x with respective values
    const resolved = resolveUserAttrs({ grant: restrict.grant, target: restrict.target, where: restrict.where }, req)

    // check for duplicates
    if (
      !resolvedApplicables.find(
        restrict =>
          resolved.grant === restrict.grant &&
          (!resolved.target || resolved.target === restrict.target) &&
          (!resolved.where || resolved.where === restrict.where)
      )
    ) {
      if (resolved.where) {
        resolved._xpr = cds.parse.expr(resolved.where).xpr
        if (!resolved._xpr)
          req.reject(400, `Exists predicate is missing in the association path "${resolved.where}" in @restrict.where`)
      }
      resolvedApplicables.push(resolved)
    }
  }

  return resolvedApplicables
}

const _isStaticAuth = resolvedApplicables => {
  return (
    resolvedApplicables.length === 1 &&
    resolvedApplicables[0]._xpr.length === 3 &&
    resolvedApplicables[0]._xpr.every(ele => typeof ele !== 'object' || ele.val)
  )
}

const _evalStatic = (op, vals) => {
  vals[0] = Number.isNaN(Number(vals[0])) ? vals[0] : Number(vals[0])
  vals[1] = Number.isNaN(Number(vals[1])) ? vals[1] : Number(vals[1])

  switch (op) {
    case '=':
      return vals[0] === vals[1]
    case '!=':
    case '<>':
      return vals[0] !== vals[1]
    case '<':
      return vals[0] < vals[1]
    case '<=':
      return vals[0] <= vals[1]
    case '>':
      return vals[0] > vals[1]
    case '>=':
      return vals[0] >= vals[1]
    default:
      throw new Error(`Operator "${op}" is not supported in @restrict.where`)
  }
}

const _handleStaticAuth = (resolvedApplicables, req) => {
  const op = resolvedApplicables[0]._xpr.find(ele => typeof ele === 'string')
  const vals = resolvedApplicables[0]._xpr.filter(ele => typeof ele === 'object' && ele.val).map(ele => ele.val)

  if (_evalStatic(op, vals)) {
    // static clause grants access => done
    return
  }

  // static clause forbids access => forbidden
  return reject(req)
}

const _getMergedWhere = restricts => {
  const xprs = []
  restricts.forEach(ele => {
    if (xprs.length) {
      xprs.push('or')
    }
    xprs.push({ xpr: [...ele._xpr] })
  })
  return xprs
}

const _addWheresToRef = (ref, model, resolvedApplicables) => {
  const newRef = []
  let lastEntity = model.definitions[ref[0].id || ref[0]]

  ref.forEach((identifier, idx) => {
    if (idx === ref.length - 1) {
      newRef.push(identifier)
      return // determine last one separately
    }

    const entity = idx === 0 ? lastEntity : lastEntity.elements[identifier.id || identifier]._target
    lastEntity = entity
    const applicablesForEntity = resolvedApplicables.filter(
      restrict => restrict.target && restrict.target.name === entity.name
    )

    let newIdentifier = identifier

    if (applicablesForEntity.length) {
      if (typeof newIdentifier === 'string') {
        newIdentifier = { id: identifier, where: [] }
      }

      if (!newIdentifier.where) newIdentifier.where = []

      if (newIdentifier.where && newIdentifier.where.length) {
        newIdentifier.where = [{ xpr: newIdentifier.where }, 'and']
      }

      newIdentifier.where.push(..._getMergedWhere(applicablesForEntity))
    }

    newRef.push(newIdentifier)
  })

  return newRef
}

const _getRestrictionForTarget = (resolvedApplicables, target) => {
  const reqTarget = target && (target._isDraftEnabled ? target.name.replace(/_drafts$/, '') : target.name)
  const applicablesForTarget = resolvedApplicables.filter(
    restrict => restrict.target && restrict.target.name === reqTarget
  )

  if (applicablesForTarget.length) {
    return _getMergedWhere(applicablesForTarget)
  }
}

const _addRestrictionsToRead = async (req, model, resolvedApplicables) => {
  if (!cds.env.fiori.lean_draft && req.target._isDraftEnabled) {
    req.query._draftRestrictions = resolvedApplicables
    return
  }

  if (typeof req.query.SELECT.from === 'object')
    // in case of $apply take a ref from sub SELECT//
    req.query.SELECT.from.ref = _addWheresToRef(
      req.query.SELECT.from.ref || req.query.SELECT.from.SELECT?.from?.ref,
      model,
      resolvedApplicables
    )

  const restrictionForTarget = _getRestrictionForTarget(resolvedApplicables, req.target)
  if (!restrictionForTarget) return

  // apply restriction
  req.query.where(restrictionForTarget)
}

const _getFromWithIsActiveEntityRemoved = from => {
  if (!from.ref) return from
  for (const element of from.ref) {
    if (element.where && isActiveEntityRequested(element.where)) {
      element.where = removeIsActiveEntityRecursively(element.where)
    }
  }

  return from
}

const _getUnrestrictedCount = async req => {
  const dbtx = cds.tx(req)
  const target =
    (req.query.UPDATE && req.query.UPDATE.entity) ||
    (req.query.DELETE && req.query.DELETE.from) ||
    (req.query.SELECT && req.query.SELECT.from)
  const selectUnrestricted = SELECT.one(['count(*) as n']).from(target)
  const whereUnrestricted = (req.query.UPDATE && req.query.UPDATE.where) || (req.query.DELETE && req.query.DELETE.where)

  if (whereUnrestricted) selectUnrestricted.where(whereUnrestricted)

  // Because of side effects, the statements have to be fired sequentially.
  const { n } = await dbtx.run(selectUnrestricted)
  return n
}

const _getRestrictedCount = async (req, model, resolvedApplicables) => {
  const dbtx = cds.tx(req)
  const target =
    (req.query.UPDATE && req.query.UPDATE.entity) ||
    (req.query.DELETE && req.query.DELETE.from) ||
    (req.query.SELECT && req.query.SELECT.from)
  const selectRestricted = SELECT.one(['count(*) as n']).from(target)
  const whereRestricted = (req.query.UPDATE && req.query.UPDATE.where) || (req.query.DELETE && req.query.DELETE.where)

  if (whereRestricted) selectRestricted.where(whereRestricted)

  if (typeof selectRestricted.SELECT === 'object') {
    selectRestricted.SELECT.from.ref = _addWheresToRef(selectRestricted.SELECT.from.ref, model, resolvedApplicables)
  }

  const restrictionForTarget = _getRestrictionForTarget(resolvedApplicables, req.target)
  if (restrictionForTarget) selectRestricted.where(restrictionForTarget)

  const { n } = await dbtx.run(cqn2cqn4sql(selectRestricted, model, { suppressSearch: true }))
  return n
}

// eslint-disable-next-line complexity
async function handler(req) {
  if (req.user._is_privileged || DRAFT_EVENTS[req.event]) {
    // > skip checks (events in DRAFT_EVENTS are checked in draft handlers via InProcessByUser)
    return
  }

  const authRelevantEntity = getAuthRelevantEntity(req, this.model, ['@requires', '@restrict'])
  const definition =
    authRelevantEntity ||
    (req.target && req.target.actions && req.target.actions[req.event]) ||
    (this.operations && this.operations[req.event])

  if (!definition) {
    // > nothing to restrict
    return
  }

  let restrictions = this.getRestrictions(definition, req.event, req.user)
  if (restrictions instanceof Promise) restrictions = await restrictions
  if (!restrictions) {
    // > unrestricted
    return
  }

  if (!restrictions.length) {
    // > no applicable restrictions -> 403
    reject(req, getRejectReason(req, '@restrict', definition))
  }
  // normalize
  restrictions = getNormalizedPlainRestrictions(restrictions, definition)
  // at least one if the user's roles grants unrestricted access => done
  if (restrictions.some(restrict => !restrict.where)) return

  const resolvedApplicables = _getResolvedApplicables(restrictions, req)

  // REVISIT: support more complex statics
  if (_isStaticAuth(resolvedApplicables)) {
    return _handleStaticAuth(resolvedApplicables, req)
  }

  if (req.event === 'READ') {
    _addRestrictionsToRead(req, this.model, resolvedApplicables)
    return
  }

  // no modification -> nothing more to do
  if (!MOD_EVENTS[req.event]) return

  if (req.query.DELETE) req.query.DELETE.from = _getFromWithIsActiveEntityRemoved(req.query.DELETE.from)
  if (req.query.SELECT) req.query.SELECT.from = _getFromWithIsActiveEntityRemoved(req.query.SELECT.from)

  // REVISIT: selected data could be used for etag check, diff, etc.

  /*
   * Here we check if UPDATE/DELETE requests add additional restrictions
   * Note: Needs to happen sequentially because of side effects
   */
  const unrestrictedCount = await _getUnrestrictedCount(req)
  if (unrestrictedCount === 0) req.reject(404)

  const restrictedCount = await _getRestrictedCount(req, this.model, resolvedApplicables)

  if (restrictedCount < unrestrictedCount) {
    reject(req, getRejectReason(req, '@restrict', definition, restrictedCount, unrestrictedCount))
  }

  // for minor optimization in generic crud handler
  req._authChecked = true
}

handler._initial = true

module.exports = handler
