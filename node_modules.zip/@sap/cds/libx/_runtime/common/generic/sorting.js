const cds = require('../../cds')
const LOG = cds.log('app')
const { getAllKeys } = require('../../cds-services/adapter/odata-v4/odata-to-cqn/utils')
const { DRAFT_COLUMNS_MAP } = require('../../common/constants/draft')

const _getStaticOrders = req => {
  const { target: entity, query } = req
  const defaultOrders = entity['@cds.default.order'] || entity['@odata.default.order'] || []

  if (!cds._deprecationWarningForDefaultSort && defaultOrders.length > 0) {
    LOG._warn &&
      LOG.warn('Annotations "@cds.default.order" and "@odata.default.order" are deprecated and will be removed.')
    cds._deprecationWarningForDefaultSort = true
  }

  const ordersFromKeys = []

  if (req.target._isSingleton || query.SELECT.limit) {
    const keys = getAllKeys(entity, true)
    for (const key of keys) {
      if (!(key in DRAFT_COLUMNS_MAP) && !defaultOrders.some(o => o.by['='] === key)) {
        ordersFromKeys.push({ by: { '=': key } })
      }
    }
  }

  if (entity.query && entity.query.SELECT && entity.query.SELECT.orderBy) {
    const orderBy = entity.query.SELECT.orderBy
    const ordersFromView = orderBy.map(keyName => ({
      by: { '=': keyName.ref[keyName.ref.length - 1] },
      desc: keyName.sort === 'desc'
    }))
    return [...ordersFromView, ...defaultOrders, ...ordersFromKeys]
  }

  return [...defaultOrders, ...ordersFromKeys]
}

/**
 * 1. query options --> already set in req.query
 * 2. orders from view || @cds.default.order/@odata.default.order
 * 3. orders from keys if singleton or limit is set
 *
 * @param req
 */
const commonGenericSorting = function (req) {
  if (!req.query || !req.query.SELECT || req.query.SELECT.one) return

  let select = req.query.SELECT

  // do not sort for /$count queries or queries only using aggregations
  if (select.columns && select.columns.length && select.columns.every(col => col.func)) {
    return
  }

  // apply default sort to bottom-most sub-query
  if (select.from && select.from.SELECT) {
    while (select.from.SELECT) select = select.from.SELECT
  }

  // "static orders" = the orders not from the query options
  let staticOrders = _getStaticOrders(req)

  // remove defaultOrder if not part of group by
  if (select.groupBy && select.groupBy.length > 0) {
    staticOrders = staticOrders.filter(d => select.groupBy.find(e => e.ref[0] === d.by['=']))
  }
  if (!staticOrders.length) return
  ;(select.orderBy || (select.orderBy = [])).push(
    ...staticOrders
      .filter(d => !select.orderBy.find(o => o.ref && o.ref.join('_') === d.by['=']))
      .map(d => ({ ref: [d.by['=']], sort: d.desc ? 'desc' : 'asc' }))
  )
}

/**
 * handler registration
 */
module.exports = cds.service.impl(function () {
  commonGenericSorting._initial = true
  this.before('READ', '*', commonGenericSorting)
})

module.exports.handler = commonGenericSorting
