/*
 * Input handler on application service layer
 *
 * - remove readonly fields
 * - remove immutable fields on update
 * - add UUIDs
 * - asserts
 */

const cds = require('../../cds')
const LOG = cds.log('app')
const { enrichDataWithKeysFromWhere } = require('../utils/keys')
const { DRAFT_COLUMNS_MAP } = require('../../common/constants/draft')
const propagateForeignKeys = require('../utils/propagateForeignKeys')
const { checkInputConstraints, assertTargets } = require('../../cds-services/util/assert')
const getTemplate = require('../utils/template')
const templateProcessor = require('../utils/templateProcessor')
const { getDataFromCQN, setDataFromCQN } = require('../utils/data')
const getRowUUIDGeneratorFn = require('../utils/rowUUIDGenerator')

const _shouldSuppressErrorPropagation = (event, value) => {
  return (
    event === 'NEW' ||
    event === 'PATCH' ||
    (event === 'UPDATE' && value.val === undefined) ||
    (value.val == null && !value.mandatory)
  )
}

const _getSimpleCategory = category => {
  if (typeof category === 'object') {
    category = category.category
  }

  return category
}

const _isDraftCoreComputed = (req, element, event) =>
  element['@Core.Computed'] &&
  cds.env.features.preserve_computed !== false &&
  req._ &&
  req._.event === 'draftActivate' &&
  !((event === 'CREATE' && element['@cds.on.insert']) || element['@cds.on.update'])

const _isStreamingProperty = (elements, row, property) =>
  Object.values(elements).some(
    element => element['@Core.MediaType'] && element['@Core.MediaType']['='] === property && row[element.name]
  )

const _getMediaTypeValue = () => {
  const ctx = cds.context
  return (
    !ctx?.http?.req?.headers?.['content-type']?.match(/json|multipart/i) && ctx?.http?.req?.headers?.['content-type']
  )
}

const _preProcessAssertTarget = (assocInfo, assertMap) => {
  const { element: assoc, row } = assocInfo
  const assocTarget = assoc._target

  // it is expected that the associated entities be defined in the same service
  if (assoc.parent._service !== assocTarget._service) {
    LOG._warn && LOG.warn('Cross-service checks for the @assert.target constraint are not supported.')
    return
  }

  const foreignKeys = assoc._foreignKeys
  let mapKey = `${assocTarget.name}(`
  const hasOwn = Object.prototype.hasOwnProperty
  const parentKeys = []

  foreignKeys.forEach(keyMap => {
    const { childElement, parentElement } = keyMap

    // don't assert target if the foreign key isn't in the payload
    if (!hasOwn.call(row, parentElement.name)) return

    const foreignKeyValue = row[parentElement.name]

    // don't assert target if the foreign key value is null
    if (foreignKeyValue === null) return

    mapKey += `${childElement.name}=${foreignKeyValue},`
    parentKeys.push({
      [childElement.name]: foreignKeyValue
    })
  })
  mapKey += `)`

  if (parentKeys.length === 0) return

  foreignKeys.forEach(keyMap => {
    const clonedAssocInfo = Object.assign({}, assocInfo, { pathSegmentsInfo: assocInfo.pathSegmentsInfo.slice(0) })
    const target = {
      key: mapKey,
      entity: assocTarget,
      keys: parentKeys,
      assocInfo: clonedAssocInfo,
      foreignKey: keyMap.parentElement
    }

    if (!assertMap.targets.has(mapKey)) {
      assertMap.targets.set(mapKey, target)
    }

    assertMap.allTargets.push(target)
  })
}

const _processCategory = (req, category, value, elementInfo, assertMap) => {
  const { row, key, element, isRoot } = elementInfo
  category = _getSimpleCategory(category)

  if (category === 'propagateForeignKeys') {
    propagateForeignKeys(key, row, element._foreignKeys, element.isComposition, { enumerable: false })
    return
  }

  // remember mandatory
  if (category === 'mandatory') {
    value.mandatory = true
    return
  }

  const event = req.event

  // remove readonly & immutable (can also be complex, so do first)
  if (category === 'readonly' || (category === 'immutable' && event === 'UPDATE')) {
    if (_isDraftCoreComputed(req, element, event)) {
      // > preserve computed values if triggered by draftActivate and not managed
      return
    }
    // Always take over the values from active entities
    if (cds.env.fiori?.lean_draft && req.context?.event === 'EDIT') return

    delete row[key]
    value.val = undefined
    return
  }

  // generate UUIDs
  if (category === 'uuid' && !value.val && ((event !== 'UPDATE' && event !== 'PATCH') || !isRoot)) {
    value.val = row[key] = cds.utils.uuid()
  }

  // @assert.target
  if ((event === 'UPDATE' || event === 'CREATE') && category === '@assert.target') {
    _preProcessAssertTarget(elementInfo, assertMap)
  }

  // set media type from content-type header if streaming
  if (category === 'stream') {
    if (_isStreamingProperty(element.parent.elements, row, key)) {
      const mtValue = _getMediaTypeValue()
      if (mtValue) row[key] = mtValue
    }
  }
}

const _getProcessorFn = (req, errors, assertMap) => {
  const event = req.event

  return elementInfo => {
    const { row, key, element, plain, pathSegmentsInfo } = elementInfo
    // ugly pointer passing for sonar
    const value = { mandatory: false, val: row && row[key] }

    for (const category of plain.categories) {
      _processCategory(req, category, value, elementInfo, assertMap)
    }

    if (_shouldSuppressErrorPropagation(event, value)) return

    // REVISIT: Convert checkInputConstraints to template mechanism
    checkInputConstraints({ element, value: value.val, errors, pathSegmentsInfo, event })
  }
}

// params: element, target, parent
const _pick = element => {
  // collect actions to apply
  const categories = []

  // REVISIT: element._foreignKeys.length seems to be a very broad check
  if (element.isAssociation && element._foreignKeys.length) {
    categories.push({ category: 'propagateForeignKeys' })
  }

  if (element['@assert.range'] || element['@assert.enum'] || element['@assert.format']) {
    categories.push('assert')
  }

  if (element._isMandatory) {
    categories.push('mandatory')
  }

  if (element._isReadOnly) {
    // > _isReadOnly includes @cds.on.insert and @cds.on.update
    categories.push('readonly')
  }

  if (element['@Core.Immutable']) {
    categories.push('immutable')
  }

  if (element.key && !DRAFT_COLUMNS_MAP[element.name] && element.isUUID) {
    categories.push('uuid')
  }

  if (element['@Core.IsMediaType']) categories.push('stream')

  if (
    element._isAssociationStrict &&
    !element.on && // managed assoc
    element.is2one &&
    element['@assert.target'] === true
  ) {
    categories.push('@assert.target')
  }

  if (categories.length) return { categories }
}

const _callError = (req, errors) => {
  if (errors.length === 0) return
  for (const error of errors) req.error(error)
}

const _getBoundAction = req => req.target.actions?.[req._?.event || req.context?.event]
const _getBoundActionBindingParameter = action => action['@cds.odata.bindingparameter.name'] || 'in'

async function commonGenericInput(req) {
  if (!req.query) return // FIXME: the code below expects req.query to be defined
  if (!req.target) return

  const template = getTemplate('app-input', this, req.target, {
    pick: _pick,
    ignore: element => element._isAssociationStrict
  })
  if (template.elements.size === 0) return

  const errors = []
  const assertMap = {
    targets: new Map(),
    allTargets: []
  }

  const pathOptions = {
    rowUUIDGenerator: getRowUUIDGeneratorFn(req.event),
    includeKeyValues: true,
    pathSegmentsInfo: []
  }

  const boundAction = _getBoundAction(req)

  if (boundAction) {
    const pathSegment = _getBoundActionBindingParameter(boundAction)
    if (pathSegment) pathOptions.pathSegmentsInfo.push(pathSegment)
    const keys = req._?.params?.[0]
    if (keys && 'IsActiveEntity' in keys) {
      pathOptions.draftKeys = { IsActiveEntity: keys.IsActiveEntity }
    }
  }

  const data = getDataFromCQN(req.query) // REVISIT: req.data should point into req.query
  enrichDataWithKeysFromWhere(data, req, this)
  const arrayData = Array.isArray(data) ? data : [data]

  for (const row of arrayData) {
    templateProcessor({ processFn: _getProcessorFn(req, errors, assertMap), row, template, pathOptions })
  }

  if (assertMap.targets.size > 0) {
    await assertTargets(assertMap, errors)
  }

  setDataFromCQN(req) // REVISIT: req.data should point into req.query
  _callError(req, errors)
}

const _getProcessorFnForActionsFunctions =
  (errors, opName) =>
  ({ row, key, element }) => {
    const value = row && row[key]

    // REVISIT: Convert checkInputConstraints to template mechanism
    checkInputConstraints({ element, value, errors, key: opName })
  }

const _processActionFunctionRow = (row, param, key, errors, event, service) => {
  const values = Array.isArray(row[key]) ? row[key] : [row[key]]

  // unstructured
  for (const value of values) {
    checkInputConstraints({ element: param, value, errors, key })
  }

  // structured
  const template = getTemplate('app-input-operation', service, param, {
    pick: _pick,
    ignore: element => element._isAssociationStrict
  })

  if (template && template.elements.size) {
    for (const value of values) {
      const args = { processFn: _getProcessorFnForActionsFunctions(errors, key), row: value, template }
      templateProcessor(args)
    }
  }
}

const _processActionFunction = (row, eventParams, errors, event, service) => {
  for (const key in eventParams) {
    let param = eventParams[key]

    // .type of action/function behaves different to .type of other csn elements
    const _type = param.type
    if (!_type && param.items) param = param.items
    _processActionFunctionRow(row, param, key, errors, event, service)
  }
}

const _getEventParameters = (req, service) => {
  // in bound case
  if (req.target) {
    if (req.target.actions && req.target.actions[req.event]) {
      return req.target.actions[req.event].params
    }

    return req.target.functions[req.event].params
  }

  // in unbound case
  return service.model.definitions[`${service.name}.${req.event}`].params
}

function _actionFunctionHandler(req) {
  const eventParams = _getEventParameters(req, this)
  if (!eventParams) return

  // REVISIT: find better solution -> this obviously was because params were not linked in the past
  // attach aspects, if not yet done
  // for (const param of Object.values(eventParams)) {
  //   if ('_isMandatory' in param) continue
  //   param._isMandatory = isMandatory(param)
  //   param._isReadOnly = isReadOnly(param)
  // }

  // REVISIT: find better solution, maybe compiler? -> this obviously was because params were not linked in the past
  // resolve enums like format, range, etc.
  // for (const param of Object.values(eventParams)) {
  //   // .type of action/function behaves different to .type of other csn elements
  //   const _type = param.type && this.model && this.model.definitions[param.type]
  //
  //   if (_type) {
  //     param.enum = _type.enum
  //   }
  // }

  const errors = []
  const data = req.data
  const arrayData = Array.isArray(data) ? data : [data]

  for (const row of arrayData) {
    _processActionFunction(row, eventParams, errors, req.event, this)
  }

  _callError(req, errors)
}

commonGenericInput._initial = true
_actionFunctionHandler._initial = true

module.exports = cds.service.impl(function () {
  if (cds.env.fiori.lean_draft) {
    this.before(['CREATE', 'UPDATE'], '*', commonGenericInput)
  } else {
    this.before(['CREATE', 'UPDATE', 'NEW', 'PATCH'], '*', commonGenericInput)
  }
  const operationNames = []

  for (const operation of this.operations) {
    operationNames.push(operation.name.substring(this.name.length + 1))
  }

  if (operationNames.length > 0) {
    this.before(operationNames, _actionFunctionHandler)
  }

  for (const entity of this.entities) {
    const boundOps = []

    if (entity.actions) {
      boundOps.push(...Object.keys(entity.actions))
    }

    if (entity.functions) {
      boundOps.push(...Object.keys(entity.functions))
    }

    if (boundOps.length > 0) {
      this.before(boundOps, entity.name, _actionFunctionHandler)
    }
  }
})
