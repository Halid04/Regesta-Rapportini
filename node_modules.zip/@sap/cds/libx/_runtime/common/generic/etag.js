const cds = require('../../cds')
const { SELECT } = cds.ql

// REVISIT: draft should not be handled here, e.g., target.name should be adjusted before
const { isActiveEntityRequested } = require('../../fiori/utils/where')
const { ensureDraftsSuffix } = require('../../fiori/utils/handler')
const { cqn2cqn4sql } = require('../../common/utils/cqn2cqn4sql')
const { isAsteriskColumn } = require('../../common/utils/rewriteAsterisks')
const { resolveView } = require('../utils/resolveView')

const C_U_ = {
  CREATE: 1,
  UPDATE: 1
}

const getRequestedTarget = query => {
  if (query.SELECT) {
    return query.SELECT.from
  } else if (query.UPDATE) {
    return query.UPDATE.entity
  } else {
    return query.DELETE.from
  }
}

const getSelectCQN = (query, target, model, isActive, etag) => {
  const targetName = isActive ? target.name : ensureDraftsSuffix(target.name)
  const cqn = cqn2cqn4sql(SELECT.from(getRequestedTarget(query)), model)
  cqn.columns([etag || target._etag.name])
  cqn.SELECT.from.ref[0] = targetName

  return cqn
}

/**
Recursively adds etag columns if a manual list of columns is specified.
If asterisk columns or no columns are given, the database layer will
add the etag columns anyway.
*/
const _addEtagColumns = (columns, entity) => {
  if (!columns || !Array.isArray(columns)) return
  if (
    entity._etag &&
    !columns.some(c => isAsteriskColumn(c)) &&
    !(columns.length === 1 && columns[0].func === 'count') &&
    !columns.some(c => c.ref && c.ref[c.ref.length - 1] === entity._etag.name)
  ) {
    columns.push({ ref: [entity._etag.name] })
  }
  const expands = columns.filter(c => c.expand)
  for (const expand of expands) {
    const refName = expand.ref[expand.ref.length - 1]
    const targetEntity = refName && entity.elements[refName] && entity.elements[refName]._target
    if (targetEntity) {
      _addEtagColumns(expand.expand, targetEntity)
    }
  }
}

const _isConcurrentODataReq = req => {
  const isReadAfterDraftAction =
    req.event === 'READ' && req.target._isDraftEnabled && req.context.event in { draftActivate: 1, EDIT: 1 }
  // It's allowed to also delete drafts when actives are deleted
  if (
    cds.env.fiori?.lean_draft &&
    req.event === 'READ' &&
    req.context.event === 'DELETE' &&
    req.target?.name.endsWith('.drafts') &&
    !req.context?.target?.name.endsWith('.drafts')
  )
    return
  const _req = isReadAfterDraftAction ? req.context : req
  return _req._isOData && _req.isConcurrentResource
}

/**
 * Generic handler for @odata.etag-enabled entities
 *
 * @param req
 */
const commonGenericEtag = async function (req) {
  // REVISIT: The check for ODataRequest should be removed after etag logic is moved
  // from okra to commons and etag handling is also allowed for rest.

  if (_isConcurrentODataReq(req)) {
    const etagElement = req.target.elements[req.target._etag.name]

    // automatically add etag columns if not already there
    if (req.query.SELECT) _addEtagColumns(req.query.SELECT.columns, req.target)

    // validate
    if (req.isConditional && !req.query.INSERT) {
      let cqn
      const isActive = isActiveEntityRequested(getRequestedTarget(req.query).ref[0].where)
      if ((req.query.UPDATE || req.query.DELETE) && isActive) {
        const query_ = resolveView(req.query, this.model, cds.db)
        const transition = (query_.UPDATE && query_.UPDATE._transitions[0]) || query_.DELETE._transitions[0]
        const etag = transition.mapping.get(req.target._etag.name).ref[0]
        cqn = getSelectCQN(query_, transition.target, this.model, isActive, etag).forUpdate()
      } else {
        cqn = getSelectCQN(req.query, req.target, this.model, isActive)
      }

      const result = await cds.tx(req).run(cqn)

      if (result.length === 1) {
        const etag = Object.values(result[0])[0]
        req.validateEtag(etag == null ? 'null' : etag)
      } else {
        req.validateEtag('*')
      }
    }

    // generate new etag, if UUID
    if (C_U_[req.event] && etagElement.isUUID) {
      req.data[etagElement.name] = cds.utils.uuid()
    }
  }
}

/**
 * handler registration
 *
 */
/* istanbul ignore next */
module.exports = cds.service.impl(function () {
  commonGenericEtag._initial = true

  for (const k in this.entities) {
    const entity = this.entities[k]

    if (!entity._etag) continue

    // handler for CREATE is registered for backwards compatibility w.r.t. ETag generation
    let events = ['CREATE', 'READ', 'UPDATE', 'DELETE']

    // if odata and fiori is separated, this will not be needed in the odata version
    if (entity._isDraftEnabled) {
      events = ['READ', 'NEW', 'DELETE', 'PATCH', 'EDIT', 'CANCEL']
    }

    this.before(events, entity, commonGenericEtag)

    for (const action in entity.actions) {
      this.before(action, entity, commonGenericEtag)
    }
  }
})
