const cds = require('../../cds')
const { SELECT } = cds.ql

const { deepCopyArray } = require('../utils/copy')

const { getColumns } = require('../../cds-services/services/utils/columns')

const getError = require('../error')

const _targetEntityDoesNotExist = async req => {
  const { query } = req
  const cqn = SELECT.from(query.UPDATE.entity, [1])

  if (query.UPDATE.entity.as) {
    cqn.SELECT.from.as = query.UPDATE.entity.as
  }

  // REVISIT: compat mode for service functions .update
  if (query.UPDATE && query.UPDATE.where) {
    cqn.where(query.UPDATE.where)
  }

  const exists = await cds.tx(req).run(cqn)
  return exists.length === 0
}

exports.impl = cds.service.impl(function () {
  // eslint-disable-next-line complexity
  this.on(['CREATE', 'READ', 'UPDATE', 'DELETE', 'UPSERT'], '*', async function (req) {
    if (typeof req.query !== 'string' && req.target && req.target._hasPersistenceSkip) {
      throw getError({
        code: 501,
        message: `Entity "${req.target.name}" is annotated with "@cds.persistence.skip" and cannot be served generically.`
      })
    }

    // REVISIT: error message
    if (!cds.db) req.reject('NO_DATABASE_CONNECTION')

    let result

    // validate that all elements in path exist on db, if necessary
    // - INSERT has no where clause to do this in one roundtrip
    // - SELECT returns [] -> really empty collection or invalid path?
    let pathExistsQuery

    const { ref } = (req.query.INSERT && req.query.INSERT.into) || (req.query.SELECT && req.query.SELECT.from) || {}
    // REVISIT: why is copy necessary?
    if (ref && ref.length > 1) pathExistsQuery = SELECT(1).from({ ref: deepCopyArray(ref.slice(0, -1)) })

    if (req.event === 'CREATE' && pathExistsQuery) {
      const res = await pathExistsQuery
      if (res.length === 0) req.reject(404)
    }

    if (req.event in { DELETE: 1, UPDATE: 1 } && req.target && req.target._isSingleton) {
      if (req.event === 'DELETE' && !req.target['@odata.singleton.nullable']) req.reject(400, 'SINGLETON_NOT_NULLABLE')
      const selectSingleton = SELECT.one(req.target)
      const keyColumns = getColumns(req.target, { onlyNames: true, keysOnly: true })

      // if no keys available, select all columns so we can delete the singleton with same content
      if (keyColumns.length) selectSingleton.columns(keyColumns)
      const singleton = await cds.tx(req).run(selectSingleton)
      if (!singleton) req.reject(404)

      // REVISIT: Workaround for singleton, to get keys into singleton
      for (const keyName in singleton) {
        if (!keyColumns.includes(keyName)) continue
        req.data[keyName] = singleton[keyName]
      }

      req.query.where(singleton)
    }

    if (req.event === 'READ' && req.query?.SELECT) {
      req.query.SELECT.localized = true
    }

    if (!result) {
      result = await cds.tx(req).run(req.query, req.data)
    }

    if (req.event === 'READ') {
      if ((result == null || result.length === 0) && pathExistsQuery) {
        const res = await pathExistsQuery
        if (res.length === 0) req.reject(404)
      }
      return result
    }

    if (req.event === 'DELETE') {
      if (result === 0) req.reject(404)
      return result
    }

    // case: no authorization check and payload more than just keys but no changes
    // -> affected rows === 0 -> no change or not exists?
    if (req.event === 'UPDATE' && result === 0 && !req._authChecked) {
      if (await _targetEntityDoesNotExist(req)) req.reject(404)
    }

    // flag to trigger read after write in protocol adapter
    req._.readAfterWrite = true

    return req.data
  })
})
