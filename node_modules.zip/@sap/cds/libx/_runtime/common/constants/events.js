const MOD_EVENTS = { UPDATE: 1, DELETE: 1, EDIT: 1 }
const WRITE_EVENTS = Object.assign({ CREATE: 1, NEW: 1, PATCH: 1, CANCEL: 1 }, MOD_EVENTS)
const CRUD_EVENTS = Object.assign({ READ: 1 }, WRITE_EVENTS)
const DRAFT_EVENTS = { PATCH: 1, CANCEL: 1, draftActivate: 1, draftPrepare: 1 }
const CDS_EVENTS = Object.assign({}, CRUD_EVENTS, DRAFT_EVENTS)

module.exports = {
  MOD_EVENTS,
  WRITE_EVENTS,
  CRUD_EVENTS,
  DRAFT_EVENTS,
  CDS_EVENTS
}
