const RestAdapter = require('./RestAdapter')

module.exports = srv => new RestAdapter(srv)
