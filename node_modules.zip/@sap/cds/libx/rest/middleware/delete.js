const RestRequest = require('../RestRequest')

module.exports = async _req => {
  const { _srv: srv, _query: query, _target, _data, _params } = _req

  const req = new RestRequest({ query, _target, params: _params, data: _data })
  // req.data is filled with keys during read and delete
  if (_params) req.data = Object.assign(_data, _params[_params.length - 1]) // REVISIT: We should avoid that!

  await srv.dispatch(req)
  _req._result = { result: null, status: 204 } // REVISIT: Ugly voodoo _re._result channel -> eliminate
}
