const cds = require('../../_runtime/cds')
const { validateReturnType } = require('../../_runtime/cds-services/adapter/rest/utils/validation-checks')

const RestRequest = require('../RestRequest')

module.exports = async (_req, _res, next) => {
  const { _srv: srv, _query: query, _operation: operation, _data: data, _params } = _req

  let result

  // unfortunately, express doesn't catch async errors -> try catch needed
  try {
    const req = query
      ? new RestRequest({ query, event: operation.name, data, params: _params })
      : new RestRequest({ event: operation.name.replace(`${srv.name}.`, ''), data, params: _params })
    result = await srv.dispatch(req)
  } catch (e) {
    return next(e)
  }

  if (!operation.returns) {
    _req._result = { status: 204 }
  } else {
    // unfortunately, express doesn't catch async errors -> try catch needed
    try {
      // REVISIT: do not use from old rest adapter
      // REVISIT: new impl should return instead of throwing to avoid try catch
      validateReturnType(operation, result)

      // set content-type header to text/plain for returned primitive data types, except for boolean
      const returnType = operation.returns._type
      if (
        !_res.get('content-type') &&
        !operation.returns.items &&
        returnType &&
        cds.builtin.types[returnType] &&
        returnType !== 'cds.Boolean'
      )
        _res.set('content-type', 'text/plain')
    } catch (e) {
      return next(e)
    }

    // mtx compat, modeled as string but object returned
    if (operation.returns._type === 'cds.String' && typeof result === 'object') {
      _res.set('content-type', 'application/json')
    }

    // REVISIT: still needed?
    if (!operation.returns.items && Array.isArray(result)) result = result[0]

    if (result === undefined) _req._result = { status: 204 }
    else _req._result = { result }
  }

  next()
}
