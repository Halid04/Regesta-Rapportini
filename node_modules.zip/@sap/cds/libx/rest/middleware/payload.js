const { base64ToBuffer } = require('../../_runtime/common/utils/binary')

module.exports = (req, res, next) => {
    const { _srv, _query, _data, _operation } = req
    const definition = _operation || _query.__target
  
    if (!(_data && _srv && definition)) return next()
    
    base64ToBuffer(_data, _srv, definition)
  
    next()
}
