// const cds = require('../../_runtime/cds')
const getTemplate = require('../../_runtime/common/utils/template')
const templateProcessor = require('../../_runtime/common/utils/templateProcessor')
const { checkStaticElementByKey } = require('../../_runtime/cds-services/util/assert')
const { MULTIPLE_ERRORS } = require('../../_runtime/common/error/constants')

//
// REVISIT: We need to decipher what we are doing here...
//

const _picker = () => {
  return element => {
    const categories = {}
    if (Array.isArray(element)) return
    if (element._isStructured || element.isAssociation || element.items) return
    categories['static_validation'] = true
    return categories
  }
}

const _processorFn = errors => {
  return ({ row, key, plain: categories, target }) => {
    // REVISIT move validation to generic asserter => see PR 717
    if (categories['static_validation'] && row[key] != null) {
      const validations = checkStaticElementByKey(target, key, row[key])
      errors.push(...validations)
    }
  }
}

const _cache = req => `rest-input;skip-key-validation:${req.method !== 'POST'}`

module.exports = (req, res, next) => {
  const { _srv, _query, _data, _operation } = req
  const definition = _operation || _query.__target

  if (!(_data && _srv && definition)) return next()

  const errors = []

  const template = getTemplate(_cache(req), _srv, definition, { pick: _picker(req) })
  if (template && template.elements.size) {
    const rows = Array.isArray(_data) ? _data : [_data]
    for (const row of rows) {
      templateProcessor({ processFn: _processorFn(errors), row, template })
    }
  }

  if (errors.length > 1) throw Object.assign(new Error(MULTIPLE_ERRORS), { details: errors })
  if (errors.length === 1) throw errors[0]

  next()
}
