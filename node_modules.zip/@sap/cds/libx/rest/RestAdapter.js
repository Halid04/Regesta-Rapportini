const cds = require('../_runtime/cds')

// eslint-disable-next-line cds/no-missing-dependencies -- needs to be added by app dev
const express = require('express')

const parse = require('./middleware/parse')
const input = require('./middleware/input')

const create = require('./middleware/create')
const read = require('./middleware/read')
const update = require('./middleware/update')
const deleet = require('./middleware/delete')
const operation = require('./middleware/operation')
const payload = require('./middleware/payload')

const error = require('./middleware/error')
const { alias2ref } = require('../_runtime/common/utils/csn')
const { bufferToBase64 } = require('../_runtime/common/utils/binary')

const RestAdapter = function (srv) {
  alias2ref(srv) // REVISIT: that's an anti pattern in new prototocol adapter setups

  const router = express.Router()

  // pass srv-related stuff to middlewares via req
  router.use((req, res, next) => {
    req._srv = srv // FIXME: That's only because of how we organized our rest adapater code into fragmented files -> don't do that

    // cds/libx/rest/middleware/create.js:
    //   12:   const { _srv: srv, _query: query, _target, _data } = _req

    // cds/libx/rest/middleware/delete.js:
    //   4:   const { _srv: srv, _query: query, _target, _params } = _req

    // cds/libx/rest/middleware/error.js:
    //   40:   const { _srv: srv } = req

    // cds/libx/rest/middleware/input.js:
    //   40:   const { _srv, _query, _data, _operation } = req
    //   43:   if (!(_data && _srv && definition)) return next()
    //   47:   const template = getTemplate(_cache(req), _srv, definition, { pick: _picker(req) })

    // cds/libx/rest/middleware/operation.js:
    //   7:   const { _srv: srv, _query: query, _operation: operation, _data: data } = _req

    // cds/libx/rest/middleware/parse.js:
    //   10:   const { _srv: service } = req

    // cds/libx/rest/middleware/read.js:
    //   4:   const { _srv: srv, _query: query, _target, _params } = _req

    // cds/libx/rest/middleware/update.js:
    //   11:   let { _srv: srv, _query: query, _target, _data, _params } = _req

    next()
  })

  // req.user + req.tenant -> cds.context = { user, tenant }
  // NOT ALLOWED: cds.context.user = 'me'
  // req.requiresLogin() -> login -> redirect to referrer

  // check @requires as soon as possible (DoS)
  router.use((req, res, next) => {
    // REVISIT: This is authorization enforcement which is protocol-independent -> should move to service layer
    const requires = srv.definition?.['@requires']
    if (requires) {
      const ok = typeof requires === 'string' ? req.user.is(requires) : requires.some(r => req.user.is(r))
      if (ok) return next()
    } else {
      return next() // neither of the above
    }

    if (req.user._is_anonymous) {
      // > unauthorized or forbidden?
      // if (req.login) return req.login() // REVISIT: no clue whether we should do so
      if (req.user._challenges) res.set('WWW-Authenticate', req.user._challenges.join(';')) //> REVISIT: is this for basic auth only? -> should be done differently
      if (req.login) res.set('WWW-Authenticate', `Basic realm="Users"`) //> REVISIT: is this reasonable?
      throw cds.error('Unauthorized', { statusCode: 401, code: '401' }) //> UNAUTHORIZED
    }
    throw cds.error('Forbidden', { statusCode: 403, code: '403' }) //> FORBIDDEN
    // REVISIT: send res.status().json() instead of throwing exceptions
    // REVISIT: security log?
  })

  // -----------------------------------------------------------------------------------------
  // service root
  router.head('/', (_, res) => res.json({}))
  router.get('/', (_, res) =>
    res.json({
      entities: Object.keys(srv.entities).map(e => ({ name: e, url: e }))
    })
  )

  // -----------------------------------------------------------------------------------------
  // parse / validate

  // content-type check
  router.use((req, res, next) => {
    // REVISIT: move that into parse function
    if (req.method in { POST: 1, PUT: 1, PATCH: 1 }) {
      const contentType = req.headers['content-type'] && req.headers['content-type'].split(';')
      if (
        contentType &&
        (!contentType[0].match(/^application\/json$/) || (typeof contentType[1] === 'string' && !contentType[1]))
      ) {
        throw cds.error('INVALID_CONTENT_TYPE_ONLY_JSON', { statusCode: 415, code: '415' }) // FIXME: better i18n + use res.status
      }

      if (req.method in { PUT: 1, PATCH: 1 }) {
        if (Array.isArray(req.body)) {
          throw cds.error(`INVALID_${req.method}`, { statusCode: 400, code: '400' }) // FIXME: better i18n + use res.status
        }

        // check for empty payload body
        if (req.headers['content-length'] === '0') {
          res.status(400).json({ error: { message: 'Malformed patch document', statusCode: 400, code: '400' } })
          return
        }
      }
    }
    next()
  })
  router.use(express.json()) // REVISIT: -> belongs to the parses
  router.use(parse) // REVISIT: -> move to actual handler(s)
  router.use(payload) // REVISIT: -> move?
  // payload validation
  router.use(input) // REVISIT: This is protocol-independent, isn't it? -> move to service layer

  // -----------------------------------------------------------------------------------------
  // begin tx
  router.use((req, res, next) => {
    // REVISIT: -> move to actual handler(s)
    const tenant = req.tenant || req.user?.tenant
    // create tx and set as cds.context
    cds.context = srv.tx(new cds.EventContext({ user: req.user, req, res, tenant }))
    next()
  })

  // -----------------------------------------------------------------------------------------
  // Actual handlers for HEAD, GET, PUT, POST, PATCH, DELETE
  //
  router.head('/*', (req, res, next) => {
    read(req, res, next) // REVISIT: HEAD is doing a full read ?
  })
  router.post('/*', (req, res, next) => {
    if (req._operation) operation(req, res, next)
    else create(req, res, next)
  })
  router.get('/*', (req, res, next) => {
    if (req._operation) operation(req, res, next)
    else read(req, res, next)
  })
  router.put('/*', update)
  router.patch('/*', update)
  router.delete('/*', (req, res, next) => deleet(req, res).then(next).catch(next))

  // -----------------------------------------------------------------------------------------
  // end tx (i.e., commit or rollback)
  router.use(async (req, res, next) => {
    const { result, status, location } = req._result // REVISIT: Ugly voodoo _req._result channel -> eliminate

    // unfortunately, express doesn't catch async errors -> try catch needed
    try {
      await cds.context?.tx?.commit(result)
    } catch (e) {
      return next(e)
    }

    // convert binaries
    const definition = req._operation || req._query.__target
    if (result && srv && definition) bufferToBase64(result, srv, definition)

    // only set status if not yet modified
    if (status && res.statusCode === 200) res.status(status) // REVISIT: Why only when res.statusCode === 200?
    if (location) res.set('location', location) // REVISIT: When do we redirect?
    if (req.method === 'HEAD')
      // REVISIT: Move that to the implementation of HEAD
      res
        .set({
          'content-type': 'application/json; charset=utf-8',
          'content-length': JSON.stringify(result).length
        })
        .end()
    // need to convert number to string because express interprets integer as status code
    else res.send(typeof result === 'number' ? result.toString() : result) // REVISIT: use req.json() instead?
  })

  // -----------------------------------------------------------------------------------------
  // error handling
  router.use((err, req, res, next) => {
    // REVISIT: should not be neccessary!
    // request may fail during processing or during commit -> both caught here

    // REVISIT: rollback needed if error occured before commit attempted -> how to distinguish?
    cds.context?.tx?.rollback(err).catch(() => {}) // REVISIT: silently ?!?

    next(err)
  })

  if (!cds.env.features.rest_error_handler) {
    router.use(error) // FIXME: nope -> call next()
  }

  return router
}

module.exports = RestAdapter
