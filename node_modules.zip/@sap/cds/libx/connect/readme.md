# Connectors to Platform Services

That is: service definitions and `cds.Service` implementations acting as clients or endpoints to platform services
