import { Service } from "./services"
import * as cds_facade from './cds'

export = cds
declare class cds {

	connect : {
		/**
		 * Connects to a specific datasource.
		 * @see [capire](https://cap.cloud.sap/docs/node.js/cds-connect#cds-connect-to)
		 */
		to (datasource: string, options?: ConnectOptions) : Promise<Service>

		/**
		 * Connects to a specific datasource via options.
		 * @see [capire](https://cap.cloud.sap/docs/node.js/cds-connect#cds-connect-to)
		 */
		to (options: ConnectOptions) : Promise<Service>

		/**
		 * Connects the primary datasource.
		 * @see [capire](https://cap.cloud.sap/docs/node.js/api#cds-connect)
		 */
		(options?: string | ConnectOptions) : Promise<typeof cds>  //> cds.connect(<options>)
	}

	/**
	 * Emitted whenever a specific service is connected for the first time.
	 */
	on (event : 'connect', listener : (srv : Service) => void) : this

}

type ConnectOptions = {
    impl?: string,
	service?: string,
	kind?:string,
	model?:string,
	credentials?: object
}
