import { SELECT, INSERT, UPDATE, DELETE, Query, ConstructedQuery, UPSERT } from './ql'
import { Awaitable } from './ql'
import { ArrayConstructable, Constructable } from './internal/inference'
import { LinkedModel, Definition, Definitions } from './reflect'
import { csn } from './csn'
import { User } from './core'
import * as express from "express"
import { ref } from './cqn'
// import { Service } from './cds'

export class QueryAPI {
  /**
   * @see [docs](https://cap.cloud.sap/docs/node.js/services#srv-run)
   */
  read: {
    <T extends ArrayConstructable<any>>(entity: T, key?: any): Awaitable<SELECT<T>, InstanceType<T>>
    <T>(entity: Definition | string, key?: any): SELECT<T>
  }

  /**
   * @see [docs](https://cap.cloud.sap/docs/node.js/services#srv-run)
   */
  create: {
    <T extends ArrayConstructable<any>>(entity: T, key?: any): INSERT<T>
    <T>(entity: Definition | string, key?: any): INSERT<T>
  }

  /**
   * @see [docs](https://cap.cloud.sap/docs/node.js/services#srv-run)
   */
  insert: {
    <T extends ArrayConstructable<any>>(data: T): INSERT<T>
    <T>(data: object | object[]): INSERT<T>
  }

  /**
   * @see [docs](https://cap.cloud.sap/docs/node.js/services#srv-run)
   */
  upsert: {
    <T extends ArrayConstructable<any>>(data: T): UPSERT<T>
    <T>(data: object | object[]): UPSERT<T>
  }

  /**
   * @see [docs](https://cap.cloud.sap/docs/node.js/services#srv-run)
   */
  update: {
    <T extends ArrayConstructable<any>>(entity: T, key?: any): UPDATE<T>
    <T>(entity: Definition | string, key?: any): UPDATE<T>
  }

  /**
   * @see [docs](https://cap.cloud.sap/docs/node.js/services#srv-run)
   */
  run: {
    (query: ConstructedQuery | ConstructedQuery[]): Promise<ResultSet | any>
    (query: Query): Promise<ResultSet | any>
    (query: string, args?: any[] | object): Promise<ResultSet | any>
  }
 
  /**
   * @see [docs](https://cap.cloud.sap/docs/node.js/cds-facade?q=cds.delete)
   */
  delete<T>(entity: Definition | string, key?: any): DELETE<T>

  /**
   * @see [docs](https://cap.cloud.sap/docs/node.js/services#srv-run)
   */
  foreach(query: Query, callback: (row: object) => void): this

  /**
   * @see [docs](https://cap.cloud.sap/docs/node.js/services#srv-stream)
   */
  stream: {
    (column: string): {
      from(entity: Definition | string): {
        where(filter: any): ReadableStream
      }
    }
    (query: Query): Promise<ReadableStream>
  }

  /**
   * Starts or joins a transaction
   * @see [docs](https://cap.cloud.sap/docs/node.js/services#srv-tx)
   */
  tx(context?: object): Transaction
  transaction(context?: object): Transaction
  
  /**
   * @see [docs](https://pages.github.tools.sap/cap/docs/node.js/cds-context-tx?q=spawn#cds-spawn)
   */
  spawn(options: Options, fn: (tx: Transaction) => {}): SpawnEventEmitter

  /**
   * @see [docs](https://pages.github.tools.sap/cap/docs/node.js/cds-context-tx?q=cds.context#cds-context
   */
  context:  ContextProperties
}

type ContextProperties = {
  id?: string
  http?: {req: express.Request, res: express.Response}
  tenant? : string,
  user? : User | string
}

/**
 * Class cds.Service
 * @see [capire docs](https://cap.cloud.sap/docs/node.js/services)
 */
export class Service extends QueryAPI {
  constructor(
    name: string,
    model: csn,
    options: {
      kind: string
      impl: string | ServiceImpl
    }
  )

  /**
   * The name of the service
   */
  name: string

  /**
   * The model from which the service's definition was loaded
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-reflect)
   */
  model: LinkedModel

  /**
   * Provides access to the entities exposed by a service
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-reflect)
   */
  entities: Definitions & ((namespace: string) => Definitions)

  /**
   * Provides access to the events declared by a service
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-reflect)
   */
  events: Definitions & ((namespace: string) => Definitions)

  /**
   * Provides access to the types exposed by a service
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-reflect)
   */
  types: Definitions & ((namespace: string) => Definitions)

  /**
   * Provides access to the operations, i.e. actions and functions, exposed by a service
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-reflect)
   */
  operations: Definitions & ((namespace: string) => Definitions)

  /**
   * Acts like a parameter-less constructor. Ensure to call `await super.init()` to have the base class’s handlers added.
   * You may register own handlers before the base class’s ones, to intercept requests before the default handlers snap in.
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#cds-service-subclasses)
   */
  init(): Promise<void>

  /**
   * Constructs and emits an asynchronous event.
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-emit)
   */
  emit: {
    <T = any>(details: { event: Events; data?: object; headers?: object }): Promise<T>
    <T = any>(event: Events, data?: object, headers?: object): Promise<T>
  }

  /**
   * Constructs and sends a synchronous request.
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srvsend--method-path-data-headers--results-)
   */
  send: {
    <T = any>(event: Events, path: string, data?: object, headers?: object): Promise<T>
    <T = any>(event: Events, data?: object, headers?: object): Promise<T>
    <T = any>(details: { event: Events; data?: object; headers?: object }): Promise<T>
    <T = any>(details: { query: ConstructedQuery; data?: object; headers?: object }): Promise<T>
    <T = any>(details: { method: Event; path: string; data?: object; headers?: object }): Promise<T>
  }

  /**
   * Constructs and sends a GET request.
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-send)
   */
  get<T = any>(entityOrPath: Target, data?: object): Promise<T>
  /**
   * Constructs and sends a POST request.
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-send)
   */
  post<T = any>(entityOrPath: Target, data?: object): Promise<T>
  /**
   * Constructs and sends a PUT request.
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-send)
   */
  put<T = any>(entityOrPath: Target, data?: object): Promise<T>
  /**
   * Constructs and sends a PATCH request.
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services#srv-send)
   */
  patch<T = any>(entityOrPath: Target, data?: object): Promise<T>
  /**
   * Constructs and sends a DELETE request.
   */
  delete: {
    <T = any>(entityOrPath: Target, data?: object): DELETE<T>
    <T extends ArrayConstructable<any>>(entity: T, key?: any): DELETE<T>
    <T>(entity: Definition | string, key?: any): DELETE<T>
  }

  // The central method to dispatch events
  dispatch(msg: EventMessage): Promise<any>

  // Provider API
  prepend(fn: ServiceImpl): Promise<this>
  on<T extends Constructable>(eve: Events, entity: T, handler: CRUDEventHandler.On<InstanceType<T>, InstanceType<T> | void | Error>): this
  on<P,R>(boundAction: (args: P) => R, service: string, handler: ActionEventHandler<P, void | Error | R>): this
  on<P,R>(action: (args: P) => R, handler: ActionEventHandler<P, void | Error | R>): this
  on(eve: Events, entity: Target, handler: OnEventHandler): this
  on(eve: Events, handler: OnEventHandler): this


  // onSucceeded (eve: Events, entity: Target, handler: EventHandler): this
  // onSucceeded (eve: Events, handler: EventHandler): this
  // onFailed (eve: Events, entity: Target, handler: EventHandler): this
  // onFailed (eve: Events, handler: EventHandler): this
  before<T extends Constructable>(eve: Events, entity: T, handler: CRUDEventHandler.Before<InstanceType<T>, InstanceType<T> | void | Error>): this
  before(eve: Events, entity: Target, handler: EventHandler): this
  before(eve: Events, handler: EventHandler): this
  after<T extends Constructable>(eve: Events, entity: T, handler: CRUDEventHandler.After<InstanceType<T>, InstanceType<T> | void | Error>): this
  after(eve: Events, entity: Target, handler: ResultsHandler): this
  after(eve: Events, handler: ResultsHandler): this
  reject(eves: Events, ...entity: Target[]): this
}

export interface Transaction extends Service {
  commit(): Promise<void>
  rollback(): Promise<void>
}

export class DatabaseService extends Service {
  deploy(model?: csn | string): Promise<csn>
  begin(): Promise<void>
  commit(): Promise<void>
  rollback(): Promise<void>
}

export interface ResultSet extends Array<{}> {}

export class cds {
  /**
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/services)
   */
  Service: typeof Service

  /**
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/app-services)
   */
  ApplicationService: typeof Service

  /**
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/remote-services)
   */
  RemoteService: typeof Service

  /**
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/messaging)
   */
  MessagingService: typeof Service

  /**
   * @see [capire docs](https://cap.cloud.sap/docs/node.js/databases)
   */
  DatabaseService: typeof DatabaseService
}

export interface ServiceImpl {
  (this: Service, srv: Service): any
}

export interface EventHandler {
  // (msg : EventMessage) : Promise<any> | any | void
  (req: Request): Promise<any> | any | void
}

export interface OnEventHandler {
  (req: Request, next: Function): Promise<any> | any | void
}

// `Partial` wraps any type and allows all properties to be undefined
// in addition to their actual type.
// This is important in the context of CRUD events, where
// entities could be lacking any properties, like a non-existing ID
// or when DB fields are corrupted, etc.
type Partial<T> = { [Key in keyof T]: undefined | T[Key] }

// Naming the first parameter in a handler `each` has special voodoo
// semantic which makes it impossible for us to infer the exact behaviour on a type level.
// So we always have to expect scalars as well as arrays in some callbacks.
type OneOrMany<T> = T | T[];

type TypedRequest<T> = Omit<Request, 'data'> & { data: T }

// https://cap.cloud.sap/docs/node.js/services#event-handlers
export namespace CRUDEventHandler {
  type Before<P,R> = (req: TypedRequest<P>) => Promise<R> | R
  type On<P,R> = (req: TypedRequest<P>, next: (...args: any) => Promise<R> | R) => Promise<R> | R
  type After<P,R> = (data: undefined | P, req: TypedRequest<P>) => Promise<R> | R
}

// Handlers for actions try to infer the passed .data property
// as strictly as possible and therefore have to remove
// { data: any } (inherited EventMessage} with a more restricted
// type, based on the parameters of the action.
export interface ActionEventHandler<P,R> {
  (req: Omit<Request, 'data'> & { data: P }, next: Function): Promise<R> | R
}

// Note: the behaviour of ResultsHandler changes based on the name of the parameter.
// If the parameter in the hook is called "each", it is called once for each row in the result,
// otherwise it gets called exactly one time with the entire result.
// This runtime behaviour can not be described on type level
// (in a way that would benefit the user).
// The user will therefore receive "any" as their result/ each. If we could some day differentiate,
// we may want to add a generic to ResultsHandler which is passed from the EventHandlers down below.
interface ResultsHandler {
  (results: any[], req: Request): void
  (each: any, req: Request): void
}

/**
 * Represents the invocation context of incoming request and event messages.
 * @see [capire docs](https://cap.cloud.sap/docs/node.js/requests)
 */
interface EventContext {
  timestamp: Date
  locale: string
  id: string
  user: User
  tenant: string
}

/**
 * @see [capire docs](https://cap.cloud.sap/docs/node.js/requests)
 */
interface EventMessage extends EventContext {
  event: string
  data: any
  headers: {}
}

interface SpawnEvents {
  'succeeded': (res: any) => void
  'failed': (error: any) => void
  'done': () => void
}

declare class SpawnEventEmitter {
  on<U extends keyof SpawnEvents>(
    event: U, listener: SpawnEvents[U]
  ): this;

  emit<U extends keyof SpawnEvents>(
    event: U, ...args: Parameters<SpawnEvents[U]>
  ): boolean;
  timer: any
}

interface Options {
  [key: string]: any
  every?: number
  after?: number
}

/**
 * @see [capire docs](https://cap.cloud.sap/docs/node.js/requests)
 */
interface Request extends EventMessage {
  params: (string | {})[]
  method: string
  path: string
  target: Definition
  /**
   * Shortcut to {@link target.name}
   *
   * @see https://cap.cloud.sap/docs/node.js/events#req-entity
   */
  entity: string
  query: Query
  subject: ref

  reply(results: any): void

  notify(code: number, message: string, target?: string, args?: {}): Error
  info(code: number, message: string, target?: string, args?: {}): Error
  warn(code: number, message: string, target?: string, args?: {}): Error
  error(code: number, message: string, target?: string, args?: {}): Error
  reject(code: number, message: string, target?: string, args?: {}): Error

  notify(message: string, target?: string, args?: {}): Error
  info(message: string, target?: string, args?: {}): Error
  warn(message: string, target?: string, args?: {}): Error
  error(message: string, target?: string, args?: {}): Error
  reject(message: string, target?: string, args?: {}): Error

  notify(message: { code?: number | string; message: string; target?: string; args?: {} }): Error
  info(message: { code?: number | string; message: string; target?: string; args?: {} }): Error
  warn(message: { code?: number | string; message: string; target?: string; args?: {} }): Error
  error(message: { code?: number | string; message: string; target?: string; args?: {}, status?: number }): Error
  reject(message: { code?: number | string; message: string; target?: string; args?: {}, status?: number }): Error
}

type Events = Event | Event[]
type Event = (CRUD | TX | HTTP | DRAFT) | (CustomOp & {})
type CRUD = 'CREATE' | 'READ' | 'UPDATE' | 'DELETE'
type DRAFT = 'NEW' | 'EDIT' | 'PATCH' | 'SAVE'
type HTTP = 'GET' | 'PUT' | 'POST' | 'PATCH' | 'DELETE'
type TX = 'COMMIT' | 'ROLLBACK'
type CustomOp = string
type Target = string | Definition | ArrayConstructable<any>
